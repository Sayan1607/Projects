IF ( (SELECT count(*)
								FROM dbo.[PR-FILE-V3] 
								where CONVERT(NUMERIC(10,2),[PRCL-IND]) in ( SELECT distinct  CONVERT(NUMERIC(10,2),PRCLIND) FROM ##Temp_ITEMPRCLIND)
								AND CONVERT(NUMERIC(10,2),[DIF(330-PRCL)])  < @Var_330PRCLDIFF
								AND ISNUMERIC(ISNULL([PR-IRES],0.00))=1
								and CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) in (@minval)
								)>1
				)
			BEGIN
				SELECT @VARPRCLL = '''' + REPLACE(STUFF(
								(SELECT ',' +  CAST(CONVERT(NUMERIC(10,2),[PRCL-IND]) AS varchar(50))
								FROM dbo.[PR-FILE-V3] 
								where CONVERT(NUMERIC(10,2),[PRCL-IND]) in ( SELECT distinct  CONVERT(NUMERIC(10,2),PRCLIND) FROM ##Temp_ITEMPRCLIND)
								AND CONVERT(NUMERIC(10,2),[DIF(330-PRCL)])  < @Var_330PRCLDIFF
								AND ISNUMERIC(ISNULL([PR-IRES],0.00))=1
								and CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) in (@minval)
								ORDER BY  CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) desc FOR XML PATH('')
								),1,1,''),',',''''+','+'''') + ''''
								
			END
			ELSE
			BEGIN
				SELECT @VARPRCLL = (SELECT top(1) CONVERT(NUMERIC(10,2),[PRCL-IND])
								FROM dbo.[PR-FILE-V3] 
								where CONVERT(NUMERIC(10,2),[PRCL-IND]) in ( SELECT distinct  CONVERT(NUMERIC(10,2),PRCLIND) FROM ##Temp_ITEMPRCLIND)
								AND CONVERT(NUMERIC(10,2),[DIF(330-PRCL)])  < @Var_330PRCLDIFF
								AND ISNUMERIC(ISNULL([PR-IRES],0.00))=1
								and CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) in (@minval)
								ORDER BY  CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) desc
								)
			END

			IF( (SELECT COUNT(*)
								FROM dbo.[PR-FILE-V3] 
								where CONVERT(NUMERIC(10,2),[PRCL-IND]) in ( SELECT distinct  CONVERT(NUMERIC(10,2),PRCLIND) FROM ##Temp_ITEMPRCLIND)
								AND CONVERT(NUMERIC(10,2),[DIF(330-PRCL)])  > @Var_330PRCLDIFF
								AND ISNUMERIC(ISNULL([PR-IRES],0.00))=1
								and CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) in (@maxval)
								)>1
				)
			BEGIN
				SELECT @VARPRCLH = '''' + REPLACE(STUFF( (SELECT ',' + CAST(CONVERT(NUMERIC(10,2),[PRCL-IND]) AS varchar(50))
								FROM dbo.[PR-FILE-V3] 
								where CONVERT(NUMERIC(10,2),[PRCL-IND]) in ( SELECT distinct  CONVERT(NUMERIC(10,2),PRCLIND) FROM ##Temp_ITEMPRCLIND)
								AND CONVERT(NUMERIC(10,2),[DIF(330-PRCL)])  > @Var_330PRCLDIFF
								AND ISNUMERIC(ISNULL([PR-IRES],0.00))=1
								and CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) in (@maxval)
								ORDER BY  CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) asc FOR XML PATH('')
								),1,1,''),',',''''+','+'''') + ''''
			END
			ELSE
			BEGIN
				SELECT @VARPRCLH = (SELECT top(1) CONVERT(NUMERIC(10,2),[PRCL-IND])
								FROM dbo.[PR-FILE-V3] 
								where CONVERT(NUMERIC(10,2),[PRCL-IND]) in ( SELECT distinct  CONVERT(NUMERIC(10,2),PRCLIND) FROM ##Temp_ITEMPRCLIND)
								AND CONVERT(NUMERIC(10,2),[DIF(330-PRCL)])  > @Var_330PRCLDIFF
								AND ISNUMERIC(ISNULL([PR-IRES],0.00))=1
								and CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) in (@maxval)
								ORDER BY  CONVERT(NUMERIC(10,2),[DIF(330-PRCL)]) asc
								)
			END

			
					
					/*
					IF((SELECT ISNULL(COUNT(*),0)  FROM ##Temp_ITEMPRCLIND WHERE (CONVERT(NUMERIC(10,2),PRCLIND)) IN 
					(
						(select (@Var_PRCLIND + MAX(ABS(CONVERT(NUMERIC(10,2),PRCLIND) - @Var_PRCLIND))) from ##Temp_ITEMPRCLIND)

					))=0)
					BEGIN
						INSERT INTO ##Temp_ITEMPRCLIND
						select @Var_ITEM_NO,(@Var_PRCLIND + MAX(ABS(CONVERT(NUMERIC(10,2),PRCLIND) - @Var_PRCLIND))) from ##Temp_ITEMPRCLIND
					END


					IF((SELECT ISNULL(COUNT(*),0)  FROM ##Temp_ITEMPRCLIND WHERE (CONVERT(NUMERIC(10,2),PRCLIND)) IN 
					(
						(select (@Var_PRCLIND - MAX(ABS(CONVERT(NUMERIC(10,2),PRCLIND) - @Var_PRCLIND))) from ##Temp_ITEMPRCLIND)
					))=0)
					BEGIN
						INSERT INTO ##Temp_ITEMPRCLIND
						select @Var_ITEM_NO,(@Var_PRCLIND - MAX(ABS(CONVERT(NUMERIC(10,2),PRCLIND) - @Var_PRCLIND))) from ##Temp_ITEMPRCLIND
					END
				*/
