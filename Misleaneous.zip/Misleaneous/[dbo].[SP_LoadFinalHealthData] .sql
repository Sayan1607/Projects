USE [ProjectHealth]
GO

/****** Object:  StoredProcedure [dbo].[SP_LoadFinalHealthData]    Script Date: 14/05/2021 8:55:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER PROCEDURE [dbo].[SP_LoadFinalHealthData] 
(
	@Minnoofcells INT
)
AS
BEGIN
		--declare @Minnoofcells INT = 3
		/* 
		=====================================
		Created On: 14-May-2021
		Created By: Sayan Maity

		=====================================
		*/

		-- Truncate all Temp table as well as the resultset

		TRUNCATE TABLE [dbo].[ProjectHealth_Intermediary]

		TRUNCATE TABLE [dbo].[ProjectHealth_IntermediaryC2]

		TRUNCATE TABLE [dbo].[ProjectHealth_IntermediaryC3]
		
		IF OBJECT_ID('tempdb..##Temp_ProjectHelathEntryResult') IS NOT NULL
			DROP TABLE ##Temp_ProjectHelathEntryResult

			select * 
			into ##Temp_ProjectHelathEntryResult 
			from [dbo].[ProjectHelathEntryResult]
		/*	
		if(select count(*)
			from [dbo].[ProjectHelathEntryResult] prs join [dbo].[ProjectHelathEntry] phe
			on prs.ITEM_NO = phe.ITEM_NO
			and prs.[PRCL-IND] = phe.PRCL_IND
			and prs.UD1 = phe.UD1
			and prs.UD2 = phe.UD2
			and prs.UD3 = phe.UD3
			and prs.[330-IND] = phe.[330_IND]
			and prs.[GAP-LMT] = phe.GAP_LIMIT
			and prs.IRES = phe.IRES
			and prs.S1C2 = phe.S1C2
			and prs.[PRCL-NXTDCL-DIF] = phe.[PRCL-NXTDCL-DIF]
			and prs.[PR-DATE] = phe.[PP-DATE]
			)< (select count(*) from [dbo].[ProjectHelathEntryResult])
		begin
			IF OBJECT_ID('tempdb..##Temp_ProjectHelathEntryResult') IS NOT NULL
			DROP TABLE ##Temp_ProjectHelathEntryResult

			select * 
			into ##Temp_ProjectHelathEntryResult 
			from [dbo].[ProjectHelathEntryResult]
		end
		*/

		TRUNCATE TABLE [dbo].[ProjectHelathEntryResult]



		Declare @Var_ITEM_NO INT,
				@Var_PRCL_IND NUMERIC(10,2),
				@NoofCells INT = 0
		
		select DISTINCT @NoofCells =NoofCells FROM ProjectHelathEntry

		IF OBJECT_ID('tempdb..##Temp_ITEMNO') IS NOT NULL
		DROP TABLE ##Temp_ITEMNO

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNO
		FROM ProjectHelathEntry  order by ITEM_NO DESC

		-- FOR C1
		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNO)>0
		BEGIN

		select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNO
		print @Var_ITEM_NO

		select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

		;WITH CTE_LHINDCNT1
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP] <= 
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP] <=
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_LHINDCNT2
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP] <=
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_LHINDCNT3
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP] <=
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		)
			INSERT INTO [dbo].[ProjectHealth_Intermediary]
			select @Var_ITEM_NO, '[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) +']' as [L/H-IND-CNT1], 
			NULL as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_LHINDCNT1
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10))  +']' as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_LHINDCNT2
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
			NULL AS [L/H-IND-CNT2] ,
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT3]
			from CTE_LHINDCNT3

	
			update [dbo].[ProjectHealth_Intermediary]
			set
				[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		
			update [dbo].[ProjectHealth_Intermediary]
			set
				[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

	
			update [dbo].[ProjectHealth_Intermediary]
			set
				[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		DELETE TOP(1) FROM ##Temp_ITEMNO
		END
		
		-- FOR C2
		IF OBJECT_ID('tempdb..##Temp_ITEMNOC2') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC2

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC2
		FROM ProjectHelathEntry  order by ITEM_NO DESC

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC2)>0
		BEGIN

		select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNOC2
		print @Var_ITEM_NO

		select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

		;WITH CTE_C2LHINDCNT1
		AS
		(
			select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
		),

		CTE_C2LHINDCNT2
		AS
		(
			select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
		),

		CTE_C2LHINDCNT3
		AS
		(
			select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
		)

			INSERT INTO [dbo].[ProjectHealth_IntermediaryC2]
			select @Var_ITEM_NO, '[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT1], 
			NULL as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C2LHINDCNT1
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C2LHINDCNT2
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
			NULL AS [L/H-IND-CNT2] ,
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT3]
			from CTE_C2LHINDCNT3

	
			update [dbo].[ProjectHealth_IntermediaryC2]
			set
				[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		
			update [dbo].[ProjectHealth_IntermediaryC2]
			set
				[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

	
			update [dbo].[ProjectHealth_IntermediaryC2]
			set
				[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO



		DELETE TOP(1) FROM ##Temp_ITEMNOC2
		END

		-- FOR 330 IND
		-- FOR C2
		IF OBJECT_ID('tempdb..##Temp_ITEMNOC3') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC3

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC3
		FROM ProjectHelathEntry  order by ITEM_NO DESC

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC3)>0
		BEGIN

		select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNOC3
		print @Var_ITEM_NO

		select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

		;WITH CTE_C3LHINDCNT1
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_C3LHINDCNT2
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_C3LHINDCNT3
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] > (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and [PP-OP]<=
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		)

			INSERT INTO [dbo].[ProjectHealth_IntermediaryC3]
			select @Var_ITEM_NO, '[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT1], 
			NULL as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C3LHINDCNT1
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C3LHINDCNT2
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
			NULL AS [L/H-IND-CNT2] ,
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT3]
			from CTE_C3LHINDCNT3

	
			update [dbo].[ProjectHealth_IntermediaryC3]
			set
				[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_IntermediaryC3] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		
			update [dbo].[ProjectHealth_IntermediaryC3]
			set
				[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_IntermediaryC3] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

	
			update [dbo].[ProjectHealth_IntermediaryC3]
			set
				[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_IntermediaryC3] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		DELETE TOP(1) FROM ##Temp_ITEMNOC3
		END



		insert into [dbo].[ProjectHelathEntryResult]
		select  A.ITEM_NO,
				substring(A.[PP-DATE-NEW],1,10) as [PR-DATE],
				--(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'RED' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@Minnoofcells as MinNoOfCells,
				NULL    AS [2COL/NET],
				NULL    AS [4COL/NET],
				NULL    AS [3COL/ST/ALIGNED],
				NULL    AS [3COL/ST/GAP],
				NULL    AS [S1/LH/CNT/SUM],
				NULL    AS [S2/LH/CNT/SUM],
				NULL    AS [S3/LH/CNT/SUM],
				NULL    AS [LH-MINUS-SUM/S1+S2+S3(ADD ONLY MINUSES, ELSE 0)],
				NULL	AS [NO-OF-Ls/NO-OF-Hs],
				NULL	AS [PP-PRCL-PPOP/33IND-PPCL/NET-AVG],
				NULL	AS [ACC/X],
				NULL AS  [RED/AVG-POS],
				NULL AS  [RED/AVG-NEG],
				NULL AS  [RED-P/13&12&23ROWS-TR],
				NULL AS  [RED-N/13&12&23ROWS-TR],
				NULL AS  [UP/SUM],
				NULL AS  [DW/SUM],
				NULL AS  [UP/CNT],
				NULL AS  [DW/CNT],
				NULL AS [13&12&23/UP/CNT],
				NULL AS [13&12&23/ DW/CNT],
				NULL AS [UP/AMT-AVG],
				NULL AS [DW/AMT-AVG],
				NULL AS [ACC],
				NULL AS [DIFF/330IN-PRCL],
				NULL AS [PP-PRCL-PPCL/DIF(OP-CL)/UD],
				NULL AS [NET-AVG],
				NULL AS [TR],
				NULL AS [ACC/PRCL-DIF],
				NULL   AS   [PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD],
				NULL   AS   [PP-PDCLST/NXT/NET-AVG],
				NULL   AS	[PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/NXT-UD],
				NULL   AS   [ACC/PPDFN],
				NULL   AS   [TR/DIF-DIF],
				NULL   AS   [ACC/TR],
				NULL   AS   [PR-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD],
				NULL   AS   [PR-PRCL-DIF/NET-AVG],
				NULL   AS   [ACC/PR/PD],
				NULL   AS	[PR-PRCL-PRCL(CLST-RNG)/DIF(OP-CL)/NXT-UD],
				NULL   AS	[PR-PRCL-DIF/NXT-NET-AVG],
				NULL   AS	[ACC/PR/NXT/PD]
		from [dbo].[ProjectHelathEntry] a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]

		union

		select  A.ITEM_NO,
				substring(A.[PP-DATE-NEW],1,10) as [PR-DATE],
				--(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD4],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD5],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD6],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'INC' as [RED/INC],
				[UD4] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@Minnoofcells as MinNoOfCells,
				NULL    AS [2COL/NET],
				NULL    AS [4COL/NET],
				NULL    AS [3COL/ST/ALIGNED],
				NULL    AS [3COL/ST/GAP],
				NULL    AS [S1/LH/CNT/SUM],
				NULL    AS [S2/LH/CNT/SUM],
				NULL    AS [S3/LH/CNT/SUM],
				NULL    AS [LH-MINUS-SUM/S1+S2+S3(ADD ONLY MINUSES, ELSE 0)],
				NULL	AS [NO-OF-Ls/NO-OF-Hs],
				NULL	AS [PP-PRCL-PPOP/33IND-PPCL/NET-AVG],
				NULL	AS [ACC/X],
				NULL AS  [RED/AVG-POS],
				NULL AS  [RED/AVG-NEG],
				NULL AS  [RED-P/13&12&23ROWS-TR],
				NULL AS  [RED-N/13&12&23ROWS-TR],
				NULL AS  [UP/SUM],
				NULL AS  [DW/SUM],
				NULL AS  [UP/CNT],
				NULL AS  [DW/CNT],
				NULL AS [13&12&23/UP/CNT],
				NULL AS [13&12&23/ DW/CNT],
				NULL AS [UP/AMT-AVG],
				NULL AS [DW/AMT-AVG],
				NULL AS [ACC],
				NULL AS [DIFF/330IN-PRCL],
				NULL AS [PP-PRCL-PPCL/DIF(OP-CL)/UD],
				NULL AS [NET-AVG],
				NULL AS [TR],
				NULL AS [ACC/PRCL-DIF],
				NULL   AS   [PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD],
				NULL   AS   [PP-PDCLST/NXT/NET-AVG],
				NULL   AS	[PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/NXT-UD],
				NULL   AS   [ACC/PPDFN],
				NULL   AS   [TR/DIF-DIF],
				NULL   AS   [ACC/TR],
				NULL   AS   [PR-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD],
				NULL   AS   [PR-PRCL-DIF/NET-AVG],
				NULL   AS   [ACC/PR/PD],
				NULL   AS	[PR-PRCL-PRCL(CLST-RNG)/DIF(OP-CL)/NXT-UD],
				NULL   AS	[PR-PRCL-DIF/NXT-NET-AVG],
				NULL   AS	[ACC/PR/NXT/PD]
		from [dbo].[ProjectHelathEntry] a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]


		EXEC SP_Loaddifferentset
		
		--EXEC SP_UpdateHealthDataREC @PPRNGUD = 0.03
		--EXEC SP_UpdateHealthDataINC @PPRNGUD = 0.03
		--EXEC SP_UpdateHealthDataREC @PPRNGUD = 0.05
		--EXEC SP_UpdateHealthDataINC @PPRNGUD = 0.05
		--EXEC SP_UpdateHealthDataREC @PPRNGUD = 0.10
		--EXEC SP_UpdateHealthDataINC @PPRNGUD = 0.10
		
		Declare @Var_03Red INT = 0,
				@Var_03INC	INT = 0,
				@Var_05Red	INT = 0,
				@Var_05Inc	INT = 0,
				@Var_10Red	INT = 0,
				@Var_10Inc	INT = 0,
				@VarUd1R		NUMERIC(10,2) = 0.00,
				@VarUd2R		NUMERIC(10,2) = 0.00,
				@VarUd3R		NUMERIC(10,2) = 0.00,
				@VarUd1I		NUMERIC(10,2) = 0.00,
				@VarUd2I		NUMERIC(10,2) = 0.00,
				@VarUd3I		NUMERIC(10,2) = 0.00,
				@Var_MinCells	INT = 0

				set @Var_MinCells = @Minnoofcells


		
		IF OBJECT_ID('tempdb..##Temp_ITEMNOC4') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC4

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC4
		FROM ProjectHelathEntry order by ITEM_NO DESC

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC4)>0
		BEGIN

			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC4

			SELECT TOP(1) @Var_03Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' ORDER BY ID asc
			SELECT TOP(1) @Var_03INC = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' ORDER BY ID asc

			
			SELECT TOP(1) @Var_10Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' order by Id desc
			SELECT TOP(1) @Var_10Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' order by Id desc

			SELECT @Var_05Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = (@Var_03Red+1)
			SELECT @Var_05Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and id = (@Var_03INC+ 1)

			-- ud1, ud2, ud3

			SELECT @VarUd1R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_03Red
			SELECT @VarUd1I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_03INC
			SELECT @VarUd2R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_05Red
			SELECT @VarUd2I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_05Inc
			SELECT @VarUd3R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_10Red
			SELECT @VarUd3I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_10Inc

			--PRINT '@Var_03Red-->' + CAST(@Var_03Red AS VARCHAR(10)) + '@Var_03INC-->' + CAST(@Var_03INC AS VARCHAR(10)) + '@Var_05Red-->' + CAST(@Var_05Red AS VARCHAR(10)) + '@Var_05Inc-->' + CAST(@Var_05Inc AS VARCHAR(10))+ '@Var_10Red-->' + CAST(@Var_10Red AS VARCHAR(10)) + '@Var_10Inc-->' + CAST(@Var_10Inc AS VARCHAR(10))
			--PRINT '@VarUd1R-->' + CAST(@VarUd1R AS VARCHAR(10)) + '@VarUd1I-->' + CAST(@VarUd1I AS VARCHAR(10)) + '@VarUd2R-->' + CAST(@VarUd2R AS VARCHAR(10)) + '@VarUd2I-->' + CAST(@VarUd2I AS VARCHAR(10))+ '@VarUd3R-->' + CAST(@VarUd3R AS VARCHAR(10)) + '@VarUd3I-->' + CAST(@VarUd3I AS VARCHAR(10))

			set @Minnoofcells = @Var_MinCells
			
			-- for 0.03
			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@Id=@Var_03Red, @NoOfCells= @Minnoofcells
			
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_03INC, @NoOfCells= @Minnoofcells
			

			-- for 0.05
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = @Var_03Red
			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			--print '@Minnoofcells-->' + cast(@Minnoofcells as varchar(10))

			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_05Red, @NoOfCells= @Minnoofcells
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id = @Var_03INC

			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_05Inc, @NoOfCells= @Minnoofcells
			
			-- for 0.10
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id=@Var_05Red

			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			
			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_10Red, @NoOfCells= @Minnoofcells
			
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id=@Var_05Inc
			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_10Inc, @NoOfCells= @Minnoofcells
			
			DELETE TOP(1) FROM ##Temp_ITEMNOC4
		END

		IF OBJECT_ID('tempdb..##Temp_ITEMNOC5') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC5

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC5
		FROM ProjectHelathEntry order by ITEM_NO DESC

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC5)>0
		BEGIN

			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC5
			
			;WITH CTE_RED_3COL
			AS
			(
				SELECT ITEM_NO,[RED/INC], 
						SUM([3COL/NET]) AS RED_3COL_TOT,
						SUM(TOT) AS RED_TOT
				FROM dbo.ProjectHelathEntryResult(nolock)
				WHERE ITEM_NO IN (@Var_ITEM_NO)
				AND [RED/INC] = 'RED'
				GROUP BY ITEM_NO,
						[RED/INC]
			),
			CTE_INC_3COL
			AS
			(
				SELECT ITEM_NO,[RED/INC], 
						SUM([3COL/NET]) AS INC_3COL_TOT,
						SUM(TOT) AS INC_TOT
				FROM dbo.ProjectHelathEntryResult(nolock)
				WHERE ITEM_NO IN (@Var_ITEM_NO)
				AND [RED/INC] = 'INC'
				GROUP BY ITEM_NO,
						[RED/INC]
			)
			UPDATE A
			SET 
				A.[3COL/ST/ALIGNED] = B.[3COL/ST/ALIGNED]
			FROM dbo.ProjectHelathEntryResult A join
			(
			SELECT CTE_RED_3COL.ITEM_NO,
					CASE WHEN RED_TOT > INC_TOT
						THEN CASE WHEN RED_3COL_TOT > INC_3COL_TOT
									THEN 'Y'
									WHEN RED_3COL_TOT< INC_3COL_TOT
									THEN 'N'
									WHEN RED_3COL_TOT = INC_3COL_TOT
									THEN 'N/A'
							END
						WHEN RED_TOT < INC_TOT
						THEN CASE WHEN RED_3COL_TOT> INC_3COL_TOT
								  THEN 'N'
								  WHEN RED_3COL_TOT < INC_3COL_TOT
								  THEN 'Y'
								  WHEN RED_3COL_TOT=INC_3COL_TOT
								  THEN 'N/A'
							END
						WHEN RED_TOT = INC_TOT
						THEN CASE WHEN RED_3COL_TOT< INC_3COL_TOT
								  THEN 'N/A'
								  WHEN RED_3COL_TOT < INC_3COL_TOT
								  THEN 'N/A'
								  WHEN RED_3COL_TOT=INC_3COL_TOT
								  THEN 'N/A'
							END
					END AS [3COL/ST/ALIGNED]

			FROM CTE_RED_3COL JOIN CTE_INC_3COL
			ON CTE_RED_3COL.ITEM_NO = CTE_INC_3COL.ITEM_NO
			)B
			ON A.ITEM_NO = B.ITEM_NO

		DELETE TOP(1) FROM ##Temp_ITEMNOC5
		END

		--=========== New Columns=====

		/*
		Declare @NoofCells INT = 200,
			@Var_ITEM_NO	INT
		*/
		IF OBJECT_ID('tempdb..##Temp_ITEMNOC51') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC51

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC51
		FROM ProjectHelathEntry order by ITEM_NO DESC

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC51)>0
		BEGIN

			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC51

			PRINT @Var_ITEM_NO
		-- Column [PP-PRCL-PPOP/33IND-PPCL/NET-AVG] value update
			--EXEC dbo.SP_CalculateCloseRange @ITEMNO	= @Var_ITEM_NO

		DELETE TOP(1) FROM ##Temp_ITEMNOC51
		END

		--- New Columns 
		
		IF OBJECT_ID('tempdb..##Temp_REDAVGPOS') IS NOT NULL
		DROP TABLE ##Temp_REDAVGPOS

		;WITH CTE_REDAVGPOS
		AS
		(
				SELECT id,
					(CASE WHEN ISNULL(Res1, 0) >0.00
							THEN Res1
							else 0.00
						END
						) as Res1 ,
						
						(CASE WHEN ISNULL(Res2, 0) >0.00
							THEN Res2
							else 0.00
						END
						) as Res2,
						
						(CASE WHEN ISNULL(Res3, 0) >0.00
							THEN Res3
							else 0.00
						END
						) as Res3
						,
						(CASE WHEN ISNULL(Res4, 0) >0.00
							THEN Res4
							else 0.00
						END
						) as Res4
						,
						(CASE WHEN ISNULL(Res5, 0) >0.00
							THEN Res5
							else 0.00
						END
						) as Res5
						,
						(CASE WHEN ISNULL(Res6, 0) >0.00
							THEN Res6
							else 0.00
						END
						) as Res6
						,
						(CASE WHEN ISNULL(Res7, 0) >0.00
							THEN Res7
							else 0.00
						END
						) as Res7
						,
						(CASE WHEN ISNULL(Res8, 0) >0.00
							THEN Res8
							else 0.00
						END
						) as Res8
						,
						(CASE WHEN ISNULL(Res9, 0) >0.00
							THEN Res9
							else 0.00
						END
						) as Res9 
				FROM dbo.ProjectHelathEntryResult
		)

			SELECT id,
				(case when Res1= 0.00
						then 0
						else 1 
					end
					+
					case when Res2= 0.00
						then 0
						else 1 
					end
					+
					case when Res3= 0.00
						then 0
						else 1 
					end
					+
					case when Res4= 0.00
						then 0
						else 1 
					end
					+
					case when Res5= 0.00
						then 0
						else 1 
					end
					+
					case when Res6= 0.00
						then 0
						else 1 
					end
					+
					case when Res7= 0.00
						then 0
						else 1 
					end
					+
					case when Res8= 0.00
						then 0
						else 1 
					end
					+
					case when Res9= 0.00
						then 0
						else 1 
					end
					) as TOTALCNT,
					(Res1+Res2+Res3+Res4+Res5+Res6+Res7+Res8+Res9) as TOTPOS
			INTO ##Temp_REDAVGPOS
			FROM CTE_REDAVGPOS

		UPDATE A
		SET
			A.[RED/AVG-POS] = CONVERT(NUMERIC(10,2),(ISNULL(B.TOTPOS,0)/B.TOTALCNT))
		FROM dbo.ProjectHelathEntryResult A join ##Temp_REDAVGPOS B
		on A.Id = B.Id
		and B.TOTALCNT > 0

		IF OBJECT_ID('tempdb..##Temp_REDAVGNEG') IS NOT NULL
		DROP TABLE ##Temp_REDAVGNEG

		;WITH CTE_REDAVGNEG
		AS
		(
		SELECT id,(CASE WHEN ISNULL(Res1, 0) <=0.00
					THEN ISNULL(Res1,0)
					else 0.00
				END
				) AS Res1
			,
			(CASE WHEN ISNULL(Res2, 0) <=0.00
					THEN ISNULL(Res2,0)
					else 0.00
				END
			)  AS Res2
			,
			(CASE WHEN ISNULL(Res3, 0) <=0.00
					THEN ISNULL(Res3,0)
					ELSE 0.00
				END
			)  AS Res3
			,
			(CASE WHEN ISNULL(Res4, 0) <=0.00
					THEN ISNULL(Res4,0)
					ELSE 0.00
				END
			) AS Res4
			,
			(CASE WHEN ISNULL(Res5, 0) <=0.00
					THEN ISNULL(Res5,0)
					else 0.00
				END
			)  AS Res5
			,
			(CASE WHEN ISNULL(Res6, 0) <=0.00
					THEN ISNULL(Res6,0)
					else 0.00
				END
			) AS Res6
			,
			(CASE WHEN ISNULL(Res7, 0) <=0.00
					THEN ISNULL(Res7,0)
					ELSE 0.00
				END
			) AS Res7 
			,
			(CASE WHEN ISNULL(Res8, 0) <=0.00
					THEN ISNULL(Res8,0)
					ELSE 0.00
				END
			) AS Res8
			,
			(CASE WHEN ISNULL(Res9, 0) <=0.00
					THEN ISNULL(Res9,0)
					ELSE 0.00
				END
			)  AS Res9
		FROM dbo.ProjectHelathEntryResult				
	)
			SELECT id,
				(case when Res1= 0.00
						then 0
						else 1 
					end
					+
					case when Res2= 0.00
						then 0
						else 1 
					end
					+
					case when Res3= 0.00
						then 0
						else 1 
					end
					+
					case when Res4= 0.00
						then 0
						else 1 
					end
					+
					case when Res5= 0.00
						then 0
						else 1 
					end
					+
					case when Res6= 0.00
						then 0
						else 1 
					end
					+
					case when Res7= 0.00
						then 0
						else 1 
					end
					+
					case when Res8= 0.00
						then 0
						else 1 
					end
					+
					case when Res9= 0.00
						then 0
						else 1 
					end
					) as TOTALCNT,
					(Res1+Res2+Res3+Res4+Res5+Res6+Res7+Res8+Res9) as TOTNEG
			INTO ##Temp_REDAVGNEG
			FROM CTE_REDAVGNEG
			
		UPDATE A
		SET
			A.[RED/AVG-NEG] = CONVERT(NUMERIC(10,2),(ISNULL(B.TOTNEG,0)/B.TOTALCNT))
		FROM dbo.ProjectHelathEntryResult A join ##Temp_REDAVGNEG B
		on A.Id = B.Id
		and B.TOTALCNT >0

		UPDATE dbo.ProjectHelathEntryResult 
		SET
			[RED/AVG-POS] = 0
		WHERE [RED/AVG-POS] IS NULL

		UPDATE dbo.ProjectHelathEntryResult 
		SET
			[RED/AVG-NEG] = 0
		WHERE [RED/AVG-NEG] IS NULL


--[RED/AVG-POS]
--==============================

	--DECLARE @NoofCells INT = 200,
	--			@Var_ITEM_NO INT = 1061

		IF OBJECT_ID('tempdb..##Temp_ITEMNOC512') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC512

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC512
		FROM ProjectHelathEntry order by ITEM_NO DESC


		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC512)>0
		BEGIN
		SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC512
		;WITH CTE_PAVG
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'RED'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'RED'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG))

		-- 2ND ROW
		;WITH CTE_PAVG2
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'RED'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'RED'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG2)+1)

		-- 3rd ROW
		;WITH CTE_PAVG3
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'RED'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'RED'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG3)+2)

		
		-- INC
		;WITH CTE_PAVGINC
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'INC'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'INC'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVGINC))
		
		-- 2ND ROW
		;WITH CTE_PAVG2
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'INC'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'INC'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG2)+1)

		-- 3rd ROW
		;WITH CTE_PAVG3
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'INC'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3  WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 1))) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'INC'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG3)+2)

		
		DELETE TOP(1) FROM ##Temp_ITEMNOC512
	END
		-- DW UP COUNT
--=====================

		--DECLARE @NoofCells INT = 200,
		--		@Var_ITEM_NO INT

		IF OBJECT_ID('tempdb..##Temp_ITEMNOC513') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC513

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC513
		FROM ProjectHelathEntry order by ITEM_NO DESC


		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC513)>0
		BEGIN
			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC513

			;WITH CTE_UPDW
			AS
			(
				SELECT ID,( (CASE WHEN [RED-P/13&12&23ROWS-TR] like 'UP%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-P/13&12&23ROWS-TR],'UP/',''))
						ELSE 0.00
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'UP%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-N/13&12&23ROWS-TR],'UP/',''))
						ELSE 0.00
					END)
				) AS [UP/SUM],
				((CASE WHEN [RED-P/13&12&23ROWS-TR] like 'DW%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-P/13&12&23ROWS-TR],'DW/',''))
						ELSE 0.00
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'DW%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-N/13&12&23ROWS-TR],'DW/',''))
						ELSE 0.00
					END)
				) as [DW/SUM],
				( (CASE WHEN [RED-P/13&12&23ROWS-TR] like 'UP%'
						THEN 1
						ELSE 0
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'UP%'
						THEN 1
						ELSE 0
					END)
				) AS [UP/CNT],
				((CASE WHEN [RED-P/13&12&23ROWS-TR] like 'DW%'
						THEN 1
						ELSE 0
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'DW%'
						THEN 1
						ELSE 0
					END)
				) as [DW/CNT]

			FROM dbo.ProjectHelathEntryResult(nolock)
			WHERE ITEM_NO IN (@Var_ITEM_NO)
			)

			UPDATE A
			set
				A.[UP/SUM] = B.[UP/SUM],
				A.[DW/SUM] = B.[DW/SUM],
				A.[UP/CNT] = B.[UP/CNT],
				A.[DW/CNT] = B.[DW/CNT]
			FROM dbo.ProjectHelathEntryResult A join CTE_UPDW B
			on A.Id = B.Id

		DELETE TOP(1) FROM ##Temp_ITEMNOC513
		END

		/*
		=========================================
		-- 13&12&23/UP/CNT
		-- 13&12&23/ DW/CNT
		=========================================
		*/

		IF OBJECT_ID('tempdb..##Temp_ITEMNOCL513') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOCL513

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOCL513
		FROM ProjectHelathEntry order by ITEM_NO DESC


		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOCL513)>0
		BEGIN
			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOCL513


						UPDATE A
						SET
							[13&12&23/UP/CNT] = ResultL.Result
							--[UP/AMT-AVG] = ResultL.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'UP/' + CAST( (convert(smallint,a.[UP/CNT]) + Convert(smallInt,b.[UP/CNT])) AS varchar(20)) as Result
								--'UP/' + CAST( convert(numeric(10,2),(convert(numeric(10,2),a.[UP/SUM]) + Convert(numeric(10,2),b.[UP/SUM]))/2) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED')
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC')
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL
						ON A.ITEM_NO = ResultL.ITEM_NO
						WHERE A.[RED/INC] = 'RED'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)

						UPDATE A
						SET
							[13&12&23/ DW/CNT] = ResultL1.Result
							--[DW/AMT-AVG] = ResultL1.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'DW/' + CAST( (convert(smallint,a.[DW/CNT]) + Convert(smallInt,b.[DW/CNT])) AS varchar(20)) as Result
								--'DW/' + CAST( convert(numeric(10,2),(convert(numeric(10,2),a.[DW/SUM]) + Convert(numeric(10,2),b.[DW/SUM]))/2) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED')
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC')
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL1
						ON A.ITEM_NO = ResultL1.ITEM_NO
						WHERE A.[RED/INC] = 'RED'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)

						--23 row
						UPDATE A
						SET
							[13&12&23/UP/CNT] = ResultL2.Result
							--[UP/AMT-AVG] = ResultL2.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'UP/' + CAST( (convert(smallint,a.[UP/CNT]) + Convert(smallInt,b.[UP/CNT])) AS varchar(20)) as Result
								--'UP/' + CAST( convert(numeric(10,2),(convert(numeric(10,2),a.[UP/SUM]) + Convert(numeric(10,2),b.[UP/SUM]))/2) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC') + 2)
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL2
						ON A.ITEM_NO = ResultL2.ITEM_NO
						WHERE A.[RED/INC] = 'INC'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC'))

						UPDATE A
						SET
							[13&12&23/ DW/CNT] = ResultL3.Result
							--[DW/AMT-AVG] = ResultL3.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'DW/' + CAST( (convert(smallint,a.[DW/CNT]) + Convert(smallInt,b.[DW/CNT])) AS varchar(20)) as Result
								--'DW/' + CAST( convert(numeric(10,2),(convert(numeric(10,2),a.[DW/SUM]) + Convert(numeric(10,2),b.[DW/SUM]))/2) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC') + 2)
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL3
						ON A.ITEM_NO = ResultL3.ITEM_NO
						WHERE A.[RED/INC] = 'INC'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC'))

						-- AMTAVG ROW 1 AND 3
						--=========================
						--UPDATE 

						EXEC dbo.SP_CalculateAVGAMT1STROW @Var_ITEM_NO = @Var_Item_No
						EXEC dbo.SP_CalculateAVGAMT3RDROW @Var_ITEM_NO = @Var_Item_No

						-- New column [DIFF/330IN-PRCL]

						UPDATE dbo.ProjectHelathEntryResult
						set
							[DIFF/330IN-PRCL] = [330-IND] - [PRCL-IND]
						WHERE ITEM_NO IN (@Var_Item_No)

		DELETE TOP(1) FROM ##Temp_ITEMNOCL513
		END

		-- new column

		IF OBJECT_ID('tempdb..##Temp_ITEMNOCL5114R') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOCL5114R

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOCL5114R
		FROM ProjectHelathEntry --where ITEM_NO = 1016
		order by ITEM_NO DESC

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOCL5114R)>0
		BEGIN
			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOCL5114R

				EXEC SP_CalCulateRangePP @Var_ITEM_NO = @Var_ITEM_NO
				
				EXEC dbo.SP_CalCulateRangePR @Var_ITEM_NO = @Var_ITEM_NO

			
			DELETE TOP(1) FROM ##Temp_ITEMNOCL5114R
		END
		
		EXEC SP_GraphPercentageCalc

	-- INSERTING ONE BLANK ROW FOR SEGREGATING ROWS IN BETWEEN
		/*
		insert into dbo.ProjectHelathEntryResult
		select NULL AS    [ITEM_NO],
			NULL AS    [PR-DATE],
			NULL AS    [PRCL-IND],
			NULL AS    [330-IND],
			NULL AS    [S1C2],
			NULL AS    [UD1],
			NULL AS    [L/H-IND-CNT1],
			NULL AS    [UD2],
			NULL AS    [L/H-IND-CNT2],
			NULL AS    [UD3],
			NULL AS    [L/H-IND-CNT3],
			NULL AS    [PRCL-NXTDCL-DIF],
			NULL AS    [N/P-C2-CNT1],
			NULL AS    [N/P-C2-CNT2],
			NULL AS    [N/P-C2-CNT3],
			NULL AS    [RED/INC],
			NULL AS    [PP-RNG-UD],
			NULL AS    [GAP-LMT],
			NULL AS    [IND-GAP],
			NULL AS    [LIND],
			NULL AS    [MIND],
			NULL AS    [Res9],
			NULL AS    [Res8],
			NULL AS    [Res7],
			NULL AS    [Res6],
			NULL AS    [Res5],
			NULL AS    [Res4],
			NULL AS    [Res3],
			NULL AS    [Res2],
			NULL AS    [Res1],
			NULL AS    [TOT],
			NULL AS    [ALL-CNT(P/N)],
			NULL AS    [GREEN],
			NULL AS    [ACC],
			NULL AS    [COMM],
			NULL AS    [IRES]
		*/
		-- Checking whether any changes in input data, if there is any changes, it will append in the resultset
		insert into dbo.ProjectHelathEntryResult
		select a.[ITEM_NO],
				a.[PR-DATE],
				a.[PRCL-IND],
				a.[330-IND],
				a.[S1C2],
				a.[UD1],
				a.[PRCL/PRCL-IND-CNT1],
				a.[UD2],
				a.[PRCL/PRCL-IND-CNT2],
				a.[UD3],
				a.[PRCL/PRCL-IND-CNT3],
				--a.[PRCL-NXTDCL-DIF],
				a.[PRCL/C2-CNT1],
				a.[PRCL/C2-CNT2],
				a.[PRCL/C3-CNT3],
				a.[RED/INC],
				a.[PP-RNG-UD],
				a.[GAP-LMT],
				a.[IND-GAP],
				a.[LIND],
				a.[MIND],
				a.[Res9],
				a.[Res8],
				a.[Res7],
				a.[Res6],
				a.[Res5],
				a.[Res4],
				a.[Res3],
				a.[Res2],
				a.[Res1],
				a.[TOT],
				a.[ALL-CNT(P/N)],
				a.[GREEN],
				a.[ACC/TOT],
				a.[3COL/NET],
				a.[ACC/3COL],
				a.[COMM],
				a.[IRES],
				a.[PRFIN-IND],
				a.[PRCL/330IND-R1-C],
				a.[PRCL/330IND-R2-C],
				a.[PRCL/330IND-R3-C],
				a.[PR-S1C1],
				a.[PR-S1C2],
				a.[PR-S1C3],
				a.[MinNoOfCells],
				a.[2COL/NET],
				a.[4COL/NET],
				a.[3COL/ST/ALIGNED],
				a.[3COL/ST/GAP],
				a.[S1/LH/CNT/SUM],
				a.[S2/LH/CNT/SUM],
				a.[S3/LH/CNT/SUM],
				a.[LH-MINUS-SUM/S1+S2+S3(ADD ONLY MINUSES, ELSE 0)],
				a.[NO-OF-Ls/NO-OF-Hs],
				a.[PP-PRCL-PPOP/33IND-PPCL/NET-AVG],
				a.[ACC/X],
				a.[RED/AVG-POS],
				a.[RED/AVG-NEG],
				a.[RED-P/13&12&23ROWS-TR],
				a.[RED-N/13&12&23ROWS-TR],
				a.[UP/SUM],
				a.[DW/SUM],
				a.[UP/CNT],
				a.[DW/CNT],
				a.[13&12&23/UP/CNT],
				a.[13&12&23/ DW/CNT],
				a.[UP/AMT-AVG],
				a.[DW/AMT-AVG],
				a.[ACC],
				A.[DIFF/330IN-PRCL],
				A.[PP-PRCL-PPCL/DIF(OP-CL)/UD],
				a.[NET-AVG],
				a.[TR],
				a.[ACC/PRCL-DIF],
				a.[PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD],
				a.[PP-PDCLST/NXT/NET-AVG],
				a.[PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/NXT-UD],
				a.[ACC/PPDFN],
				a.[TR/DIF-DIF],
				a.[ACC/TR],
				a.[PR-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD],
				a.[PR-PRCL-DIF/NET-AVG],
				a.[ACC/PR/PD],
				a.[PR-PRCL-PRCL(CLST-RNG)/DIF(OP-CL)/NXT-UD],
				a.[PR-PRCL-DIF/NXT-NET-AVG],
				a.[ACC/PR/NXT/PD]
		from ##Temp_ProjectHelathEntryResult a left join dbo.ProjectHelathEntryResult b
		ON A.ITEM_NO = b.ITEM_NO
		and a.[PR-DATE] = b.[PR-DATE]
		and a.[PRCL-IND] = b.[PRCL-IND]
		and a.[330-IND] = b.[330-IND]
		and a.UD1 = b.UD1
		and a.ud2 = b.ud2
		and a.UD3 = b.UD3
		and a.[GAP-LMT] = b.[GAP-LMT]
		and a.S1C2 = b.S1C2
		and a.IRES = b.IRES
		--and a.[PRCL-NXTDCL-DIF] = b.[PRCL-NXTDCL-DIF]
		where b.ITEM_NO is null

END
GO


