
Declare @Var_03Red INT = 0,
				@Var_03INC	INT = 0,
				@Var_05Red	INT = 0,
				@Var_05Inc	INT = 0,
				@Var_10Red	INT = 0,
				@Var_10Inc	INT = 0,
				@VarUd1R		NUMERIC(10,2) = 0.00,
				@VarUd2R		NUMERIC(10,2) = 0.00,
				@VarUd3R		NUMERIC(10,2) = 0.00,
				@VarUd1I		NUMERIC(10,2) = 0.00,
				@VarUd2I		NUMERIC(10,2) = 0.00,
				@VarUd3I		NUMERIC(10,2) = 0.00,
				@Var_MinCells	INT = 0,
				@Minnoofcells	INT = 3,
				@Var_ITEM_NO	INT 

				set @Var_MinCells = @Minnoofcells


		IF OBJECT_ID('tempdb..##Temp_ITEMNOC4') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC4

		SELECT DISTINCT TOP(100) ITEM_NO
		INTO ##Temp_ITEMNOC4
		FROM ProjectHelathEntry ORDER BY ITEM_NO desc

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC4)>0
		BEGIN

			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC4

			SELECT TOP(1) @Var_03Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' ORDER BY ID asc
			SELECT TOP(1) @Var_03INC = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' ORDER BY ID asc

			
			SELECT TOP(1) @Var_10Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' order by Id desc
			SELECT TOP(1) @Var_10Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' order by Id desc

			SELECT @Var_05Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = (@Var_03Red+1)
			SELECT @Var_05Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and id = (@Var_03INC+ 1)

			-- ud1, ud2, ud3

			SELECT @VarUd1R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_03Red
			SELECT @VarUd1I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_03INC
			SELECT @VarUd2R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_05Red
			SELECT @VarUd2I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_05Inc
			SELECT @VarUd3R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_10Red
			SELECT @VarUd3I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_10Inc

			--PRINT '@Var_03Red-->' + CAST(@Var_03Red AS VARCHAR(10)) + '@Var_03INC-->' + CAST(@Var_03INC AS VARCHAR(10)) + '@Var_05Red-->' + CAST(@Var_05Red AS VARCHAR(10)) + '@Var_05Inc-->' + CAST(@Var_05Inc AS VARCHAR(10))+ '@Var_10Red-->' + CAST(@Var_10Red AS VARCHAR(10)) + '@Var_10Inc-->' + CAST(@Var_10Inc AS VARCHAR(10))
			--PRINT '@VarUd1R-->' + CAST(@VarUd1R AS VARCHAR(10)) + '@VarUd1I-->' + CAST(@VarUd1I AS VARCHAR(10)) + '@VarUd2R-->' + CAST(@VarUd2R AS VARCHAR(10)) + '@VarUd2I-->' + CAST(@VarUd2I AS VARCHAR(10))+ '@VarUd3R-->' + CAST(@VarUd3R AS VARCHAR(10)) + '@VarUd3I-->' + CAST(@VarUd3I AS VARCHAR(10))

			set @Minnoofcells = @Var_MinCells
			
			-- for 0.03
			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@Id=@Var_03Red, @NoOfCells= @Minnoofcells
			
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_03INC, @NoOfCells= @Minnoofcells
			

			-- for 0.05
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = @Var_03Red
			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			--print '@Minnoofcells-->' + cast(@Minnoofcells as varchar(10))

			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_05Red, @NoOfCells= @Minnoofcells
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id = @Var_03INC

			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_05Inc, @NoOfCells= @Minnoofcells
			
			-- for 0.10
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id=@Var_05Red

			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			
			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_10Red, @NoOfCells= @Minnoofcells
			
			select @Minnoofcells = (case when Res1 IS NULL then 0 else 1 end 
									+ case when Res2 IS NULL then 0 else 1 end 
									+ case when Res3 IS NULL  then 0 else 1 end
									+ case when Res4 IS NULL  then 0 else 1 end
									+ case when Res5 IS NULL  then 0 else 1 end
									+ case when Res6 IS NULL  then 0 else 1 end 
									+ case when Res7 IS NULL  then 0 else 1 end
									+ case when Res8 IS NULL  then 0 else 1 end
									+ case when Res9 IS NULL  then 0 else 1 end     
								)
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id=@Var_05Inc
			IF(@Minnoofcells<9)
			begin
			SET @Minnoofcells = @Minnoofcells + 1
			end
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@Id = @Var_10Inc, @NoOfCells= @Minnoofcells
			
			DELETE TOP(1) FROM ##Temp_ITEMNOC4
		END
