
DECLARE @Var_ITEM_NO VARCHAR(20) = '1065D'


			IF OBJECT_ID('tempdb..##Temp_AVGAMT') IS NOT NULL
			DROP TABLE ##Temp_AVGAMT

			SELECT @Var_ITEM_NO = REPLACE(@Var_ITEM_NO,'D','U')
			;with CTE_FLINC 
			AS
			( 
				SELECT *
				FROM dbo.ProjectHelathEntryResult 
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'INC'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+2)		
			),
			CTE_FLRED
			AS
			(

				SELECT *
				FROM dbo.ProjectHelathEntryResult
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'RED'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+2)	
			)

		SELECT (CTE_FLRED.[RED-P/13&12&23ROWS-TR] + ':' + CTE_FLINC.[RED-P/13&12&23ROWS-TR]) AVGAMT
		INTO ##Temp_AVGAMT
		FROM CTE_FLINC join CTE_FLRED
		on CTE_FLINC.ITEM_NO = CTE_FLRED.ITEM_NO

		-- 2nd ROW
		;with CTE_FLINC 
			AS
			( 
				SELECT *
				FROM dbo.ProjectHelathEntryResult 
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'INC'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+2)		
			),
			CTE_FLRED
			AS
			(

				SELECT *
				FROM dbo.ProjectHelathEntryResult
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'RED'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+2)	
			)
		INSERT INTO ##Temp_AVGAMT
		SELECT (CTE_FLRED.[RED-N/13&12&23ROWS-TR] + ':' + CTE_FLINC.[RED-N/13&12&23ROWS-TR]) AVGAMT
		FROM CTE_FLINC join CTE_FLRED
		on CTE_FLINC.ITEM_NO = CTE_FLRED.ITEM_NO

		--select * from ##Temp_AVGAMT

		INSERT INTO ##Temp_AVGAMT
				SELECT SUBSTRING(AVGAMT,1,CHARINDEX(':',AVGAMT)-1)
				FROM ##TEMP_AVGAMT
				UNION
				SELECT SUBSTRING(AVGAMT,CHARINDEX(':',AVGAMT)+ 1, LEN(AVGAMT))
				FROM ##TEMP_AVGAMT

				DELETE TOP(1) FROM ##TEMP_AVGAMT
				DELETE TOP(1) FROM ##TEMP_AVGAMT

				IF OBJECT_ID('tempdb..##Temp_AVGAMTN') IS NOT NULL
				DROP TABLE ##Temp_AVGAMTN
				SELECT ROW_NUMBER() OVER(ORDER BY AVGAMT ASC) ID,
						AVGAMT
				INTO ##Temp_AVGAMTN
				FROM ##Temp_AVGAMT

				IF OBJECT_ID('tempdb..##Temp_AVGAMTNW') IS NOT NULL
				DROP TABLE ##Temp_AVGAMTNW

				SELECT AVGAMT
				INTO ##Temp_AVGAMTNW
				FROM ##Temp_AVGAMTN
				WHERE 1=2

				IF(SELECT COUNT(*) FROM ##TEMP_AVGAMTN WHERE AVGAMT LIKE 'FL%')>0
				BEGIN
					IF(select COUNT(*) from ##Temp_AVGAMTN where AVGAMT LIKE 'UP%')>0
					BEGIN
						INSERT INTO ##Temp_AVGAMTNW 
						select AVGAMT from ##Temp_AVGAMTN where AVGAMT LIKE 'FL%' 

						INSERT INTO ##Temp_AVGAMTNW 
						SELECT 'UP/' + (select CAST( CONVERT(NUMERIC(10,2),(SUM(CONVERT(NUMERIC(10,2),REPLACE(AVGAMT,'UP/',''))) )/COUNT(*)) AS VARCHAR(20))
						from ##Temp_AVGAMTN 
						where AVGAMT LIKE 'UP%')
					END
					IF (select COUNT(*) from ##Temp_AVGAMTN where AVGAMT LIKE 'DW%')>0
					BEGIN
						INSERT INTO ##Temp_AVGAMTNW 
						select AVGAMT from ##Temp_AVGAMTN where AVGAMT LIKE 'FL%' 

						INSERT INTO ##Temp_AVGAMTNW 
						SELECT 'DW/' + (select CAST( CONVERT(NUMERIC(10,2),(SUM(CONVERT(NUMERIC(10,2),REPLACE(AVGAMT,'DW/',''))) )/COUNT(*)) AS VARCHAR(20))
						from ##Temp_AVGAMTN 
						where AVGAMT LIKE 'DW%')
					END
				END

				--SELECT * FROM ##Temp_AVGAMTNW

				IF(( (SELECT COUNT(*) FROM ##Temp_AVGAMTNW WHERE AVGAMT LIKE 'UP%') > 0) AND ( (SELECT COUNT(*) FROM ##Temp_AVGAMTNW WHERE AVGAMT LIKE 'DW%') > 0))
				BEGIN
					DELETE FROM ##Temp_AVGAMTNW WHERE AVGAMT = 'FL'
				END
				SELECT * FROM ##Temp_AVGAMTNW order by AVGAMT asc

				/*
				SELECT COUNT(*) FROM ##Temp_AVGAMTN where AVGAMT LIKE 'DW%'

				IF(SELECT COUNT(*) FROM ##Temp_AVGAMTN where AVGAMT LIKE 'DW%')=3
				BEGIN
					
					DELETE TOP(1) FROM ##Temp_AVGAMTN
					INSERT INTO ##Temp_AVGAMTN values (5,'FL')
				END

				
				DECLARE @VAR1 VARCHAR(20),
						@VAR2 VARCHAR(20),
						@VAR3 VARCHAR(20),
						@VAR4 VARCHAR(20)

				SELECT TOP(1) @VAR1 = AVGAMT FROM ##Temp_AVGAMTN ORDER BY ID ASC
				SELECT TOP(2) @VAR2 = AVGAMT FROM ##Temp_AVGAMTN ORDER BY ID ASC
				SELECT TOP(3) @VAR3 = AVGAMT FROM ##Temp_AVGAMTN ORDER BY ID ASC
				SELECT TOP(4) @VAR4 = AVGAMT FROM ##Temp_AVGAMTN ORDER BY ID ASC

				PRINT @VAR1 + @VAR2 + @VAR3 + @VAR4
				
				select ISNULL((SELECT CASE WHEN @VAR1 LIKE 'DW%' AND @VAR2 LIKE 'DW%'
							THEN 'DW/' + CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(@VAR1,'DW/','')) + CONVERT(NUMERIC(10,2),REPLACE(@VAR2,'DW/','')))/2) AS VARCHAR(20))
							WHEN @VAR1 LIKE 'DW%' AND @VAR2 LIKE 'FL%'
							THEN @VAR1
							WHEN @VAR1 LIKE 'FL%' AND @VAR2 LIKE 'DW%'
							THEN @VAR2
						END),'FL')
				select ISNULL((SELECT CASE WHEN @VAR3 LIKE 'UP%' AND @VAR4 LIKE 'UP%'
							THEN 'UP/' + CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(@VAR3,'UP/','')) + CONVERT(NUMERIC(10,2),REPLACE(@VAR4,'UP/','')))/2) AS VARCHAR(20))
							WHEN @VAR3 LIKE 'UP%' AND @VAR4 LIKE 'FL%'
							THEN @VAR3
							WHEN @VAR3 LIKE 'FL%' AND @VAR4 LIKE 'UP%'
							THEN @VAR4
						END
						),'FL')
*/
