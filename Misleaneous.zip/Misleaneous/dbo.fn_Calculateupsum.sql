ALTER FUNCTION dbo.fn_Calculateupsum
(
	@ITEMNO VARCHAR(50)
)
RETURNS NUMERIC(10,2) 
AS 
BEGIN
	Declare @VarSum numeric(10,2) = 0.00
	
	select @VarSum = CASE WHEN @ITEMNO like '%U'
				THEN  (SELECT sum(convert(numeric(10,2),[UP/SUM])) from dbo.ProjectHelathEntryResult where ITEM_NO in (CONVERT(SMALLINT,REPLACE(@ITEMNO,'U',''))))
				ELSE (SELECT sum(convert(numeric(10,2),[DW/SUM])) from dbo.ProjectHelathEntryResult where ITEM_NO in (CONVERT(SMALLINT,REPLACE(@ITEMNO,'D',''))))
		END

	Return  @VarSum
END