
Declare @Var_03Red INT = 0,
				@Var_03INC	INT = 0,
				@Var_05Red	INT = 0,
				@Var_05Inc	INT = 0,
				@Var_10Red	INT = 0,
				@Var_10Inc	INT = 0,
				@VarUd1R		NUMERIC(10,2) = 0.00,
				@VarUd2R		NUMERIC(10,2) = 0.00,
				@VarUd3R		NUMERIC(10,2) = 0.00,
				@VarUd1I		NUMERIC(10,2) = 0.00,
				@VarUd2I		NUMERIC(10,2) = 0.00,
				@VarUd3I		NUMERIC(10,2) = 0.00,
				@Var_ITEM_NO	INT,
				@Minnoofcells	INT = 3


		IF OBJECT_ID('tempdb..##Temp_ITEMNOC4') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC4

		SELECT DISTINCT ITEM_NO
		INTO ##Temp_ITEMNOC4
		FROM ProjectHelathEntry

		--WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC4)>0
		--BEGIN

			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC4

			SELECT TOP(1) @Var_03Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' ORDER BY ID asc
			SELECT TOP(1) @Var_03INC = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' ORDER BY ID asc

			
			SELECT TOP(1) @Var_10Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' order by Id desc
			SELECT TOP(1) @Var_10Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' order by Id desc

			SELECT @Var_05Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = (@Var_10Red-@Var_03Red)
			SELECT @Var_05Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and id = ((@Var_10Inc-@Var_03INC) + 3)

			-- ud1, ud2, ud3

			SELECT @VarUd1R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_03Red
			SELECT @VarUd1I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_03INC
			SELECT @VarUd2R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_05Red
			SELECT @VarUd2I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_05Inc
			SELECT @VarUd3R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_10Red
			SELECT @VarUd3I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_10Inc
			
			print '@Var_03Red -->' + cast(@Var_03Red as varchar(10)) + '@Var_05Red -->' + cast(@Var_05Red as varchar(10)) + '@Var_10Red -->' + cast(@Var_10Red as varchar(10))
			print '@Var_03INC -->' + cast(@Var_03INC as varchar(10)) + '@Var_05Inc -->' + cast(@Var_05Inc as varchar(10)) + '@Var_10Inc -->' + cast(@Var_10Inc as varchar(10))

			PRINT '@VarUd1R-->' + CAST(@VarUd1R AS VARCHAR(10)) + '@VarUd2R-->' + CAST(@VarUd2R AS VARCHAR(10)) + '@VarUd3R-->' + CAST(@VarUd3R AS VARCHAR(10))
			PRINT '@VarUd1I-->' + CAST(@VarUd1I AS VARCHAR(10)) + '@VarUd2I-->' + CAST(@VarUd2I AS VARCHAR(10)) + '@VarUd3I-->' + CAST(@VarUd3I AS VARCHAR(10))
			 
			-- for 0.03
			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@PPRNGUD=@VarUd1R, @NoOfCells= @Minnoofcells
			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@PPRNGUD = @VarUd1I, @NoOfCells= @Minnoofcells

			-- for 0.05
			
			select @Minnoofcells = (CASE WHEN ISNULL(Res1,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res2,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res3,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res4,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res5,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res6,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res7,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res8,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res9,0) = 0 THEN 0 ELSE 1 END) 
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = @Var_03Red

			SET @Minnoofcells = @Minnoofcells + 1
			update dbo.ProjectHelathEntryResult
			set
				[MinNoOfCells] = @Minnoofcells
			where @Var_ITEM_NO = @Var_ITEM_NO and Id=@Var_05Red and [RED/INC] = 'RED'

			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@PPRNGUD = @VarUd2R, @NoOfCells= @Minnoofcells

			select @Minnoofcells = (CASE WHEN ISNULL(Res1,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res2,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res3,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res4,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res5,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res6,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res7,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res8,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res9,0) = 0 THEN 0 ELSE 1 END) 
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id = @Var_03INC

			SET @Minnoofcells = @Minnoofcells + 1
			update dbo.ProjectHelathEntryResult
			set
				[MinNoOfCells] = @Minnoofcells
			where @Var_ITEM_NO = @Var_ITEM_NO and id=@Var_05Inc and [RED/INC] = 'INC'

			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@PPRNGUD =@VarUd2I, @NoOfCells= @Minnoofcells
			

			-- for 0.10
			select @Minnoofcells = (CASE WHEN ISNULL(Res1,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res2,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res3,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res4,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res5,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res6,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res7,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res8,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res9,0) = 0 THEN 0 ELSE 1 END) 
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id=@Var_05Red

			SET @Minnoofcells = @Minnoofcells + 1
			update dbo.ProjectHelathEntryResult
			set
				[MinNoOfCells] = @Minnoofcells
			where @Var_ITEM_NO = @Var_ITEM_NO and Id=@Var_10Red and [RED/INC] = 'RED'
			--SET @Minnoofcells = @Minnoofcells + 1

			EXEC SP_ProjectHealthP1_Recur @Var_ITEM_NO = @Var_ITEM_NO,@PPRNGUD = @VarUd3R, @NoOfCells= @Minnoofcells

			select @Minnoofcells = (CASE WHEN ISNULL(Res1,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res2,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res3,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res4,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res5,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res6,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res7,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res8,0) = 0 THEN 0 ELSE 1 END) +
									(CASE WHEN ISNULL(Res9,0) = 0 THEN 0 ELSE 1 END) 
				from dbo.ProjectHelathEntryResult
				where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id=@Var_05Inc

			SET @Minnoofcells = @Minnoofcells + 1
			update dbo.ProjectHelathEntryResult
			set
				[MinNoOfCells] = @Minnoofcells
			where @Var_ITEM_NO = @Var_ITEM_NO and Id=@Var_10Inc and [RED/INC] = 'INC'
			--SET @Minnoofcells = @Minnoofcells + 1

			EXEC SP_ProjectHealthP1_RecurINC @Var_ITEM_NO = @Var_ITEM_NO,@PPRNGUD = @VarUd3I, @NoOfCells= @Minnoofcells

			DELETE TOP(1) FROM ##Temp_ITEMNOC4
		--END


		