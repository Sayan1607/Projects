ALTER PROCEDURE dbo.SP_C_PERCENTAGE
AS
BEGIN
	TRUNCATE TABLE dbo.ExportSummary
	;WITH CTE_UD1_TOT AS
	(
	SELECT [RED/INC],
							UD1,
							NULL AS UD2,
							NULL AS UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD1=0.03)))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL'
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C'
					GROUP BY [RED/INC],
							UD1
	),

		CTE_UD2_TOT AS
		(
			SELECT [RED/INC],
									NULL AS UD1,
									UD2,
									NULL AS UD3,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD2=0.05)))*100 AS varchar(10)) +'%' AS TOT,
									NULL AS '3/COL' 
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/TOT] = 'C'
							GROUP BY [RED/INC],
									UD2
		),

		CTE_UD3_TOT AS
		(
			SELECT [RED/INC],
									NULL AS UD1,
									NULL AS UD2,
									UD3,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD3=0.10)))*100 AS varchar(10)) +'%' AS TOT,
									NULL AS '3/COL'
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/TOT] = 'C'
							GROUP BY [RED/INC],
									UD3
		),

		CTE_RED_SUB_TOT AS
		(
			SELECT 'RED-SUBT' AS [RED-SUBT],
									NULL AS UD1,
									NULL AS UD2,
									NULL UD3,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'RED')))*100 AS varchar(10)) +'%' AS TOT,
									NULL AS '3/COL' 
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/TOT] = 'C' and [RED/INC] = 'RED'
							GROUP BY [RED/INC]
		),

		CTE_3COL_UD1 AS
		(
			SELECT [RED/INC],
									UD1,
									NULL AS UD2,
									NULL AS UD3,
									NULL AS TOT,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD1=0.03)))*100 AS varchar(10)) +'%' AS '3/COL' 
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/3COL] = 'C'
							GROUP BY [RED/INC],
									UD1
		),

		CTE_3COL_UD2 AS
		(
			SELECT [RED/INC],
									NULL AS UD1,
									UD2,
									NULL AS UD3,
									NULL AS TOT,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD2=0.05)))*100 AS varchar(10)) +'%' AS '3/COL'  
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/3COL] = 'C'
							GROUP BY [RED/INC],
									UD2
		),

		CTE_3COL_UD3 AS
		(
			SELECT [RED/INC],
									NULL AS UD1,
									NULL AS UD2,
									UD3,
									NULL AS TOT,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD3=0.10)))*100 AS varchar(10)) +'%' AS '3/COL'  
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/3COL] = 'C'
							GROUP BY [RED/INC],
									UD3
		),
		CTE_INC_SUB_TOT AS
		(
			SELECT 'INC-SUBT' AS [INC-SUBT],
									NULL AS UD1,
									NULL AS UD2,
									NULL UD3,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'INC')))*100 AS varchar(10)) +'%' AS TOT,
									NULL AS '3/COL' 
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/TOT] = 'C' and [RED/INC] = 'INC'
							GROUP BY [RED/INC]
		),

		CTE_3COL_RED_SUB_TOTAL AS 
		(
			SELECT '3COL-RED-SUBT' AS [3COL-RED-SUBT],
									NULL AS UD1,
									NULL AS UD2,
									NULL UD3,
									NULL AS TOT,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'RED')))*100 AS varchar(10)) +'%' AS '3/COL'  
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/3COL] = 'C' and [RED/INC] = 'RED'
							GROUP BY [RED/INC]
		),

		CTE_3COL_INC_SUB_TOTAL AS 
		(
			SELECT '3COL-INC-SUBT' AS [3COL-INC-SUBT],
									NULL AS UD1,
									NULL AS UD2,
									NULL UD3,
									NULL AS TOT,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'INC')))*100 AS varchar(10)) +'%' AS '3/COL'  
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/3COL] = 'C' and [RED/INC] = 'INC'
							GROUP BY [RED/INC]
		),

		CTE_TOTAL_RED_INC AS
		(
			SELECT 'FULL-TOT' AS [FULL-TOT],
									NULL AS UD1,
									NULL AS UD2,
									NULL UD3,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult)))*100 AS varchar(10)) +'%' AS TOT,
									NULL AS '3/COL' 
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/TOT] = 'C'
		),

		CTE_3COL_TOTAL_RED_INC AS
		(
			SELECT 'FULL-TOT-3COL' AS [FULL-TOT-3COL],
									NULL AS UD1,
									NULL AS UD2,
									NULL UD3,
									NULL AS TOT,
									CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult)))*100 AS varchar(10)) +'%' AS '3/COL'  
							from dbo.ProjectHelathEntryResult
							WHERE [ACC/3COL] = 'C'
		)

		INSERT INTO dbo.ExportSummary
		select Result.[RED/INC],
				Result.[.03/AC3],
				Result.[.05/ACT],
				Result.[.1/ACT],
				Result.[.03/AC3],
				Result.[.5/AC3],
				Result.[.1/AC3],
				Result.TOTAL
		from 
		(
					SELECT a.[RED/INC],
							CTE_UD1_TOT.TOT as '.03/ACT',
							CTE_UD2_TOT.TOT as '.05/ACT',
							CTE_UD3_TOT.TOT as '.1/ACT',
							CTE_3COL_UD1.[3/COL] as '.03/AC3',
							CTE_3COL_UD2.[3/COL] as '.5/AC3',
							CTE_3COL_UD3.[3/COL] AS '.1/AC3',
							NULL AS 'TOTAL'
					FROM dbo.ProjectHelathEntryResult A join CTE_UD1_TOT
					ON a.[RED/INC] = CTE_UD1_TOT.[RED/INC]
					and a.UD1 = CTE_UD1_TOT.UD1
					join CTE_UD2_TOT
					on a.[RED/INC] = CTE_UD2_TOT.[RED/INC]
					and a.UD2 = CTE_UD2_TOT.UD2
					join CTE_UD3_TOT
					on a.[RED/INC] = CTE_UD3_TOT.[RED/INC]
					and a.UD3 = CTE_UD3_TOT.UD3
					JOIN CTE_3COL_UD1
					ON A.[RED/INC] = CTE_3COL_UD1.[RED/INC]
					AND A.UD1 = CTE_3COL_UD1.UD1
					JOIN CTE_3COL_UD2
					ON a.[RED/INC] = CTE_3COL_UD2.[RED/INC]
					and a.UD2 = CTE_3COL_UD2.UD2
					JOIN CTE_3COL_UD3
					ON a.[RED/INC] = CTE_3COL_UD3.[RED/INC]
					and a.UD3 = CTE_3COL_UD3.UD3
					group by a.[RED/INC],
							CTE_UD1_TOT.TOT,
							CTE_UD2_TOT.TOT,
							CTE_UD3_TOT.TOT,
							CTE_3COL_UD1.[3/COL],
							CTE_3COL_UD2.[3/COL],
							CTE_3COL_UD3.[3/COL] 

					UNION

					SELECT [RED-SUBT],
							NULL,
							NULL,
							NULL,
							null,
							null,
							NULL,
							TOT AS TOTAL
					from CTE_RED_SUB_TOT

					UNION

					SELECT [INC-SUBT],
							NULL,
							NULL,
							NULL,
							null,
							null,
							NULL,
							TOT AS TOTAL
					from CTE_INC_SUB_TOT

					UNION

					SELECT [3COL-RED-SUBT],
							NULL,
							NULL,
							NULL,
							null,
							null,
							NULL,
							[3/col] AS TOTAL
					FROM CTE_3COL_RED_SUB_TOTAL

					UNION

					SELECT [3COL-INC-SUBT],
							NULL,
							NULL,
							NULL,
							null,
							null,
							NULL,
							[3/col] AS TOTAL
					FROM CTE_3COL_INC_SUB_TOTAL

					UNION

					SELECT [FULL-TOT],
							NULL,
							NULL,
							NULL,
							null,
							null,
							NULL,
							TOT AS TOTAL
					FROM CTE_TOTAL_RED_INC

					UNION
			
					SELECT [FULL-TOT-3COL],
							NULL,
							NULL,
							NULL,
							null,
							null,
							NULL,
							[3/COL] AS TOTAL
					FROM CTE_3COL_TOTAL_RED_INC

		) Result
		order by (case when Result.[RED/INC]='FULL-TOT' THEN 20 when Result.[RED/INC]='FULL-TOT-3COL' THEN 21 ELSE LEN(Result.[RED/INC]) END) asc

END
