ALTER FUNCTION dbo.fn_FinalCountPN(@T_CNTPN varchar(50))
returnS int
AS
BEGIN
	declare @P_Cnt int =0,
			@N_Cnt int = 0

	SET @P_Cnt = substring(@T_CNTPN,2,CHARINDEX('/',@T_CNTPN)-2)
	SET @N_Cnt = substring(@T_CNTPN,CHARINDEX('/',@T_CNTPN)+1,(CHARINDEX(']',@T_CNTPN)-(CHARINDEX('/',@T_CNTPN)+1)))
			
	return case when @P_Cnt>@N_Cnt
						then 1
				when @P_Cnt = @N_Cnt
					then 2
				else 0
				end
END