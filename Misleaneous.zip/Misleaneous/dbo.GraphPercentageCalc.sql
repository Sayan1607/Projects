
CREATE TABLE dbo.GraphPercentageCalc
(
	[RED/INC] nchar(3) NOT NULL,
	C_Count		INT NULL,
	W_Count		INT NULL
)
