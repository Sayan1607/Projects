ALTER PROCEDURE dbo.SP_UpdateHealthDataINC 

	@PPRNGUD numeric(10,2)

AS
BEGIN

SET NOCOUNT ON; 
Declare @Var_ITEM_NO INT,
		@FinalCtr INT = 0,
		@FinalCtrnGT INT = 0,
		@Cntr1 INT = 0,
		@Cntr2 INT= 0,
		@Cntr3 INT= 0,
		@Cntr4 INT= 0,
		@Cntr5 INT= 0,
		@Cntr6 INT= 0,
		@Cntr7 INT= 0,
		@Cntr8 INT= 0,
		@Cntr9 INT= 0,
		@P3Ctr INT =0,
		@N3CTR	INT =0

IF OBJECT_ID('tempdb..##Temp_ITEMNOGAPLMT') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOGAPLMT

		SELECT DISTINCT ITEM_NO
		INTO ##Temp_ITEMNOGAPLMT
		FROM ProjectHelathEntry

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOGAPLMT)>0
		BEGIN
				select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNOGAPLMT

				IF OBJECT_ID('tempdb..##Temp_ITEMNOGAPLMTINTM') IS NOT NULL
				DROP TABLE ##Temp_ITEMNOGAPLMTINTM

				IF OBJECT_ID('tempdb..##TEMP_ITEMNOGAPLMTINTMAGGRT') IS NOT NULL
				DROP TABLE ##TEMP_ITEMNOGAPLMTINTMAGGRT

				IF OBJECT_ID('tempdb..##Temp_Result') IS NOT NULL
				DROP TABLE ##Temp_Result

				;WITH CTE_GAPLMT
				AS
				(
					select [PRCL-IND],
							@PPRNGUD [PP-RNG-UD] ,
							[GAP-LMT],
							[330-IND],
							([PRCL-IND]-@PPRNGUD) AS LLMT,
							([PRCL-IND]+@PPRNGUD) AS HLMT,
							([330-IND]+[GAP-LMT]) as HGAPLMT,
							[RED/INC]
					from [dbo].[ProjectHelathEntryResult]
					where [ITEM_NO] in (@Var_ITEM_NO)
					and [RED/INC]= 'INC'
					and [PP-RNG-UD] = @PPRNGUD
				)

					select @Var_ITEM_NO as ITEM_NO ,
							[PP-CL] AS [PP-CL],
							CONVERT(NUMERIC(10,2),[PP-IRES]) AS [PP-IRES],
							(SELECT [RED/INC] FROM CTE_GAPLMT) AS [RED/INC]
					INTO ##Temp_ITEMNOGAPLMTINTM
					from [dbo].[PP-FILE]
					where [PP-OP] between (SELECT LLMT FROM CTE_GAPLMT) and (SELECT HLMT FROM CTE_GAPLMT)
					AND [PP-CL]  BETWEEN (SELECT [330-IND] FROM CTE_GAPLMT) AND (SELECT HGAPLMT FROM CTE_GAPLMT)
					AND ISNUMERIC([PP-IRES]) = 1
					order by [PP-CL] ASC

					select ITEM_NO,
							[RED/INC],
					max([PP-CL]) as [MPP-CL] , 
					min ([PP-CL]) as [MINPP-CL]
					into ##TEMP_ITEMNOGAPLMTINTMAGGRT
					from ##Temp_ITEMNOGAPLMTINTM
					group by ITEM_NO,
							[RED/INC]

					update A
					SET 
						A.LIND = b.[MINPP-CL],
						A.MIND = b.[MPP-CL],
						A.[IND-GAP] = (b.[MPP-CL] -b.[MINPP-CL]) 
					FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
					on A.ITEM_NO = b.ITEM_NO
					and A.[RED/INC] = B.[RED/INC]
					and A.[PP-RNG-UD] = @PPRNGUD
					--select * from ##Temp_ITEMNOGAPLMTINTM

					Declare @varCnt int = 9
					select convert(numeric(10,2),00000000.00) as rs into ##Temp_Result
					delete from ##Temp_Result

					while(select (@varCnt- count(*)) from ##Temp_ITEMNOGAPLMTINTM)>0
					begin
						insert into ##Temp_Result
						select NULL as rs
						set @varCnt = @varCnt-1
					end
					while(select count(*) from ##Temp_ITEMNOGAPLMTINTM)>0
					begin
						insert into ##Temp_Result
						select top(1)[PP-IRES] as rs from ##Temp_ITEMNOGAPLMTINTM order by [PP-CL] asc, [PP-IRES] desc
						
						delete top(1) from ##Temp_ITEMNOGAPLMTINTM where [PP-CL] in (select top(1)[PP-CL] as rs from ##Temp_ITEMNOGAPLMTINTM order by [PP-CL] asc)
						and [PP-IRES] in (select rs from ##Temp_Result)
					end
					--select * from ##Temp_Result

					
					 update A
							SET 
								A.Res9 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res8 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res7 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							AND A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res6 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res5 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res4 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res3 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res2 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					delete top(1) from ##Temp_Result
					update A
							SET 
								A.Res1 = (select top(1)rs from ##Temp_Result)
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
					
					SELECT @Cntr1= case when A.Res1 > 0
								Then 1
								else 0 
							end,
						   @Cntr2= case when A.Res2 > 0
								Then 1
								else 0 
							end,
						 @Cntr3= case when A.Res3 > 0
								Then 1
								else 0 
							end,
						@Cntr4= case when A.Res4 > 0
								Then 1
								else 0 
							end,
						@Cntr5= case when A.Res5 > 0
								Then 1
								else 0 
							end,
						@Cntr6= case when A.Res6 > 0
								Then 1
								else 0 
							end,
						@Cntr7= case when A.Res7 > 0
								Then 1
								else 0 
							end,
						@Cntr8= case when A.Res8 > 0
								Then 1
								else 0 
							end,
						@Cntr9= case when A.Res9 > 0
								Then 1
								else 0 
							end
					FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
				select @FinalCtr = (@Cntr1 + @Cntr2 + @Cntr3 + @Cntr4 + @Cntr5 + @Cntr6 + @Cntr7 + @Cntr8 + @Cntr9)
				--print '@FinalCtr  --->' + cast(@FinalCtr as varchar(10))
				select @P3Ctr = (@Cntr1 + @Cntr2 + @Cntr3)

				SELECT @Cntr1= case when A.Res1 <= 0
								Then 1
								else 0 
							end,
						   @Cntr2= case when A.Res2 <= 0
								Then 1
								else 0 
							end,
						 @Cntr3= case when A.Res3 <= 0
								Then 1
								else 0 
							end,
						@Cntr4= case when A.Res4 <= 0
								Then 1
								else 0 
							end,
						@Cntr5= case when A.Res5 <= 0
								Then 1
								else 0 
							end,
						@Cntr6= case when A.Res6 <= 0
								Then 1
								else 0 
							end,
						@Cntr7= case when A.Res7 <= 0
								Then 1
								else 0 
							end,
						@Cntr8= case when A.Res8 <= 0
								Then 1
								else 0 
							end,
						@Cntr9= case when A.Res9 <= 0
								Then 1
								else 0 
							end
					FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD
				select @FinalCtrnGT = (@Cntr1 + @Cntr2 + @Cntr3 + @Cntr4 + @Cntr5 + @Cntr6 + @Cntr7 + @Cntr8 + @Cntr9)
				--print '@FinalCtrnGT  --->' + cast(@FinalCtrnGT as varchar(10))
				select @N3CTR = (@Cntr1 + @Cntr2 + @Cntr3 )

					update A
							SET 
								A.TOT = (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)),
								A.GREEN = CASE WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0
												THEN 'NEG'
												ELSE 'POS'
										  END,
								A.[ALL-CNT(P/N)] = '[' + cast(@FinalCtr as varchar(10)) + '/' + cast(@FinalCtrnGT as varchar(10)) + ']',
								A.ACC = CASE WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0 AND 
													A.IRES < 0 and @FinalCtrnGT > @FinalCtr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0 AND 
													A.IRES < 0 and @FinalCtrnGT < @FinalCtr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) > 0 AND 
													A.IRES > 0 and @FinalCtrnGT > @FinalCtr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) > 0 AND 
													A.IRES > 0 and @FinalCtrnGT < @FinalCtr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0 AND 
													A.IRES > 0 and @FinalCtrnGT > @FinalCtr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0 AND 
													A.IRES > 0 and @FinalCtrnGT < @FinalCtr
											THEN 'C'
											
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) > 0 AND 
													A.IRES < 0 and @FinalCtrnGT > @FinalCtr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) > 0 AND 
													A.IRES < 0 and @FinalCtrnGT <= @FinalCtr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0 AND 
													A.IRES > 0 and @FinalCtrnGT = @FinalCtr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) > 0 AND 
													A.IRES > 0 and @FinalCtrnGT = @FinalCtr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) > 0 AND 
													A.IRES < 0 and @FinalCtrnGT = @FinalCtr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) < 0 AND 
													A.IRES < 0 and @FinalCtrnGT = @FinalCtr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0) + ISNULL(a.Res4,0) + ISNULL(a.Res5,0) + ISNULL(a.Res6,0) + ISNULL(a.Res7,0) + ISNULL(a.Res8,0) + ISNULL(a.Res9,0)) =0
											THEN 'NV'
											ELSE 'W'
										END,
								A.[3COL/NET] = (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)),
								A.[ACC/3COL] = CASE WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) < 0 AND 
													A.IRES < 0 and @N3CTR > @P3Ctr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) < 0 AND 
													A.IRES < 0 and @N3CTR < @P3Ctr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) > 0 AND 
													A.IRES > 0 and @N3CTR > @P3Ctr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) > 0 AND 
													A.IRES > 0 and @N3CTR < @P3Ctr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) < 0 AND 
													A.IRES > 0 and @N3CTR > @P3Ctr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) < 0 AND 
													A.IRES > 0 and @N3CTR < @P3Ctr
											THEN 'C'
											
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) > 0 AND 
													A.IRES < 0 and @N3CTR > @P3Ctr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) > 0 AND 
													A.IRES < 0 and @N3CTR <= @P3Ctr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) < 0 AND 
													A.IRES > 0 and @N3CTR = @P3Ctr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) > 0 AND 
													A.IRES > 0 and @N3CTR = @P3Ctr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) > 0 AND 
													A.IRES < 0 and @N3CTR = @P3Ctr
											THEN 'W'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) < 0 AND 
													A.IRES < 0 and @N3CTR = @P3Ctr
											THEN 'C'
											WHEN (ISNULL(a.Res1,0) + ISNULL(a.Res2,0) + ISNULL(a.Res3,0)) =0
											THEN 'NV'
											ELSE 'W'
										END
							FROM [dbo].[ProjectHelathEntryResult] A join ##TEMP_ITEMNOGAPLMTINTMAGGRT B
							on A.ITEM_NO = b.ITEM_NO
							and A.[RED/INC] = B.[RED/INC]
							and A.[PP-RNG-UD] = @PPRNGUD

					DELETE TOP(1) FROM ##Temp_ITEMNOGAPLMT

		END


END		