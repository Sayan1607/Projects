ALTER PROCEDURE dbo.SP_ProjectHealthP1_Recur
(
	@Var_ITEM_NO INT,
	@Id INT,
	@NoOfCells INT 
)
AS
BEGIN
		Declare @ActResCntR INT = 0,
				@ActResNxtCntR	INT = 0,
				@var_PPRNGUD	NUMERIC(10,2)

			set @ActResCntR = 0
			set @ActResNxtCntR = 0
			

			select @ActResCntR = (case when Res1 IS NULL then 0 else 1 end 
				+ case when Res2 IS NULL then 0 else 1 end 
				+ case when Res3 IS NULL  then 0 else 1 end
				+ case when Res4 IS NULL  then 0 else 1 end
				+ case when Res5 IS NULL  then 0 else 1 end
				+ case when Res6 IS NULL  then 0 else 1 end 
				+ case when Res7 IS NULL  then 0 else 1 end
				+ case when Res8 IS NULL  then 0 else 1 end
				+ case when Res9 IS NULL  then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id

			IF(
				SELECT count(*)
				FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
				and UD2 in 
				(
					SELECT [PP-RNG-UD]
					FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
				)
				)>0
			
			BEGIN
					SELECT @var_PPRNGUD = [PP-RNG-UD]
					FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = (@Id-1)
					SET @var_PPRNGUD = @var_PPRNGUD + 0.01
			END
			ELSE
			BEGIN
						IF(
						SELECT count(*)
						FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
						and UD3 in 
						(
							SELECT [PP-RNG-UD]
							FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
						)
						)>0
			
					BEGIN
							SELECT @var_PPRNGUD = [PP-RNG-UD]
							FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = (@Id-1)
							SET @var_PPRNGUD = @var_PPRNGUD + 0.01
					END
					ELSE
					BEGIN
						SET @var_PPRNGUD = 0.01
					END
			END

			

			--print @var_PPRNGUD

			while(@ActResCntR<@NoOfCells)
			begin
				if(@var_PPRNGUD<=15)
				begin
					EXEC dbo.SP_UpdateHealthDataREC @PPRNGUD = @var_PPRNGUD,@ID=@Id, @Var_ITEMNO = @Var_ITEM_NO

					select @ActResNxtCntR = (case when Res1 IS NULL then 0 else 1 end 
					+ case when Res2 IS NULL then 0 else 1 end 
					+ case when Res3 IS NULL  then 0 else 1 end
					+ case when Res4 IS NULL  then 0 else 1 end
					+ case when Res5 IS NULL  then 0 else 1 end
					+ case when Res6 IS NULL  then 0 else 1 end 
					+ case when Res7 IS NULL  then 0 else 1 end
					+ case when Res8 IS NULL  then 0 else 1 end
					+ case when Res9 IS NULL  then 0 else 1 end     
					)
					from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
		
					set @ActResCntR = @ActResNxtCntR
					set @var_PPRNGUD = @var_PPRNGUD + 0.01
				end
				else
				begin
					break
				end
			end

			--select cast(@Var_ITEM_NO as varchar(10)) + ' : @varindPRCLRED-->' + cast(@varindPRCLRED as varchar(10))

			
			IF(@var_PPRNGUD>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResult
			SET
				[PP-RNG-UD] = @var_PPRNGUD - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
			end 
			ELSE IF(@var_PPRNGUD=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @var_PPRNGUD
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND Id = @Id
			end 
			

			
END