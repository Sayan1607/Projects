CREATE PROCEDURE SP_C_PERCENTAGE
AS
BEGIN
				;WITH CTE_UD1_TotalCW
				AS
				(
					SELECT ITEM_NO,
						UD1,
						[RED/INC],
						count([ACC/TOT]) Total_UD1_CW
						from dbo.ProjectHelathEntryResultP2
						GROUP BY ITEM_NO,UD1,
								[RED/INC]

				),
				CTE_UD2_TotalCW
				AS
				(
					SELECT ITEM_NO,
						UD2,
						[RED/INC],
						count([ACC/TOT]) Total_UD1_CW
						from dbo.ProjectHelathEntryResultP2
						GROUP BY ITEM_NO,UD2,
								[RED/INC]

				),
				CTE_UD3_TotalCW
				AS
				(
					SELECT ITEM_NO,
						UD3,
						[RED/INC],
						count([ACC/TOT]) Total_UD1_CW
						from dbo.ProjectHelathEntryResultP2
						GROUP BY ITEM_NO,UD3,
								[RED/INC]

				)
				SELECT RsltUD1.ITEM_NO,
						RsltUD1.UD1,
						RsltUD1.UD2,
						RsltUD1.UD3,
						RsltUD1.[RED/INC],
						cast(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),RsltUD1.C_CNT)/CONVERT(NUMERIC(10,2),CTE_UD1_TotalCW.Total_UD1_CW))*100) as varchar(50)) + '%' AS C_Percent
				FROM 
				(
					SELECT ITEM_NO,
							UD1,
							NULL AS UD2,
							NULL AS UD3,
							[RED/INC],
							count([ACC/TOT]) C_CNT
					from dbo.ProjectHelathEntryResultP2
					WHERE [ACC/TOT] = 'C'
					GROUP BY ITEM_NO,UD1,
							[RED/INC]
				)RsltUD1 join CTE_UD1_TotalCW
				on RsltUD1.ITEM_NO = CTE_UD1_TotalCW.ITEM_NO
				and RsltUD1.UD1 = CTE_UD1_TotalCW.UD1
				and RsltUD1.[RED/INC] = CTE_UD1_TotalCW.[RED/INC]

				UNION

				SELECT RsltUD2.ITEM_NO,
						RsltUD2.UD1,
						RsltUD2.UD2,
						RsltUD2.UD3,
						RsltUD2.[RED/INC],
						cast(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),RsltUD2.C_CNT)/CONVERT(NUMERIC(10,2),CTE_UD2_TotalCW.Total_UD1_CW))*100) as varchar(50)) + '%' AS C_Percent
				FROM 
				(
						select ITEM_NO,
								NULL AS UD1,
								UD2,
								NULL AS UD3,
								[RED/INC],
								count([RED/INC]) AS C_CNT
						from dbo.ProjectHelathEntryResultP2
						WHERE [ACC/TOT] = 'C'
						GROUP BY ITEM_NO,UD2,
								[RED/INC]
				)RsltUD2 join CTE_UD2_TotalCW
				on RsltUD2.ITEM_NO = CTE_UD2_TotalCW.ITEM_NO
				and RsltUD2.UD2 = CTE_UD2_TotalCW.UD2
				and RsltUD2.[RED/INC] = CTE_UD2_TotalCW.[RED/INC]

				UNION

				SELECT RsltUD3.ITEM_NO,
						RsltUD3.UD1,
						RsltUD3.UD2,
						RsltUD3.UD3,
						RsltUD3.[RED/INC],
						cast(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),RsltUD3.C_CNT)/CONVERT(NUMERIC(10,2),CTE_UD3_TotalCW.Total_UD1_CW))*100) as varchar(50)) + '%' AS C_Percent
				FROM 
				(
				select ITEM_NO,
						NULL AS UD1,
						NULL AS UD2,
						UD3,
						[RED/INC],
						count([RED/INC]) AS C_CNT
				from dbo.ProjectHelathEntryResultP2
				WHERE [ACC/TOT] = 'C'
				GROUP BY ITEM_NO,UD3,
						[RED/INC]
				)RsltUD3 join CTE_UD3_TotalCW
				on RsltUD3.ITEM_NO = CTE_UD3_TotalCW.ITEM_NO
				and RsltUD3.UD3 = CTE_UD3_TotalCW.UD3
				and RsltUD3.[RED/INC] = CTE_UD3_TotalCW.[RED/INC]

END



