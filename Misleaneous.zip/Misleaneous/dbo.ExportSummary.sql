
--drop table dbo.ExportSummary
--drop table dbo.ExportSummaryP2

--DROP TABLE dbo.ExportSummary3COL

--DROP TABLE dbo.ExportSummary3colP2


CREATE TABLE dbo.ExportSummary
(
	--[ITEM_NO]		INT NOT NULL,
	[RED/INC]		VARCHAR(50) NULL,
	[.03/ACT]		VARCHAR(50) NULL,
	[.05/ACT]		VARCHAR(50) NULL,
	[.1/ACT]		VARCHAR(50) NULL,
	[.03/AC3]		VARCHAR(50) NULL,
	[.5/AC3]		VARCHAR(50) NULL,
	[.1/AC3]		VARCHAR(50) NULL,
	TOT				VARCHAR(50) NULL
	--[3/COL]			CHAR(50) NULL
)



CREATE TABLE dbo.ExportSummaryP2
(
	--[ITEM_NO]		INT NOT NULL,
	[RED/INC]		VARCHAR(50) NULL,
	FLAG			NCHAR(50) NULL,
	TOT				CHAR(50) NULL,
	[3/COL]			CHAR(50) NULL,
	MinNoOfCells	INT NULL
)

/*
==============

CREATE TABLE dbo.ExportSummary3COL
(
	--[ITEM_NO]		INT NOT NULL,
	UD1				NUMERIC(10,2) NULL,
	UD2				NUMERIC(10,2) NULL,
	UD3				NUMERIC(10,2) NULL,
	[RED/INC]		VARCHAR(50) NULL,
	C_PERCENT		CHAR(50) NULL
)

CREATE TABLE dbo.ExportSummary3colP2
(
	--[ITEM_NO]		INT NOT NULL,
	UD1				NUMERIC(10,2) NULL,
	UD2				NUMERIC(10,2) NULL,
	UD3				NUMERIC(10,2) NULL,
	[RED/INC]		VARCHAR(50) NULL,
	C_PERCENT		CHAR(50) NULL
)

======================
*/

