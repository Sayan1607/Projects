
CREATE PROCEDURE SP_LoadFinalHealthData 
AS
BEGIN

/*
=====================================
Created On: 14-May-2021
Created By: Sayan Maity

=====================================
*/
insert into [dbo].[ProjectHelathEntryResult]
select  ITEM_NO,
	   	PRCL_IND  [PVCL-IND],
		[330_IND]  [330-IND],
		[S1C2],
		[UD1],
		NULL AS [L/H-IND-CNT1],
		[UD2],
		NULL AS [L/H-IND-CNT2],
		[UD3],
		NULL AS [L/H-IND-CNT3],
		[PRCL-NXTDCL-DIF],
		NULL AS [N/P-C2-CNT1],
		NULL AS [N/P-C2-CNT2],
		NULL AS [N/P-C2-CNT3],
		'RED' as [RED/INC],
		[UD1] as [PP-RNG-UD],
		[GAP_LIMIT],
		NULL AS [IND-GAP],
		NULL AS [LIND],
		NULL AS [MIND],
		NULL AS [Res9],
		NULL AS [Res8],
		NULL AS [Res7],
		NULL AS [Res6],
		NULL AS [Res5],
		NULL AS [Res4],
		NULL AS [Res3],
		NULL AS [Res2],
		NULL AS [Res1],
		NULL AS [TOT],
		NULL AS [ALL-CNT(P/N)],
		NULL AS [GREEN],
		NULL AS [ACC],
		NULL AS [COMM],
		[IRES]

from [dbo].[ProjectHelathEntry]

END
