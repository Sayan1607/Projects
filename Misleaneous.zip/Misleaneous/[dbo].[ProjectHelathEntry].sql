USE [ProjectHealth]
GO

DROP TABLE [dbo].[ProjectHelathEntry]

/****** Object:  Table [dbo].[ProjectHelathEntry]    Script Date: 14/05/2021 11:09:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProjectHelathEntry](
	[ITEM_NO] [int] NOT NULL,
	[PRCL_IND] [numeric](10, 2) NULL,
	[UD1] [numeric](10, 2) NULL,
	[UD2] [numeric](10, 2) NULL,
	[UD3] [numeric](10, 2) NULL,
	[UD4] [numeric](10, 2) NULL,
	[UD5] [numeric](10, 2) NULL,
	[UD6] [numeric](10, 2) NULL,
	[330_IND] [numeric](10, 2) NULL,
	[GAP_LIMIT] [int] NULL,
	[IRES] [numeric](10, 2) NULL,
	[S1C1] [numeric](10, 2) NULL,
	[S1C2] [numeric](10, 2) NULL,
	[S1C3] [numeric](10, 2) NULL,
	[NOR-LH/REV-LH[IF (LH-MINUS-SUM)] [numeric](10, 2) NULL,
	[PP-DATE]	NVARCHAR(20) NULL,
	[PRFIN-IND] [numeric](10, 2) NULL,
	[PP-DATE-NEW] AS (convert(char(10), convert(date,[PP-DATE]), 3)),
	[NoofCells]	INT NULL,
PRIMARY KEY CLUSTERED 
(
	[ITEM_NO] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


