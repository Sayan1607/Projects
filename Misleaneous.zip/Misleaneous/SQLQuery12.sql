USE [ProjectHealth]
GO

/****** Object:  StoredProcedure [dbo].[SP_LoadFinalHealthData]    Script Date: 14/05/2021 8:55:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER PROCEDURE [dbo].[SP_LoadFinalHealthData] 
AS
BEGIN

/*
=====================================
Created On: 14-May-2021
Created By: Sayan Maity

=====================================
*/



Declare @Var_ITEM_NO INT,
		@Var_PRCL_IND NUMERIC(10,2)

IF OBJECT_ID('tempdb..##Temp_ITEMNO') IS NOT NULL
DROP TABLE ##Temp_ITEMNO

SELECT DISTINCT ITEM_NO
INTO ##Temp_ITEMNO
FROM ProjectHelathEntry

WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNO)>0
BEGIN

select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNO
print @Var_ITEM_NO

select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

;WITH CTE_LHINDCNT1
AS
(
	select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
),

CTE_LHINDCNT2
AS
(
	select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
),
CTE_LHINDCNT3
AS
(
	select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
),
PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
),
CTE_C2LHINDCNT3
AS
(
	select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
)

	
	INSERT INTO [dbo].[ProjectHealth_Intermediary]
	select @Var_ITEM_NO, cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT1], 
	NULL as [L/H-IND-CNT2], 
	NULL AS [L/H-IND-CNT3]
	from CTE_LHINDCNT1
	union
	select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
	cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT2], 
	NULL AS [L/H-IND-CNT3]
	from CTE_LHINDCNT2
	union
	select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
	NULL AS [L/H-IND-CNT2] ,
	cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT3]
	from CTE_LHINDCNT3

	
	update [dbo].[ProjectHealth_Intermediary]
	set
		[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

		
	update [dbo].[ProjectHealth_Intermediary]
	set
		[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

	
	update [dbo].[ProjectHealth_Intermediary]
	set
		[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

	INSERT INTO [dbo].[ProjectHealth_IntermediaryC2]
	select @Var_ITEM_NO, cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT1], 
	NULL as [L/H-IND-CNT2], 
	NULL AS [L/H-IND-CNT3]
	from CTE_C2LHINDCNT1
	union
	select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
	cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT2], 
	NULL AS [L/H-IND-CNT3]
	from CTE_C2LHINDCNT2
	union
	select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
	NULL AS [L/H-IND-CNT2] ,
	cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT3]
	from CTE_C2LHINDCNT3

	
	update [dbo].[ProjectHealth_IntermediaryC2]
	set
		[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

		
	update [dbo].[ProjectHealth_IntermediaryC2]
	set
		[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

	
	update [dbo].[ProjectHealth_IntermediaryC2]
	set
		[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO



DELETE TOP(1) FROM ##Temp_ITEMNO
END


insert into [dbo].[ProjectHelathEntryResult]
select  A.ITEM_NO,
	   	PRCL_IND  [PVCL-IND],
		[330_IND]  [330-IND],
		[S1C2],
		[UD1],
		b.[L/H-IND-CNT1] AS [L/H-IND-CNT1],
		[UD2],
		b.[L/H-IND-CNT2] AS [L/H-IND-CNT2],
		[UD3],
		b.[L/H-IND-CNT3] AS [L/H-IND-CNT3],
		[PRCL-NXTDCL-DIF],
		NULL AS [N/P-C2-CNT1],
		NULL AS [N/P-C2-CNT2],
		NULL AS [N/P-C2-CNT3],
		'RED' as [RED/INC],
		[UD1] as [PP-RNG-UD],
		[GAP_LIMIT],
		NULL AS [IND-GAP],
		NULL AS [LIND],
		NULL AS [MIND],
		NULL AS [Res9],
		NULL AS [Res8],
		NULL AS [Res7],
		NULL AS [Res6],
		NULL AS [Res5],
		NULL AS [Res4],
		NULL AS [Res3],
		NULL AS [Res2],
		NULL AS [Res1],
		NULL AS [TOT],
		NULL AS [ALL-CNT(P/N)],
		NULL AS [GREEN],
		NULL AS [ACC],
		NULL AS [COMM],
		[IRES]

from [dbo].[ProjectHelathEntry] a join 
(SELECT DISTINCT [ITEM_NO]
      ,[L/H-IND-CNT1]
      ,[L/H-IND-CNT2]
      ,[L/H-IND-CNT3]
  FROM [dbo].[ProjectHealth_Intermediary]
  ) b
on a.ITEM_NO = b.[ITEM_NO]

END
GO


