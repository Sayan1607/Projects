--truncate table dbo.ProjectHelathEntryResult


--select * from [dbo].[ProjectHelathEntry]

--select * from dbo.ProjectHelathEntryResult 

----where ITEM_NO = 1056 and [RED/INC] = 'red' order by id asc

--select top(1) Id from dbo.ProjectHelathEntryResult where ITEM_NO = 1056 and [RED/INC] = 'red' order by id desc


Declare @Var_03Red INT = 0,
				@Var_03INC	INT = 0,
				@Var_05Red	INT = 0,
				@Var_05Inc	INT = 0,
				@Var_10Red	INT = 0,
				@Var_10Inc	INT = 0,
				@VarUd1R		NUMERIC(10,2) = 0.00,
				@VarUd2R		NUMERIC(10,2) = 0.00,
				@VarUd3R		NUMERIC(10,2) = 0.00,
				@VarUd1I		NUMERIC(10,2) = 0.00,
				@VarUd2I		NUMERIC(10,2) = 0.00,
				@VarUd3I		NUMERIC(10,2) = 0.00,
				@Var_ITEM_NO int = 1056

			SELECT TOP(1) @Var_03Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' ORDER BY ID asc
			SELECT TOP(1) @Var_03INC = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' ORDER BY ID asc

			
			SELECT TOP(1) @Var_10Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' order by Id desc
			SELECT TOP(1) @Var_10Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' order by Id desc

			SELECT @Var_05Red = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' and Id = (@Var_10Red-@Var_03Red)
			SELECT @Var_05Inc = Id from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' and Id = ((@Var_10Inc-@Var_03INC) + 3)

			print '@Var_03Red -->' + cast(@Var_03Red as varchar(10)) + '@Var_05Red -->' + cast(@Var_05Red as varchar(10)) + '@Var_10Red -->' + cast(@Var_10Red as varchar(10))
			
			print '@Var_03INC -->' + cast(@Var_03INC as varchar(10)) + '@Var_05Inc -->' + cast(@Var_05Inc as varchar(10)) + '@Var_10Inc -->' + cast(@Var_10Inc as varchar(10))
			 
			SELECT @VarUd1R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_03Red
			SELECT @VarUd1I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_03INC
			SELECT @VarUd2R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_05Red
			SELECT @VarUd2I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_05Inc
			SELECT @VarUd3R = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'RED' AND Id = @Var_10Red
			SELECT @VarUd3I = [PP-RNG-UD] from dbo.ProjectHelathEntryResult where ITEM_NO = @Var_ITEM_NO and [RED/INC] = 'INC' AND Id = @Var_10Inc

			PRINT '@VarUd1R-->' + CAST(@VarUd1R AS VARCHAR(10)) + '@VarUd2R-->' + CAST(@VarUd2R AS VARCHAR(10)) + '@VarUd3R-->' + CAST(@VarUd3R AS VARCHAR(10))
			PRINT '@VarUd1I-->' + CAST(@VarUd1I AS VARCHAR(10)) + '@VarUd2I-->' + CAST(@VarUd2I AS VARCHAR(10)) + '@VarUd3I-->' + CAST(@VarUd3I AS VARCHAR(10))
			 
