
ALTER PROCEDURE SP_PopulateProjectHealthEntry
AS
BEGIN
	

insert into [dbo].[ProjectHelathEntry]
select [PR-ITEM-NO],
		[PRCL-IND],
		0.03 as UD1,
		0.05 AS UD2,
		0.10 AS UD3,
		0.03 as UD4,
		0.05 AS UD5,
		0.10 AS UD6,
		[PR-330IND] AS [330_IND],
		1 AS [GAP_LIMIT],
		case when CHARINDEX('+', [PR-IRES]) =1
			then convert(numeric(10,2),('00000000' + LTRIM(RTRIM(Replace(Replace([PR-IRES],'+',''),',','.')))))
			else [PR-IRES]
		end  AS IRES,
		[PR-S1C1] AS S1C1,
		[PR-S1C2] AS S1C2,
		[PR-S1C3] AS S1C3,
		6 AS [NOR-LH/REV-LH[IF (LH-MINUS-SUM)],
		convert(char(10),[PR-DATE],126) AS [PP-DATE],
		[PRFIN-IND],
		1 AS [NoofCells]
from [dbo].[PR-FILE-V3]
WHERE [PRCL-IND] IS NOT NULL AND  convert(numeric(10,2),[PRCL-IND])<> 0
and [PR-IRES] is not null and ISNUMERIC([PR-IRES])=1
AND ISNUMERIC([PRFIN-IND])=1

END


