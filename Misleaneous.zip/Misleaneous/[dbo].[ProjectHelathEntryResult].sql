USE [ProjectHealth]
GO

DROP TABLE [dbo].[ProjectHelathEntryResult]

/****** Object:  Table [dbo].[ProjectHelathEntryResult]    Script Date: 14/05/2021 11:20:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProjectHelathEntryResult](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ITEM_NO] [int] NOT NULL,
	[PR-DATE] nchar(10) NULL,
	[PRCL-IND] [numeric](10, 2) NULL,
	[330-IND] [numeric](10, 2) NULL,
	[S1C2] [numeric](10, 2) NULL,
	[UD1] [numeric](10, 2) NULL,
	[PRCL/PRCL-IND-CNT1] [nchar](10) NULL,
	[UD2] [numeric](10, 2) NULL,
	[PRCL/PRCL-IND-CNT2] [nchar](10) NULL,
	[UD3] [numeric](10, 2) NULL,
	[PRCL/PRCL-IND-CNT3] [nchar](10) NULL,
	--[PRCL-NXTDCL-DIF] [nchar](10) NULL,
	[PRCL/C2-CNT1] [nchar](10) NULL,
	[PRCL/C2-CNT2] [nchar](10) NULL,
	[PRCL/C3-CNT3] [nchar](10) NULL,
	[RED/INC] [NCHAR](3) NULL,
	[PP-RNG-UD] [nchar](10) NULL,
	[GAP-LMT] [int] NOT NULL,
	[IND-GAP] [numeric](10, 2) NULL,
	[LIND] [numeric](10, 2) NULL,
	[MIND] [numeric](10, 2) NULL,
	[Res9] [numeric](10, 2) NULL,
	[Res8] [numeric](10, 2) NULL,
	[Res7] [numeric](10, 2) NULL,
	[Res6] [numeric](10, 2) NULL,
	[Res5] [numeric](10, 2) NULL,
	[Res4] [numeric](10, 2) NULL,
	[Res3] [numeric](10, 2) NULL,
	[Res2] [numeric](10, 2) NULL,
	[Res1] [numeric](10, 2) NULL,
	[TOT] [numeric](10, 2) NULL,
	[ALL-CNT(P/N)] [nchar](10) NULL,
	[GREEN] [nchar](10) NULL,
	[ACC/TOT] [nchar](3) NULL,
	[3COL/NET] [numeric](10, 2) NULL,
	[ACC/3COL][nchar](3) NULL,
	[COMM] [nvarchar](max) NULL,
	[IRES] [numeric](10, 2) NULL,
	[PRFIN-IND] [numeric](10, 2) NULL,
	[PRCL/330IND-R1-C] [nchar](10) NULL,
	[PRCL/330IND-R2-C] [nchar](10) NULL,
	[PRCL/330IND-R3-C] [nchar](10) NULL,
	[PR-S1C1] [numeric](10, 2) NULL,
	[PR-S1C2] [numeric](10, 2) NULL,
	[PR-S1C3] [numeric](10, 2) NULL,
	[MinNoOfCells] [INT] NULL,
	[2COL/NET]	[numeric](10, 2) NULL,
	[4COL/NET]	[numeric](10, 2) NULL,
	[3COL/ST/ALIGNED]	char(3) NULL,
	[3COL/ST/GAP]	[numeric](10, 2) NULL,
	[S1/LH/CNT/SUM]	INT NULL,
	[S2/LH/CNT/SUM]	INT NULL,
	[S3/LH/CNT/SUM] INT NULL,
	[LH-MINUS-SUM/S1+S2+S3(ADD ONLY MINUSES, ELSE 0)] INT NULL,
	[NO-OF-Ls/NO-OF-Hs]	NCHAR(50) NULL,
	[PP-PRCL-PPOP/33IND-PPCL/NET-AVG] NUMERIC(10,2) NULL,
	[ACC/X]	CHAR(1) NULL,
	[RED/AVG-POS]   NUMERIC(10,2) NULL,
	[RED/AVG-NEG]   NUMERIC(10,2) NULL,
	[RED-P/13&12&23ROWS-TR]  NVARCHAR(50) NULL,
	[RED-N/13&12&23ROWS-TR]  NVARCHAR(50) NULL,
	[UP/SUM] NVARCHAR(50) NULL,
	[DW/SUM] NVARCHAR(50) NULL,
	[UP/CNT] NVARCHAR(20) NULL,
	[DW/CNT] NVARCHAR(20) NULL,
	[13&12&23/UP/CNT] NVARCHAR(20) NULL,
	[13&12&23/ DW/CNT] NVARCHAR(20) NULL,
	[UP/AMT-AVG] NVARCHAR(20) NULL,
	[DW/AMT-AVG] NVARCHAR(20) NULL,
	[ACC] CHAR(1) NULL,
	[DIFF/330IN-PRCL]  NUMERIC(10,2) NULL,
	[PP-PRCL-PPCL/DIF(OP-CL)/UD] NVARCHAR(50) NULL,
	[NET-AVG] NVARCHAR(20) NULL,
	[TR]  NVARCHAR(50) NULL,
	[PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD]  NUMERIC(10,2) NULL,
	[PP-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/NXT-UD] NUMERIC(10,2) NULL,
	[PP-PDCLST/NXT/NET-AVG]  NVARCHAR(20) NULL,
	[ACC/PPDFN] CHAR(1) NULL,
	[TR/DIF-DIF]  NUMERIC(10,2) NULL,
	[ACC/TR] CHAR(1) NULL,
	[PR-PRCL-PPCL(CLST-RNG)/DIF(OP-CL)/UD]  NUMERIC(10,2) NULL,
	[PR-PRCL-DIF/NET-AVG]  NVARCHAR(50) NULL,
	[ACC/PR/PD] CHAR(1) NULL,
	[ACC/PRCL-DIF] CHAR(1) NULL

PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


