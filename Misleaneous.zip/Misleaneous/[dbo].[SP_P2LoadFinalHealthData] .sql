USE [ProjectHealth]
GO

/****** Object:  StoredProcedure [dbo].[SP_LoadFinalHealthData]    Script Date: 14/05/2021 8:55:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER PROCEDURE [dbo].[SP_P2LoadFinalHealthData] 
(
	@NoOfCells INT
	--@ITEM_NO INT
)
AS
BEGIN
		--DECLARE @NoOfCells INT = 4
		/* 
		=====================================
		Created On: 14-May-2021
		Created By: Sayan Maity

		=====================================
		*/

		-- Truncate all Temp table as well as the resultset

		TRUNCATE TABLE [dbo].[ProjectHealth_Intermediary]

		TRUNCATE TABLE [dbo].[ProjectHealth_IntermediaryC2]

		TRUNCATE TABLE [dbo].[ProjectHealth_IntermediaryC3]
		
		--IF OBJECT_ID('tempdb..##Temp_ProjectHelathEntryResult') IS NOT NULL
		--	DROP TABLE ##Temp_ProjectHelathEntryResult

			--select * 
			--into ##Temp_ProjectHelathEntryResult 
			--from [dbo].[ProjectHelathEntryResult]
		/*	
		if(select count(*)
			from [dbo].[ProjectHelathEntryResult] prs join [dbo].[ProjectHelathEntry] phe
			on prs.ITEM_NO = phe.ITEM_NO
			and prs.[PRCL-IND] = phe.PRCL_IND
			and prs.UD1 = phe.UD1
			and prs.UD2 = phe.UD2
			and prs.UD3 = phe.UD3
			and prs.[330-IND] = phe.[330_IND]
			and prs.[GAP-LMT] = phe.GAP_LIMIT
			and prs.IRES = phe.IRES
			and prs.S1C2 = phe.S1C2
			and prs.[PRCL-NXTDCL-DIF] = phe.[PRCL-NXTDCL-DIF]
			and prs.[PR-DATE] = phe.[PP-DATE]
			)< (select count(*) from [dbo].[ProjectHelathEntryResult])
		begin
			IF OBJECT_ID('tempdb..##Temp_ProjectHelathEntryResult') IS NOT NULL
			DROP TABLE ##Temp_ProjectHelathEntryResult

			select * 
			into ##Temp_ProjectHelathEntryResult 
			from [dbo].[ProjectHelathEntryResult]
		end
		*/

		TRUNCATE TABLE [dbo].[ProjectHelathEntryResultP2]



		Declare @Var_ITEM_NO INT,
				@Var_PRCL_IND NUMERIC(10,2),
				@ActResCntR	INT = 0,
				@ActResCntI INT = 0,
				@ActResNxtCntR	INT = 0,
				@ActResNxtCntI	INT = 0,
				@ActResCnt330I	INT = 0,
				@ActResNxtCnt330R  INT = 0,
				@ActResNxtCnt330I	INT = 0,
				@UD1 NUMERIC(10,2) = 0.03,
				@varind330INC NUMERIC(10,2),
				@varind330RED NUMERIC(10,2),
				@varindPRCLINC NUMERIC(10,2),
				@varindPRCLRED NUMERIC(10,2),
				@varind330PRCLINC NUMERIC(10,2),
				@varind330PRCLRED NUMERIC(10,2),
				@ActResCnt330P	INT = 0,
				@ActResNxtCnt330P	INT = 0,
				@ActResCnt330RP	INT = 0,
				@ActResNxtCnt330RP	INT = 0,
				@ActResCnt330R INT = 0
				--,@ITEM_NO int = 939
		IF OBJECT_ID('tempdb..##Temp_ITEMNO') IS NOT NULL
		DROP TABLE ##Temp_ITEMNO

		SELECT top(50) ITEM_NO
		INTO ##Temp_ITEMNO
		FROM ProjectHelathEntry order by ITEM_NO desc --where ITEM_NO IN (@ITEM_NO)

		-- FOR C1
		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNO)>0
		BEGIN

		select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNO
		print @Var_ITEM_NO

		select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

		;WITH CTE_LHINDCNT1
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_LHINDCNT2
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_LHINDCNT3
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		)
			INSERT INTO [dbo].[ProjectHealth_Intermediary]
			select @Var_ITEM_NO, '[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) +']' as [L/H-IND-CNT1], 
			NULL as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_LHINDCNT1
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10))  +']' as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_LHINDCNT2
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
			NULL AS [L/H-IND-CNT2] ,
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT3]
			from CTE_LHINDCNT3

	
			update [dbo].[ProjectHealth_Intermediary]
			set
				[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		
			update [dbo].[ProjectHealth_Intermediary]
			set
				[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

	
			update [dbo].[ProjectHealth_Intermediary]
			set
				[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_Intermediary] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		DELETE TOP(1) FROM ##Temp_ITEMNO
		END
		
		-- FOR C2
		IF OBJECT_ID('tempdb..##Temp_ITEMNOC2') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC2

		SELECT top(50) ITEM_NO
		INTO ##Temp_ITEMNOC2
		FROM ProjectHelathEntry ORDER BY ITEM_NO DESC--where ITEM_NO IN (@ITEM_NO)

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC2)>0
		BEGIN

		select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNOC2
		print @Var_ITEM_NO

		select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

		;WITH CTE_C2LHINDCNT1
		AS
		(
			select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
		),

		CTE_C2LHINDCNT2
		AS
		(
			select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
		),

		CTE_C2LHINDCNT3
		AS
		(
			select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select ([330_IND] - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select ([330_IND] + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
		)

			INSERT INTO [dbo].[ProjectHealth_IntermediaryC2]
			select @Var_ITEM_NO, '[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT1], 
			NULL as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C2LHINDCNT1
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C2LHINDCNT2
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
			NULL AS [L/H-IND-CNT2] ,
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT3]
			from CTE_C2LHINDCNT3

	
			update [dbo].[ProjectHealth_IntermediaryC2]
			set
				[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		
			update [dbo].[ProjectHealth_IntermediaryC2]
			set
				[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

	
			update [dbo].[ProjectHealth_IntermediaryC2]
			set
				[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO



		DELETE TOP(1) FROM ##Temp_ITEMNOC2
		END

		-- FOR 330 IND
		-- FOR C2
		IF OBJECT_ID('tempdb..##Temp_ITEMNOC3') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC3

		SELECT top(50) ITEM_NO
		INTO ##Temp_ITEMNOC3
		FROM ProjectHelathEntry ORDER BY ITEM_NO DESC--where ITEM_NO IN (@ITEM_NO)

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC3)>0
		BEGIN

		select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNOC3
		print @Var_ITEM_NO

		select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

		;WITH CTE_C3LHINDCNT1
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)  and ITEM_NO in (@Var_ITEM_NO)) and 
			(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_C3LHINDCNT2
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		),

		CTE_C3LHINDCNT3
		AS
		(
			select COUNT(DISTINCT [PP-CL]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] < (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			union
			select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-CL]) AS PP_CL_HighCnt
			from [PP-FILE]
			where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO)) and 
			(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
			and [PP-CL] > (select [330_IND]  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND) and ITEM_NO in (@Var_ITEM_NO))
		)

			INSERT INTO [dbo].[ProjectHealth_IntermediaryC3]
			select @Var_ITEM_NO, '[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT1], 
			NULL as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C3LHINDCNT1
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT2], 
			NULL AS [L/H-IND-CNT3]
			from CTE_C3LHINDCNT2
			union
			select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
			NULL AS [L/H-IND-CNT2] ,
			'[' + cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) + ']' as [L/H-IND-CNT3]
			from CTE_C3LHINDCNT3

	
			update [dbo].[ProjectHealth_IntermediaryC3]
			set
				[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_IntermediaryC3] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		
			update [dbo].[ProjectHealth_IntermediaryC3]
			set
				[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_IntermediaryC3] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

	
			update [dbo].[ProjectHealth_IntermediaryC3]
			set
				[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_IntermediaryC3] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
			where [ITEM_NO] = @Var_ITEM_NO

		DELETE TOP(1) FROM ##Temp_ITEMNOC3
		END



		insert into [dbo].[ProjectHelathEntryResultP2]
		select  A.ITEM_NO,
				(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'RED' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				'PRCL->PPCL' AS FLAG,
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@NoOfCells as [MinNoCells]
		from (SELECT top(50)* FROM [dbo].[ProjectHelathEntry] ORDER BY ITEM_NO DESC) a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]

		union

		select  A.ITEM_NO,
				(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'INC' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				'PRCL->PPCL' AS FLAG,
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@NoOfCells as [MinNoCells]
		from (SELECT top(50)* FROM [dbo].[ProjectHelathEntry] ORDER BY ITEM_NO DESC) a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]
		union
		select  A.ITEM_NO,
				(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'RED' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				'330IND->PPCL' AS FLAG,
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@NoOfCells as [MinNoCells]
		from (SELECT top(50)* FROM [dbo].[ProjectHelathEntry] ORDER BY ITEM_NO DESC) a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]

		union

		select  A.ITEM_NO,
				(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'INC' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				'330IND->PPCL' AS FLAG,
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@NoOfCells as [MinNoCells]
		from (SELECT top(50)* FROM [dbo].[ProjectHelathEntry] ORDER BY ITEM_NO DESC) a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]

		UNION

		select  A.ITEM_NO,
				(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'RED' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				'PRCL/330IND->PPOP/PPCL' AS FLAG,
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@NoOfCells as [MinNoCells]
		from (SELECT top(50)* FROM [dbo].[ProjectHelathEntry] ORDER BY ITEM_NO DESC) a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]

		UNION

		select  A.ITEM_NO,
				(substring(CONVERT(char(10),A.[PP-DATE],126),9,2) + '-' + substring(CONVERT(char(10),A.[PP-DATE],126),6,2) + '-' +substring(CONVERT(char(10),A.[PP-DATE],126),1,4) ) as [PR-DATE],
	   			PRCL_IND  [PRCL-IND],
				[330_IND]  [330-IND],
				[S1C2],
				[UD1],
				b.[L/H-IND-CNT1] AS [PRCL/PRCL-IND-CNT1],
				[UD2],
				b.[L/H-IND-CNT2] AS [PRCL/PRCL-IND-CNT2],
				[UD3],
				b.[L/H-IND-CNT3] AS [PRCL/PRCL-IND-CNT3],
				--[PRCL-NXTDCL-DIF],
				c.[L/H-IND-CNT1] AS [PRCL/C2-CNT1],
				c.[L/H-IND-CNT2] AS [PRCL/C2-CNT2],
				c.[L/H-IND-CNT3] AS [PRCL/C3-CNT3],
				'INC' as [RED/INC],
				[UD1] as [PP-RNG-UD],
				[GAP_LIMIT],
				NULL AS [IND-GAP],
				NULL AS [LIND],
				NULL AS [MIND],
				NULL AS [Res9],
				NULL AS [Res8],
				NULL AS [Res7],
				NULL AS [Res6],
				NULL AS [Res5],
				NULL AS [Res4],
				NULL AS [Res3],
				NULL AS [Res2],
				NULL AS [Res1],
				NULL AS [TOT],
				NULL AS [ALL-CNT(P/N)],
				NULL AS [GREEN],
				NULL AS [ACC/TOT],
				NULL AS [3COL/NET],
				NULL AS [ACC/3COL],
				NULL AS [COMM],
				[IRES],
				[PRFIN-IND],
				d.[L/H-IND-CNT1] as [PRCL/330IND-R1-C],
				d.[L/H-IND-CNT2] as [PRCL/330IND-R2-C],
				d.[L/H-IND-CNT3] as [PRCL/330IND-R3-C],
				'PRCL/330IND->PPOP/PPCL' AS FLAG,
				A.[S1C1] AS [PR-S1C1],
				A.S1C2 as [PR-S1C2],
				A.S1C3  AS [PR-S1C3],
				@NoOfCells as [MinNoCells]
		from (SELECT top(50)* FROM [dbo].[ProjectHelathEntry] ORDER BY ITEM_NO DESC) a join 
		(SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_Intermediary]
		  ) b
		on a.ITEM_NO = b.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC2]
		  ) c
		on a.ITEM_NO = c.[ITEM_NO]
		join (SELECT DISTINCT [ITEM_NO]
			  ,[L/H-IND-CNT1]
			  ,[L/H-IND-CNT2]
			  ,[L/H-IND-CNT3]
		  FROM [dbo].[ProjectHealth_IntermediaryC3]
		  ) d
		on a.ITEM_NO = d.[ITEM_NO]

		
		
	IF OBJECT_ID('tempdb..##Temp_P2ITEMNO') IS NOT NULL
		DROP TABLE ##Temp_P2ITEMNO

		SELECT top(50) ITEM_NO
		INTO ##Temp_P2ITEMNO
		FROM ProjectHelathEntry order by ITEM_NO DESC--where ITEM_NO IN (@ITEM_NO)

		-- FOR C1
		WHILE(SELECT COUNT(*) FROM ##Temp_P2ITEMNO)>0
		BEGIN

			select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_P2ITEMNO
			
			EXEC SP_ProjectHealthP2_Recur @Var_ITEM_NO = @Var_ITEM_NO


			DELETE TOP(1) FROM ##Temp_P2ITEMNO
		END

		

		--EXEC SP_GraphPercentageCalc


	-- INSERTING ONE BLANK ROW FOR SEGREGATING ROWS IN BETWEEN
		/*
		insert into dbo.ProjectHelathEntryResult
		select NULL AS    [ITEM_NO],
			NULL AS    [PR-DATE],
			NULL AS    [PRCL-IND],
			NULL AS    [330-IND],
			NULL AS    [S1C2],
			NULL AS    [UD1],
			NULL AS    [L/H-IND-CNT1],
			NULL AS    [UD2],
			NULL AS    [L/H-IND-CNT2],
			NULL AS    [UD3],
			NULL AS    [L/H-IND-CNT3],
			NULL AS    [PRCL-NXTDCL-DIF],
			NULL AS    [N/P-C2-CNT1],
			NULL AS    [N/P-C2-CNT2],
			NULL AS    [N/P-C2-CNT3],
			NULL AS    [RED/INC],
			NULL AS    [PP-RNG-UD],
			NULL AS    [GAP-LMT],
			NULL AS    [IND-GAP],
			NULL AS    [LIND],
			NULL AS    [MIND],
			NULL AS    [Res9],
			NULL AS    [Res8],
			NULL AS    [Res7],
			NULL AS    [Res6],
			NULL AS    [Res5],
			NULL AS    [Res4],
			NULL AS    [Res3],
			NULL AS    [Res2],
			NULL AS    [Res1],
			NULL AS    [TOT],
			NULL AS    [ALL-CNT(P/N)],
			NULL AS    [GREEN],
			NULL AS    [ACC],
			NULL AS    [COMM],
			NULL AS    [IRES]
		*/
		-- Checking whether any changes in input data, if there is any changes, it will append in the resultset
		/*
		insert into dbo.ProjectHelathEntryResult
		select a.[ITEM_NO],
				a.[PR-DATE],
				a.[PRCL-IND],
				a.[330-IND],
				a.[S1C2],
				a.[UD1],
				a.[PRCL/PRCL-IND-CNT1],
				a.[UD2],
				a.[PRCL/PRCL-IND-CNT2],
				a.[UD3],
				a.[PRCL/PRCL-IND-CNT3],
				--a.[PRCL-NXTDCL-DIF],
				a.[PRCL/C2-CNT1],
				a.[PRCL/C2-CNT2],
				a.[PRCL/C3-CNT3],
				a.[RED/INC],
				a.[PP-RNG-UD],
				a.[GAP-LMT],
				a.[IND-GAP],
				a.[LIND],
				a.[MIND],
				a.[Res9],
				a.[Res8],
				a.[Res7],
				a.[Res6],
				a.[Res5],
				a.[Res4],
				a.[Res3],
				a.[Res2],
				a.[Res1],
				a.[TOT],
				a.[ALL-CNT(P/N)],
				a.[GREEN],
				a.[ACC/TOT],
				a.[3COL/NET],
				a.[ACC/3COL],
				a.[COMM],
				a.[IRES],
				a.[PRFIN-IND],
				a.[PRCL/330IND-R1-C],
				a.[PRCL/330IND-R2-C],
				a.[PRCL/330IND-R3-C]
		from ##Temp_ProjectHelathEntryResult a left join dbo.ProjectHelathEntryResult b
		ON A.ITEM_NO = b.ITEM_NO
		and a.[PR-DATE] = b.[PR-DATE]
		and a.[PRCL-IND] = b.[PRCL-IND]
		and a.[330-IND] = b.[330-IND]
		and a.UD1 = b.UD1
		and a.ud2 = b.ud2
		and a.UD3 = b.UD3
		and a.[GAP-LMT] = b.[GAP-LMT]
		and a.S1C2 = b.S1C2
		and a.IRES = b.IRES
		--and a.[PRCL-NXTDCL-DIF] = b.[PRCL-NXTDCL-DIF]
		where b.ITEM_NO is null
		*/

END
GO

