USE [ProjectHealth]
GO

/****** Object:  Table [dbo].[ProjectHealth_Intermediary]    Script Date: 14/05/2021 8:54:06 PM ******/
DROP TABLE [dbo].[ProjectHealth_Intermediary]
GO

/****** Object:  Table [dbo].[ProjectHealth_Intermediary]    Script Date: 14/05/2021 8:54:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProjectHealth_Intermediary](
	[ITEM_NO]	INT NOT NULL,
	[L/H-IND-CNT1] [nchar](10) NULL,
	[L/H-IND-CNT2] [nchar](10) NULL,
	[L/H-IND-CNT3] [nchar](10) NULL
) ON [PRIMARY]
GO


