

Declare @Var_ITEM_NO INT,
		@Var_PRCL_IND NUMERIC(10,2)

IF OBJECT_ID('tempdb..##Temp_ITEMNO') IS NOT NULL
DROP TABLE ##Temp_ITEMNO

SELECT DISTINCT ITEM_NO
INTO ##Temp_ITEMNO
FROM ProjectHelathEntry

WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNO)>0
BEGIN

select top(1) @Var_ITEM_NO = ITEM_NO from ##Temp_ITEMNO
print @Var_ITEM_NO

select @Var_PRCL_IND = PRCL_IND from ProjectHelathEntry where ITEM_NO IN (@Var_ITEM_NO)

;WITH CTE_C2LHINDCNT1
AS
(
	select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD1) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
),

CTE_C2LHINDCNT2
AS
(
	select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD2) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
),
CTE_C2LHINDCNT3
AS
(
	select COUNT(DISTINCT [PP-C2]) AS PP_CL_LessCnt, null as PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] < 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	union
	select null as PP_CL_LessCnt, COUNT(DISTINCT [PP-C2]) AS PP_CL_HighCnt
	from [PP-FILE]
	where [PP-OP] between (select (PRCL_IND - UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND)) and 
	(select (PRCL_IND + UD3) from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
	and [PP-C2] > 0--(select PRCL_IND  from dbo.ProjectHelathEntry where PRCL_IND in (@Var_PRCL_IND))
)

	INSERT INTO [dbo].[ProjectHealth_IntermediaryC2]
	select @Var_ITEM_NO, cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT1], 
	NULL as [L/H-IND-CNT2], 
	NULL AS [L/H-IND-CNT3]
	from CTE_C2LHINDCNT1
	union
	select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1], 
	cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT2], 
	NULL AS [L/H-IND-CNT3]
	from CTE_C2LHINDCNT2
	union
	select @Var_ITEM_NO, NULL AS [L/H-IND-CNT1],
	NULL AS [L/H-IND-CNT2] ,
	cast(SUM(ISNULL(PP_CL_LessCnt,0)) as varchar(10))+ '/' +cast(SUM(ISNULL(PP_CL_HighCnt,0)) as varchar(10)) as [L/H-IND-CNT3]
	from CTE_C2LHINDCNT3

	
	update [dbo].[ProjectHealth_IntermediaryC2]
	set
		[L/H-IND-CNT1] = (SELECT [L/H-IND-CNT1] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT1] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

		
	update [dbo].[ProjectHealth_IntermediaryC2]
	set
		[L/H-IND-CNT2] = (SELECT [L/H-IND-CNT2] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT2] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

	
	update [dbo].[ProjectHealth_IntermediaryC2]
	set
		[L/H-IND-CNT3] = (SELECT [L/H-IND-CNT3] FROM [dbo].[ProjectHealth_IntermediaryC2] WHERE [ITEM_NO] = @Var_ITEM_NO AND [L/H-IND-CNT3] IS NOT NULL)
	where [ITEM_NO] = @Var_ITEM_NO

DELETE TOP(1) FROM ##Temp_ITEMNO
END



--delete from [dbo].[ProjectHealth_IntermediaryC2]


select * from [dbo].[ProjectHealth_IntermediaryC2]

