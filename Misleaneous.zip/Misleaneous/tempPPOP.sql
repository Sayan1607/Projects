Declare @NoofCells INT = 1,
		@Var_ITEM_NO INT = 1051

		IF OBJECT_ID('tempdb..##Temp_ITEMNOCL5114') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOCL5114
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFFRESULTTR') IS NOT NULL
	    DROP TABLE ##Temp_ITEMPRCLINDDIFFRESULTTR
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFFRESULT') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLINDDIFFRESULT
		IF OBJECT_ID('tempdb..##Temp_CTE') IS NOT NULL
		DROP TABLE ##Temp_CTE
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFF') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLINDDIFF
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLIND') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLIND

		IF OBJECT_ID('tempdb..##Temp_ITEMNOCL5114') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOCL5114

		SELECT DISTINCT ITEM_NO
		INTO ##Temp_ITEMNOCL5114
		FROM ProjectHelathEntry 
		where ITEM_NO in (@Var_ITEM_NO)
		order by ITEM_NO DESC

		DECLARE @Var_PRCLIND NUMERIC(10,2),
				@Var_330PRCLDIFF NUMERIC(10,2),
				@VAR_OPCL1 NUMERIC(10,2),
				@VAR_OPCL2 NUMERIC(10,2),
				@VAR_IRES1	NUMERIC(10,2),
				@VAR_IRES2	NUMERIC(10,2),
				@VARPRCLL	NUMERIC(10,2),
				@VARPRCLH	NUMERIC(10,2),
				@TR			VARCHAR(50),
				@INCRED		NUMERIC(10,2) = 0.00

		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOCL5114)>0
		BEGIN
			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOCL5114

			SELECT DISTINCT @Var_PRCLIND = [PRCL-IND] FROM dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_ITEM_NO)
			SELECT DISTINCT @Var_330PRCLDIFF = ([330-IND] - [PRCL-IND]) FROM dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_ITEM_NO)

			IF OBJECT_ID('tempdb..##Temp_ITEMPRCLIND') IS NOT NULL
			DROP TABLE ##Temp_ITEMPRCLIND

			select 0 AS ITEM_NO,
					CONVERT(NUMERIC(10,2),0.00) as PRCLIND
			INTO  ##Temp_ITEMPRCLIND

			delete from ##Temp_ITEMPRCLIND

			IF(SELECT COUNT(*) FROM dbo.[PP-FILE] where [PP-CL] = @Var_PRCLIND AND ISNUMERIC([PP-IRES])=1)>0
			BEGIN
				INSERT INTO ##Temp_ITEMPRCLIND
				SELECT @Var_ITEM_NO,@Var_PRCLIND
			END

			INSERT INTO ##Temp_ITEMPRCLIND
			SELECT TOP(1) @Var_ITEM_NO, CONVERT(NUMERIC(10,2),[PP-CL]) AS [PP-CL]
			FROM dbo.[PP-FILE] 
			where [PP-CL] < @Var_PRCLIND 
			AND ISNUMERIC([PP-IRES]) = 1
			ORDER BY [PP-CL] DESC

			INSERT INTO ##Temp_ITEMPRCLIND
			SELECT TOP(1) @Var_ITEM_NO, CONVERT(NUMERIC(10,2),[PP-CL]) AS [PP-CL]
			FROM dbo.[PP-FILE] 
			where [PP-CL] > @Var_PRCLIND
			AND ISNUMERIC([PP-IRES]) = 1
			ORDER BY [PP-CL] ASC

			--PRINT @Var_330PRCLDIFF

			IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFF') IS NOT NULL
			DROP TABLE ##Temp_ITEMPRCLINDDIFF

			SELECT [PP-CL],
					CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)] , 
					CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
			INTO ##Temp_ITEMPRCLINDDIFF
			FROM dbo.[PP-FILE] 
			where [PP-CL] in ( SELECT distinct  PRCLIND FROM ##Temp_ITEMPRCLIND)
			AND [PP-DIF(OP-CL)] in (@Var_330PRCLDIFF)
			AND ISNUMERIC([PP-IRES])=1

			TRUNCATE TABLE ##Temp_ITEMPRCLINDDIFF

			SELECT @VARPRCLL = (SELECT top(1) [PP-CL]
								FROM dbo.[PP-FILE] 
								where [PP-CL] in ( SELECT distinct  PRCLIND FROM ##Temp_ITEMPRCLIND)
								AND [PP-DIF(OP-CL)]  < @Var_330PRCLDIFF
								AND ISNUMERIC([PP-IRES])=1
								ORDER BY  [PP-DIF(CL-OP)] ASC
								)

			SELECT @VARPRCLH = (SELECT top(1) [PP-CL]
								FROM dbo.[PP-FILE] 
								where [PP-CL] in ( SELECT distinct  PRCLIND FROM ##Temp_ITEMPRCLIND)
								AND [PP-DIF(OP-CL)]  > @Var_330PRCLDIFF
								AND ISNUMERIC([PP-IRES])=1
								ORDER BY  [PP-DIF(CL-OP)] DESC
								)
			
			
			--select @VARPRCLL
			--select @VARPRCLH
			
			WHILE(@VARPRCLL IS NULL OR @VARPRCLH IS NULL)
			BEGIN
				IF((@Var_PRCLIND - (select  MIN(PRCLIND) from ##Temp_ITEMPRCLIND)) < ((select MAX(PRCLIND) from ##Temp_ITEMPRCLIND) - @Var_PRCLIND) )
				BEGIN
					--PRINT 'Hi..p'
					INSERT INTO ##Temp_ITEMPRCLIND
					SELECT TOP(1) @Var_ITEM_NO, CONVERT(NUMERIC(10,2),[PP-CL]) AS [PP-CL]
					FROM dbo.[PP-FILE] 
					where [PP-CL] < @Var_PRCLIND and [PP-CL] not in (select  PRCLIND from ##Temp_ITEMPRCLIND)
					AND ISNUMERIC([PP-IRES]) = 1
					ORDER BY [PP-CL] DESC
				END
				ELSE IF( ((select MAX(PRCLIND) from ##Temp_ITEMPRCLIND) - @Var_PRCLIND) < (@Var_PRCLIND - (select  MIN(PRCLIND) from ##Temp_ITEMPRCLIND)))
				BEGIN
					INSERT INTO ##Temp_ITEMPRCLIND
					SELECT TOP(1) @Var_ITEM_NO, CONVERT(NUMERIC(10,2),[PP-CL]) AS [PP-CL]
					FROM dbo.[PP-FILE] 
					where [PP-CL] > @Var_PRCLIND and [PP-CL] not in (select PRCLIND from ##Temp_ITEMPRCLIND)
					AND ISNUMERIC([PP-IRES]) = 1
					ORDER BY [PP-CL] ASC
				END
				ELSE IF ( ((select MAX(PRCLIND) from ##Temp_ITEMPRCLIND) - @Var_PRCLIND) = (@Var_PRCLIND - (select  MIN(PRCLIND) from ##Temp_ITEMPRCLIND)))
				BEGIN
					SELECT @INCRED = @INCRED + 0.01
					IF(@VARPRCLH IS NULL)
					BEGIN
						INSERT INTO ##Temp_ITEMPRCLIND
						SELECT TOP(1) @Var_ITEM_NO, CONVERT(NUMERIC(10,2),[PP-CL]) AS [PP-CL]
						FROM dbo.[PP-FILE] 
						where [PP-CL] > @Var_PRCLIND and [PP-CL] not in (select PRCLIND from ##Temp_ITEMPRCLIND) and [PP-CL] in ((select max(PRCLIND) from ##Temp_ITEMPRCLIND)+@INCRED)
						AND ISNUMERIC([PP-IRES]) = 1
						ORDER BY [PP-CL] ASC
					END
					IF(@VARPRCLL IS NULL)
					BEGIN
						INSERT INTO ##Temp_ITEMPRCLIND
						SELECT TOP(1) @Var_ITEM_NO, CONVERT(NUMERIC(10,2),[PP-CL]) AS [PP-CL]
						FROM dbo.[PP-FILE] 
						where [PP-CL] < @Var_PRCLIND and [PP-CL] not in (select  PRCLIND from ##Temp_ITEMPRCLIND) and [PP-CL] in ((select min(PRCLIND) from ##Temp_ITEMPRCLIND)-@INCRED)
						AND ISNUMERIC([PP-IRES]) = 1
						ORDER BY [PP-CL] DESC
					END

				END
				
				SELECT @VARPRCLL = (SELECT top(1) [PP-CL]
								FROM dbo.[PP-FILE] 
								where [PP-CL] in ( SELECT distinct  PRCLIND FROM ##Temp_ITEMPRCLIND)
								AND [PP-DIF(OP-CL)]  < @Var_330PRCLDIFF
								AND ISNUMERIC([PP-IRES])=1
								ORDER BY  [PP-DIF(CL-OP)] ASC
								)

				SELECT @VARPRCLH = (SELECT top(1) [PP-CL]
								FROM dbo.[PP-FILE] 
								where [PP-CL] in ( SELECT distinct  PRCLIND FROM ##Temp_ITEMPRCLIND)
								AND [PP-DIF(OP-CL)]  > @Var_330PRCLDIFF
								AND ISNUMERIC([PP-IRES])=1
								ORDER BY  [PP-DIF(CL-OP)] DESC
								)
				--select @VARPRCLL
				--select @VARPRCLH

				--select * from ##Temp_ITEMPRCLIND

			END
			
			--SELECT * FROM ##Temp_ITEMPRCLIND

			
			Declare @minval numeric(10,2),
					@maxval	numeric(10,2)
			
			--SELECT min([PP-DIF(OP-CL)]) FROM DBO.[PP-FILE] WHERE [PP-CL] in (20.10, 20.12) AND [PP-DIF(OP-CL)] > 0.06 -- @Var_PRCLIND
			--select * from dbo.[PP-FILE] where [PP-CL] in ((select max(PRCLIND) from ##Temp_ITEMPRCLIND),19.71) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = 1.27
			--select * from dbo.[PP-FILE] where [PP-CL] in (select min(PRCLIND) from ##Temp_ITEMPRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = 0.20
			--select * from dbo.[PP-FILE] where [PP-CL] in (19.85) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = 0.20

			SELECT @maxval = convert(numeric(10,2),min([PP-DIF(OP-CL)])) FROM DBO.[PP-FILE] WHERE [PP-CL] in ( select distinct PRCLIND from ##Temp_ITEMPRCLIND) AND [PP-DIF(OP-CL)] > @Var_330PRCLDIFF and CONVERT(NUMERIC(10,2), [PP-DIF(OP-CL)]) <> @Var_330PRCLDIFF 
			and CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )

			SELECT @minval = convert(numeric(10,2),max([PP-DIF(OP-CL)])) FROM DBO.[PP-FILE] WHERE [PP-CL] in ( select distinct PRCLIND from ##Temp_ITEMPRCLIND) AND [PP-DIF(OP-CL)] < @Var_330PRCLDIFF and CONVERT(NUMERIC(10,2), [PP-DIF(OP-CL)]) <> @Var_330PRCLDIFF 
			and CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )

			--select @maxval
			--select @minval
			--select @VARPRCLL
			--select @VARPRCLH

			--select * from ##Temp_ITEMPRCLINDDIFF

			IF(@VARPRCLL IS NOT NULL AND @VARPRCLH IS NOT NULL)
			BEGIN
					IF((select COUNT(*) from dbo.[PP-FILE] where [PP-CL] in (select min(PRCLIND) from ##Temp_ITEMPRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = @minval) > 0)
					BEGIN
							--PRINT 'HI..1'
							INSERT INTO ##Temp_ITEMPRCLINDDIFF
							SELECT CONVERT(NUMERIC(10,2),A.[PP-CL]) AS [PP-CL],
									CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) AS [PP-DIF(CL-OP)],
									CONVERT(NUMERIC(10,2),A.[PP-IRES]) AS [PP-IRES]
							FROM dbo.[PP-FILE] A join
							(
							SELECT TOP(1) [PP-CL],
										CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)], 
										CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
							FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
							ON A.[PP-CL] = B.PRCLIND
							where B.PRCLIND < @Var_PRCLIND
							AND [PP-DIF(OP-CL)]  < @Var_330PRCLDIFF
							AND ISNUMERIC([PP-IRES])=1
							AND CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )
							ORDER BY  [PP-DIF(CL-OP)] ASC
							)RESULT
							ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = RESULT.[PP-CL]
							AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = RESULT.[PP-DIF(CL-OP)]

					END
					IF((select COUNT(*) from dbo.[PP-FILE] where [PP-CL] in (select max(PRCLIND) from ##Temp_ITEMPRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = @minval) > 0)
					BEGIN
							--PRINT 'HI..2'
							INSERT INTO ##Temp_ITEMPRCLINDDIFF
							SELECT CONVERT(NUMERIC(10,2),A.[PP-CL]) AS [PP-CL],
									CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) AS [PP-DIF(CL-OP)],
									CONVERT(NUMERIC(10,2),A.[PP-IRES]) AS [PP-IRES]
							FROM dbo.[PP-FILE] A join
							(
							SELECT TOP(1) [PP-CL],
										CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)], 
										CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
							FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
							ON A.[PP-CL] = B.PRCLIND
							where B.PRCLIND > @Var_PRCLIND
							AND [PP-DIF(OP-CL)]  < @Var_330PRCLDIFF
							AND ISNUMERIC([PP-IRES])=1
							AND CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )
							ORDER BY  [PP-DIF(CL-OP)] ASC
							)RESULT
							ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = RESULT.[PP-CL]
							AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = RESULT.[PP-DIF(CL-OP)]

					END
					IF((select COUNT(*) from dbo.[PP-FILE] where [PP-CL] in (@Var_PRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = @minval) > 0)
					BEGIN
							--PRINT 'HI..3'
							INSERT INTO ##Temp_ITEMPRCLINDDIFF
							SELECT CONVERT(NUMERIC(10,2),A.[PP-CL]) AS [PP-CL],
									CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) AS [PP-DIF(CL-OP)],
									CONVERT(NUMERIC(10,2),A.[PP-IRES]) AS [PP-IRES]
							FROM dbo.[PP-FILE] A join
							(
							SELECT TOP(1) [PP-CL],
										CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)], 
										CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
							FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
							ON A.[PP-CL] = B.PRCLIND
							where B.PRCLIND = @Var_PRCLIND
							AND [PP-DIF(OP-CL)]  < @Var_330PRCLDIFF
							AND ISNUMERIC([PP-IRES])=1
							AND CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )
							ORDER BY  [PP-DIF(CL-OP)] ASC
							)RESULT
							ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = RESULT.[PP-CL]
							AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = RESULT.[PP-DIF(CL-OP)]

					END
					
					--select * from dbo.[PP-FILE] where [PP-CL] in (select max(PRCLIND) from ##Temp_ITEMPRCLIND) AND [PP-DIF(OP-CL)] = @maxval

					IF((select COUNT(*) from dbo.[PP-FILE] where [PP-CL] in (select max(PRCLIND) from ##Temp_ITEMPRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = @maxval) > 0)
					BEGIN
							--PRINT 'HI..4'
							INSERT INTO ##Temp_ITEMPRCLINDDIFF
							SELECT CONVERT(NUMERIC(10,2),A.[PP-CL]) AS [PP-CL],
									CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) AS [PP-DIF(CL-OP)],
									CONVERT(NUMERIC(10,2),A.[PP-IRES]) AS [PP-IRES]
							FROM dbo.[PP-FILE] A join
							(
							SELECT top(1) [PP-CL],
										CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)],
										CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
							FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
							ON A.[PP-CL] = B.PRCLIND
							where B.PRCLIND > @Var_PRCLIND 
							AND [PP-DIF(OP-CL)]  > @Var_330PRCLDIFF
							AND ISNUMERIC([PP-IRES])=1
							AND CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )
							ORDER BY  [PP-DIF(CL-OP)] DESC
							)RESULT
							ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = RESULT.[PP-CL]
							AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = RESULT.[PP-DIF(CL-OP)]
					END
					
					IF((select COUNT(*) from dbo.[PP-FILE] where [PP-CL] in (select min(PRCLIND) from ##Temp_ITEMPRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = @maxval) > 0)
					BEGIN
							--PRINT 'HI..5'
							INSERT INTO ##Temp_ITEMPRCLINDDIFF
							SELECT CONVERT(NUMERIC(10,2),A.[PP-CL]) AS [PP-CL],
									CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) AS [PP-DIF(CL-OP)],
									CONVERT(NUMERIC(10,2),A.[PP-IRES]) AS [PP-IRES]
							FROM dbo.[PP-FILE] A join
							(
							SELECT top(1) [PP-CL],
										CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)],
										CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
							FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
							ON A.[PP-CL] = B.PRCLIND
							where B.PRCLIND < @Var_PRCLIND 
							AND [PP-DIF(OP-CL)]  > @Var_330PRCLDIFF
							AND ISNUMERIC([PP-IRES])=1
							AND CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )
							ORDER BY  [PP-DIF(CL-OP)] DESC
							)RESULT
							ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = RESULT.[PP-CL]
							AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = RESULT.[PP-DIF(CL-OP)]
					END
					IF((select COUNT(*) from dbo.[PP-FILE] where [PP-CL] in (@Var_PRCLIND) AND convert(numeric(10,2),[PP-DIF(OP-CL)]) = @maxval) > 0)
					BEGIN
							--PRINT 'HI..6'
							INSERT INTO ##Temp_ITEMPRCLINDDIFF
							SELECT CONVERT(NUMERIC(10,2),A.[PP-CL]) AS [PP-CL],
									CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) AS [PP-DIF(CL-OP)],
									CONVERT(NUMERIC(10,2),A.[PP-IRES]) AS [PP-IRES]
							FROM dbo.[PP-FILE] A join
							(
							SELECT top(1) [PP-CL],
										CONVERT(NUMERIC(10,2),[PP-DIF(CL-OP)]) [PP-DIF(CL-OP)],
										CONVERT(NUMERIC(10,2),[PP-IRES]) [PP-IRES]
							FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
							ON A.[PP-CL] = B.PRCLIND
							where B.PRCLIND = @Var_PRCLIND 
							AND [PP-DIF(OP-CL)]  > @Var_330PRCLDIFF
							AND ISNUMERIC([PP-IRES])=1
							AND CONVERT(NUMERIC(10,2),[PP-DIF(OP-CL)]) NOT IN (SELECT DISTINCT CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)])
											FROM dbo.[PP-FILE] A join ##Temp_ITEMPRCLIND B
											ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.PRCLIND)
											WHERE ISNUMERIC(A.[PP-IRES]) = 0
									   )
							ORDER BY  [PP-DIF(CL-OP)] DESC
							)RESULT
							ON CONVERT(NUMERIC(10,2),A.[PP-CL]) = RESULT.[PP-CL]
							AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = RESULT.[PP-DIF(CL-OP)]
					END
			END
			
			--SELECT * FROM  ##Temp_ITEMPRCLINDDIFF
			
			IF OBJECT_ID('tempdb..##Temp_CTE') IS NOT NULL
				DROP TABLE ##Temp_CTE
					
					SELECT A.*
					INTO ##Temp_CTE
					FROM ##Temp_ITEMPRCLINDDIFF A JOIN 
					(
					SELECT [PP-CL],
						[PP-DIF(CL-OP)],
						COUNT(*) AS CNT
					FROM ##Temp_ITEMPRCLINDDIFF
					GROUP BY [PP-CL],
						[PP-DIF(CL-OP)]
					HAVING COUNT(*) > 1
					)RSLT
					ON A.[PP-CL] = RSLT.[PP-CL]
					AND A.[PP-DIF(CL-OP)] = RSLT.[PP-DIF(CL-OP)]
				
				IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFFRESULT') IS NOT NULL
				DROP TABLE ##Temp_ITEMPRCLINDDIFFRESULT

				SELECT 0 AS ITEM_NO,
						CONVERT(NUMERIC(10,2),0.00) AS [PP-CL],
						CONVERT(NUMERIC(10,2),0.00) AS [PP-DIF(CL-OP)],
						CONVERT(NUMERIC(10,2),0.00) AS [PP-IRES],
						CONVERT(NUMERIC(10,2),0.00) as MxDiff,
						CONVERT(NUMERIC(10,2),0.00) as AVGRSLT,
						CONVERT(NUMERIC(10,2),0.00) as NETRSLT
				INTO ##Temp_ITEMPRCLINDDIFFRESULT

				DELETE FROM ##Temp_ITEMPRCLINDDIFFRESULT

				WHILE((SELECT COUNT(*) FROM ##Temp_CTE)>=2)
				BEGIN
						SELECT TOP(1) @VAR_OPCL1 = [PP-DIF(CL-OP)] FROM ##Temp_CTE
						SELECT TOP(2) @VAR_OPCL2 = [PP-DIF(CL-OP)] FROM ##Temp_CTE

						SELECT TOP(1) @VAR_IRES1 = [PP-IRES] FROM ##Temp_CTE
						SELECT TOP(2) @VAR_IRES2 = [PP-IRES] FROM ##Temp_CTE

							

							--select * from ##Temp_ITEMPRCLINDDIFF

							IF( (@VAR_OPCL1 <=0.00 AND @VAR_OPCL2<=0.00) OR (@VAR_OPCL1 >0.00 AND @VAR_OPCL2>0.00) )
							BEGIN

								IF(@VAR_OPCL1 = @VAR_OPCL2)
								BEGIN
									INSERT INTO ##Temp_ITEMPRCLINDDIFFRESULT
									SELECT @Var_ITEM_NO,*, 
										((select max([PP-CL]) from ##Temp_ITEMPRCLINDDIFF) - @Var_PRCLIND) AS MxDiff,
										ABS(CONVERT(NUMERIC(10,2),(ABS(@VAR_OPCL1) + ABS(@VAR_OPCL2))/2)) AS AVGRSLT,
										NULL as NETRSLT
									FROM ##Temp_CTE
								END
								ELSE
								BEGIN
									INSERT INTO ##Temp_ITEMPRCLINDDIFFRESULT
									SELECT @Var_ITEM_NO,*, 
										((select max([PP-CL]) from ##Temp_ITEMPRCLINDDIFF) - @Var_PRCLIND) AS MxDiff,
										ABS(CONVERT(NUMERIC(10,2),(ABS(@VAR_OPCL1) - ABS(@VAR_OPCL2)))) AS AVGRSLT,
										NULL as NETRSLT
									FROM ##Temp_CTE
								END
							END 
			
							ELSE
							BEGIN
				
								INSERT INTO ##Temp_ITEMPRCLINDDIFFRESULT
								SELECT @Var_ITEM_NO,*, 
									((select max([PP-CL]) from ##Temp_ITEMPRCLINDDIFF)  - @Var_PRCLIND) AS MxDiff,
									ABS(CONVERT(NUMERIC(10,2),(ABS(@VAR_OPCL1) + ABS(@VAR_OPCL2)))) AS AVGRSLT,
									NULL as NETRSLT
								FROM ##Temp_CTE
							END
			
							IF( (@VAR_IRES1<=0 AND @VAR_IRES2<=0) OR (@VAR_IRES1>0 AND @VAR_IRES2>0))
							BEGIN
								UPDATE ##Temp_ITEMPRCLINDDIFFRESULT
								SET
									NETRSLT = ABS(CONVERT(NUMERIC(10,2), (@VAR_IRES1 + @VAR_IRES2)/2))

							END
							ELSE
							BEGIN
								UPDATE ##Temp_ITEMPRCLINDDIFFRESULT
								SET
									NETRSLT = ABS(CONVERT(NUMERIC(10,2), (@VAR_IRES1 + @VAR_IRES2)))
							END

							DELETE TOP(1) FROM ##Temp_CTE
							DELETE TOP(1) FROM ##Temp_CTE

							INSERT INTO ##Temp_CTE
							SELECT  DISTINCT [PP-CL],
										AVGRSLT as [PP-DIF(CL-OP)],
										NETRSLT as [PP=IRES]
							FROM ##Temp_ITEMPRCLINDDIFFRESULT

			END

			
			INSERT INTO ##Temp_CTE
			SELECT A.*
			FROM ##Temp_ITEMPRCLINDDIFF A JOIN 
			(
			SELECT [PP-CL],
				[PP-DIF(CL-OP)],
				COUNT(*) AS CNT
			FROM ##Temp_ITEMPRCLINDDIFF
			GROUP BY [PP-CL],
				[PP-DIF(CL-OP)]
			HAVING COUNT(*) = 1
			)RSLT
			ON A.[PP-CL] = RSLT.[PP-CL]
			AND A.[PP-DIF(CL-OP)] = RSLT.[PP-DIF(CL-OP)]

			delete from ##Temp_ITEMPRCLINDDIFFRESULT

			SELECT TOP(1) @VAR_OPCL1 = [PP-DIF(CL-OP)] FROM ##Temp_CTE
			SELECT TOP(2) @VAR_OPCL2 = [PP-DIF(CL-OP)] FROM ##Temp_CTE

			SELECT TOP(1) @VAR_IRES1 = [PP-IRES] FROM ##Temp_CTE
			SELECT TOP(2) @VAR_IRES2 = [PP-IRES] FROM ##Temp_CTE


			IF( (@VAR_OPCL1 <=0.00 AND @VAR_OPCL2<=0.00) OR (@VAR_OPCL1 >0.00 AND @VAR_OPCL2>0.00) )
			BEGIN
				
				INSERT INTO ##Temp_ITEMPRCLINDDIFFRESULT
				SELECT @Var_ITEM_NO,*, 
					((select max([PP-CL]) from ##Temp_ITEMPRCLINDDIFF) - @Var_PRCLIND) AS MxDiff,
					ABS(CONVERT(NUMERIC(10,2),(ABS(@VAR_OPCL1) - ABS(@VAR_OPCL2)))) AS AVGRSLT,
					NULL as NETRSLT
				FROM ##Temp_ITEMPRCLINDDIFF
			END 
			
			ELSE
			BEGIN
				
				INSERT INTO ##Temp_ITEMPRCLINDDIFFRESULT
				SELECT @Var_ITEM_NO,*, 
					((select max([PP-CL]) from ##Temp_ITEMPRCLINDDIFF)  - @Var_PRCLIND) AS MxDiff,
					ABS(CONVERT(NUMERIC(10,2),(ABS(@VAR_OPCL1) + ABS(@VAR_OPCL2)))) AS AVGRSLT,
					NULL as NETRSLT
				FROM ##Temp_ITEMPRCLINDDIFF
			END
			
			IF( (@VAR_IRES1<=0 AND @VAR_IRES2<=0) OR (@VAR_IRES1>0 AND @VAR_IRES2>0))
			BEGIN
				UPDATE ##Temp_ITEMPRCLINDDIFFRESULT
				SET
					NETRSLT = (CONVERT(NUMERIC(10,2), (@VAR_IRES1 + @VAR_IRES2)/2))

			END
			ELSE
			BEGIN
				UPDATE ##Temp_ITEMPRCLINDDIFFRESULT
				SET
					NETRSLT = (CONVERT(NUMERIC(10,2), (@VAR_IRES1 + @VAR_IRES2)))
			END
			
			--SELECT * FROM ##Temp_ITEMPRCLINDDIFFRESULT

			UPDATE A
			SET
				A.[PP-PRCL-PPCL/DIF(OP-CL)//NET-AV] = B.MxDiff,
				A.[NET-AVG] = (CAST(NETRSLT AS varchar(20)) + '/' + CAST(AVGRSLT AS varchar(20)) )
			FROM dbo.ProjectHelathEntryResult A join ##Temp_ITEMPRCLINDDIFFRESULT B
			on A.ITEM_NO = B.ITEM_NO
			
			-- new col

		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFFRESULTTR') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLINDDIFFRESULTTR

		SELECT (CONVERT(NUMERIC(10,2),A.[PP-DIF(OP-CL)]) - @Var_330PRCLDIFF) TRRange,
				b.[PP-IRES],
				CONVERT(NUMERIC(10,2),a.[PP-DIF(CL-OP)]) [PP-DIF(OP-CL)],
				b.[PP-CL]
		INTO ##Temp_ITEMPRCLINDDIFFRESULTTR
		FROM dbo.[PP-FILE] A join  ##Temp_ITEMPRCLINDDIFFRESULT B
		on CONVERT(NUMERIC(10,2),A.[PP-CL]) = CONVERT(NUMERIC(10,2),B.[PP-CL])
		AND CONVERT(NUMERIC(10,2),A.[PP-IRES]) = CONVERT(NUMERIC(10,2),B.[PP-IRES])
		AND CONVERT(NUMERIC(10,2),A.[PP-DIF(CL-OP)]) = CONVERT(NUMERIC(10,2),B.[PP-DIF(CL-OP)])

		--SELECT * FROM ##Temp_ITEMPRCLINDDIFFRESULTTR

		DECLARE @VarDiff1 NUMERIC(10,2) = 0.00,
				@VarDiff2 NUMERIC(10,2) = 0.00

		SELECT TOP(1) @VarDiff1 = ABS(TRRange) FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC
		SELECT TOP(1) @VarDiff2 = ABS(TRRange) FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC

		IF( @VarDiff1 < @VarDiff2)
		BEGIN
				SELECT @TR = CAST( ((SELECT TOP(1) [PP-IRES] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC) - (SELECT TOP(1) [PP-IRES] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC)) AS VARCHAR(20))
				+'/' +
				 CAST( ((SELECT TOP(1) [PP-DIF(OP-CL)] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC) - (SELECT TOP(1) [PP-DIF(OP-CL)] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC)) AS VARCHAR(20))

		END
		ELSE IF( @VarDiff1 > @VarDiff2)
		BEGIN
				SELECT @TR = CAST( ((SELECT TOP(1) [PP-IRES] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC) - (SELECT TOP(1) [PP-IRES] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC)) AS VARCHAR(20))
				+'/' +
				 CAST( ((SELECT TOP(1) [PP-DIF(OP-CL)] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC) - (SELECT TOP(1) [PP-DIF(OP-CL)] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC)) AS VARCHAR(20))

		END
		ELSE IF( @VarDiff1 = @VarDiff2)
		BEGIN
				SELECT @TR = CAST( ((SELECT TOP(1) [PP-IRES] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC) + (SELECT TOP(1) [PP-IRES] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC)) AS VARCHAR(20))
				+'/' +
				 CAST( ((SELECT TOP(1) [PP-DIF(OP-CL)] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC) + (SELECT TOP(1) [PP-DIF(OP-CL)] FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC)) AS VARCHAR(20))

		END
		
		--SELECT @TR

		UPDATE dbo.ProjectHelathEntryResult
		SET
			TR = @TR
		WHERE ITEM_NO IN (@Var_ITEM_NO)

		
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[TR/DIF-DIF] = (SELECT TOP(1) TRRange FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange DESC) + (SELECT TOP(1) TRRange FROM ##Temp_ITEMPRCLINDDIFFRESULTTR ORDER BY TRRange ASC)
		WHERE ITEM_NO IN (@Var_ITEM_NO)
			
			
			DELETE TOP(1) FROM ##Temp_ITEMNOCL5114
		END
		-- Dropping all temp tables

		IF OBJECT_ID('tempdb..##Temp_ITEMNOCL5114') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOCL5114
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFFRESULTTR') IS NOT NULL
	    DROP TABLE ##Temp_ITEMPRCLINDDIFFRESULTTR
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFFRESULT') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLINDDIFFRESULT
		IF OBJECT_ID('tempdb..##Temp_CTE') IS NOT NULL
		DROP TABLE ##Temp_CTE
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLINDDIFF') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLINDDIFF
		IF OBJECT_ID('tempdb..##Temp_ITEMPRCLIND') IS NOT NULL
		DROP TABLE ##Temp_ITEMPRCLIND