/*
select * from dbo.ProjectHelathEntry

--delete from dbo.ProjectHelathEntry where ITEM_NO not in (1057)


select * from dbo.ProjectHelathEntryResult

;WITH CTE_REDAVGPOS
		AS
		(
				SELECT id,
					(CASE WHEN ISNULL(Res1, 0) >0.00
							THEN Res1
							else 0.00
						END
						) as Res1 ,
						
						(CASE WHEN ISNULL(Res2, 0) >0.00
							THEN Res2
							else 0.00
						END
						) as Res2,
						
						(CASE WHEN ISNULL(Res3, 0) >0.00
							THEN Res3
							else 0.00
						END
						) as Res3
						,
						(CASE WHEN ISNULL(Res4, 0) >0.00
							THEN Res4
							else 0.00
						END
						) as Res4
						,
						(CASE WHEN ISNULL(Res5, 0) >0.00
							THEN Res5
							else 0.00
						END
						) as Res5
						,
						(CASE WHEN ISNULL(Res6, 0) >0.00
							THEN Res6
							else 0.00
						END
						) as Res6
						,
						(CASE WHEN ISNULL(Res7, 0) >0.00
							THEN Res7
							else 0.00
						END
						) as Res7
						,
						(CASE WHEN ISNULL(Res8, 0) >0.00
							THEN Res8
							else 0.00
						END
						) as Res8
						,
						(CASE WHEN ISNULL(Res9, 0) >0.00
							THEN Res9
							else 0.00
						END
						) as Res9 
				FROM dbo.ProjectHelathEntryResult
		)

SELECT id,
	(case when Res1= 0.00
			then 0
			else 1 
		end
		+
		case when Res2= 0.00
			then 0
			else 1 
		end
		+
		case when Res3= 0.00
			then 0
			else 1 
		end
		+
		case when Res4= 0.00
			then 0
			else 1 
		end
		+
		case when Res5= 0.00
			then 0
			else 1 
		end
		+
		case when Res6= 0.00
			then 0
			else 1 
		end
		+
		case when Res7= 0.00
			then 0
			else 1 
		end
		+
		case when Res8= 0.00
			then 0
			else 1 
		end
		+
		case when Res9= 0.00
			then 0
			else 1 
		end
		) as TOTALCNT,
		(Res1+Res2+Res3+Res4+Res5+Res6+Res7+Res8+Res9) as TOTPOS
FROM CTE_REDAVGPOS

;WITH CTE_REDAVGNEG
AS
(
		SELECT id,(CASE WHEN ISNULL(Res1, 0) <=0.00
					THEN ISNULL(Res1,0)
					else 0.00
				END
				) AS Res1
			,
			(CASE WHEN ISNULL(Res2, 0) <=0.00
					THEN ISNULL(Res2,0)
					else 0.00
				END
			)  AS Res2
			,
			(CASE WHEN ISNULL(Res3, 0) <=0.00
					THEN ISNULL(Res3,0)
					ELSE 0.00
				END
			)  AS Res3
			,
			(CASE WHEN ISNULL(Res4, 0) <=0.00
					THEN ISNULL(Res4,0)
					ELSE 0.00
				END
			) AS Res4
			,
			(CASE WHEN ISNULL(Res5, 0) <=0.00
					THEN ISNULL(Res5,0)
					else 0.00
				END
			)  AS Res5
			,
			(CASE WHEN ISNULL(Res6, 0) <=0.00
					THEN ISNULL(Res6,0)
					else 0.00
				END
			) AS Res6
			,
			(CASE WHEN ISNULL(Res7, 0) <=0.00
					THEN ISNULL(Res7,0)
					ELSE 0.00
				END
			) AS Res7 
			,
			(CASE WHEN ISNULL(Res8, 0) <=0.00
					THEN ISNULL(Res8,0)
					ELSE 0.00
				END
			) AS Res8
			,
			(CASE WHEN ISNULL(Res9, 0) <=0.00
					THEN ISNULL(Res9,0)
					ELSE 0.00
				END
			)  AS Res9
		FROM dbo.ProjectHelathEntryResult				
)
SELECT id,
	(case when Res1= 0.00
			then 0
			else 1 
		end
		+
		case when Res2= 0.00
			then 0
			else 1 
		end
		+
		case when Res3= 0.00
			then 0
			else 1 
		end
		+
		case when Res4= 0.00
			then 0
			else 1 
		end
		+
		case when Res5= 0.00
			then 0
			else 1 
		end
		+
		case when Res6= 0.00
			then 0
			else 1 
		end
		+
		case when Res7= 0.00
			then 0
			else 1 
		end
		+
		case when Res8= 0.00
			then 0
			else 1 
		end
		+
		case when Res9= 0.00
			then 0
			else 1 
		end
		) as TOTALCNT,
		(Res1+Res2+Res3+Res4+Res5+Res6+Res7+Res8+Res9) as TOTNEG
FROM CTE_REDAVGNEG


select * from dbo.ProjectHelathEntryResult


*/
--[TOT/RED/AVG-POS]


--==============================
/*
DECLARE @NoofCells INT = 200,
				@Var_ITEM_NO INT

		IF OBJECT_ID('tempdb..##Temp_ITEMNOC512') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC512

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC512
		FROM ProjectHelathEntry order by ITEM_NO DESC


		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC512)>0
		BEGIN
		SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC512
		;WITH CTE_PAVG
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'RED'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'RED'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG))

		-- 2ND ROW
		;WITH CTE_PAVG2
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'RED'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'RED'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG2)+1)

		-- 3rd ROW
		;WITH CTE_PAVG3
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'RED'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'RED'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG3)+2)

		
		-- INC
		;WITH CTE_PAVGINC
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'INC'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVGINC) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVGINC) + 2)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVGINC) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'INC'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVGINC))
		
		-- 2ND ROW
		;WITH CTE_PAVG2
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'INC'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG2) + 1)) - (SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG2) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'INC'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG2)+1)

		-- 3rd ROW
		;WITH CTE_PAVG3
		AS
		(
		SELECT id,
				ITEM_NO
				[RED/INC],
				[RED/AVG-POS],
				[RED/AVG-NEG]
		from dbo.ProjectHelathEntryResult
		WHERE [RED/INC] = 'INC'
		and ITEM_NO in (@Var_ITEM_NO)
		)
		UPDATE dbo.ProjectHelathEntryResult
		SET
			[RED-P/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-POS],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
				END 
		),
			[RED-N/13&12&23ROWS-TR] = 
		(
		SELECT CASE WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) )>0
					THEN 'UP/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
					WHEN ( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) ) = 0
					THEN 'FL'
					ELSE 'DW/' + CAST(( (SELECT  ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3 WHERE ID IN ((SELECT TOP(1) Id FROM CTE_PAVG3) + 2)) - ((SELECT TOP(1) ISNULL([RED/AVG-NEG],0) FROM CTE_PAVG3)+1) ) AS varchar(50))
				END 
		)
		WHERE  [RED/INC] = 'INC'
		AND ITEM_NO in (@Var_ITEM_NO)
		AND ID in ((select top(1) ID from CTE_PAVG3)+2)

		
		DELETE TOP(1) FROM ##Temp_ITEMNOC512
	END
*/
-- DW UP COUNT
--=====================

		DECLARE @NoofCells INT = 200,
				@Var_ITEM_NO INT

		IF OBJECT_ID('tempdb..##Temp_ITEMNOC513') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOC513

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOC513
		FROM ProjectHelathEntry order by ITEM_NO DESC


		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOC513)>0
		BEGIN
			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOC513

			;WITH CTE_UPDW
			AS
			(
				SELECT ID,( (CASE WHEN [RED-P/13&12&23ROWS-TR] like 'UP%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-P/13&12&23ROWS-TR],'UP/',''))
						ELSE 0.00
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'UP%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-N/13&12&23ROWS-TR],'UP/',''))
						ELSE 0.00
					END)
				) AS [UP/SUM],
				((CASE WHEN [RED-P/13&12&23ROWS-TR] like 'DW%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-P/13&12&23ROWS-TR],'DW/',''))
						ELSE 0.00
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'DW%'
						THEN CONVERT(NUMERIC(10,2),REPLACE([RED-N/13&12&23ROWS-TR],'DW/',''))
						ELSE 0.00
					END)
				) as [DW/SUM],
				( (CASE WHEN [RED-P/13&12&23ROWS-TR] like 'UP%'
						THEN 1
						ELSE 0
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'UP%'
						THEN 1
						ELSE 0
					END)
				) AS [UP/CNT],
				((CASE WHEN [RED-P/13&12&23ROWS-TR] like 'DW%'
						THEN 1
						ELSE 0
					END)
					+
					(CASE WHEN [RED-N/13&12&23ROWS-TR] like 'DW%'
						THEN 1
						ELSE 0
					END)
				) as [DW/CNT]

			FROM dbo.ProjectHelathEntryResult(nolock)
			WHERE ITEM_NO IN (@Var_ITEM_NO)
			)

			UPDATE A
			set
				A.[UP/SUM] = B.[UP/SUM],
				A.[DW/SUM] = B.[DW/SUM],
				A.[UP/CNT] = B.[UP/CNT],
				A.[DW/CNT] = B.[DW/CNT]
			FROM dbo.ProjectHelathEntryResult A join CTE_UPDW B
			on A.Id = B.Id

		DELETE TOP(1) FROM ##Temp_ITEMNOC513
		END



















