Declare @VarSum VARCHAR(50)
		
		IF(@Var_ITEM_NO like '%U')
		BEGIN
				;WITH CTE_UPSUMRED 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/SUM] AS UP_SUM_RED,
						[DW/SUM] AS DW_SUM_RED
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
					and [RED/INC] = 'RED'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+1)
				),
				CTE_UPSUMINC 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/SUM] AS UP_SUM_INC,
						[DW/SUM] AS DW_SUM_INC
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
					and [RED/INC] = 'INC'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)
				)
				SELECT @VarSum = 'UP/' + cast(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),A.UP_SUM_INC) + CONVERT(NUMERIC(10,2),B.UP_SUM_RED))) as varchar(20))
						FROM CTE_UPSUMINC A JOIN CTE_UPSUMRED B
						ON A.ITEM_NO = B.ITEM_NO
		END
		ELSE IF(@Var_ITEM_NO like '%D')
		BEGIN
			;WITH CTE_DWSUMRED 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/SUM] AS UP_SUM_RED,
						[DW/SUM] AS DW_SUM_RED
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D','')))
					and [RED/INC] = 'RED'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D',''))) and [RED/INC] = 'RED' )+1)
				),
				CTE_DWSUMINC 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/SUM] AS UP_SUM_INC,
						[DW/SUM] AS DW_SUM_INC
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D','')))
					and [RED/INC] = 'INC'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D',''))) and [RED/INC] = 'INC' )+1)
				)
				SELECT @VarSum = 'DW/' + CAST( convert(numeric(10,2),(CONVERT(NUMERIC(10,2),A.DW_SUM_INC) + CONVERT(NUMERIC(10,2),B.DW_SUM_RED))) as varchar(20))
						FROM CTE_DWSUMINC A JOIN CTE_DWSUMRED B
						ON A.ITEM_NO = B.ITEM_NO
		END

		RETURN @VarSum
	