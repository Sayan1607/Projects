ALTER function dbo.fn_CalculateCountSum(@Cnt1 Varchar(50), @Cnt2 Varchar(50), @Cnt3 Varchar(50))
returns varchar(10)
AS
BEGIN
	return '[' + cast(convert(SMALLINT,SUBSTRING(@Cnt1,2,CHARINDEX('/',@Cnt1)-2))+
					convert(SMALLINT,SUBSTRING(@Cnt2,2,CHARINDEX('/',@Cnt2)-2))+
					convert(SMALLINT,SUBSTRING(@Cnt3,2,CHARINDEX('/',@Cnt3)-2)) AS VARCHAR(10)) +'/' +

			cast(CONVERT(SMALLINT,substring((replace(replace(@Cnt1,'[',''),']','')),charindex('/', (replace(replace(@Cnt1,'[',''),']','')))+1, len( (replace(replace(@Cnt1,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt1,'[',''),']','')))) )+
					convert(SMALLINT,substring((replace(replace(@Cnt2,'[',''),']','')),charindex('/', (replace(replace(@Cnt2,'[',''),']','')))+1, len( (replace(replace(@Cnt2,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt2,'[',''),']','')))))+
					convert(SMALLINT,substring((replace(replace(@Cnt3,'[',''),']','')),charindex('/', (replace(replace(@Cnt3,'[',''),']','')))+1, len( (replace(replace(@Cnt3,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt3,'[',''),']',''))))) AS VARCHAR(10)) 
			+']'
END