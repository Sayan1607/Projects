
DECLARE @Var_Item_No INT,
		@NoofCells INT = 20
		IF OBJECT_ID('tempdb..##Temp_ITEMNOCL513') IS NOT NULL
		DROP TABLE ##Temp_ITEMNOCL513

		SELECT DISTINCT top(@NoofCells) ITEM_NO
		INTO ##Temp_ITEMNOCL513
		FROM ProjectHelathEntry order by ITEM_NO DESC


		WHILE(SELECT COUNT(*) FROM ##Temp_ITEMNOCL513)>0
		BEGIN
			SELECT TOP(1) @Var_ITEM_NO = ITEM_NO FROM ##Temp_ITEMNOCL513


						UPDATE A
						SET
							[13&12&23/UP/CNT] = ResultL.Result,
							[UP/AMT-AVG] = ResultL.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'UP' + CAST( (convert(smallint,a.[UP/CNT]) + Convert(smallInt,b.[UP/CNT])) AS varchar(20)) as Result,
								'UP' + CAST( (convert(numeric(10,2),a.[UP/SUM]) + Convert(numeric(10,2),b.[UP/SUM])) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED')
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC')
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL
						ON A.ITEM_NO = ResultL.ITEM_NO
						WHERE A.[RED/INC] = 'RED'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)

						UPDATE A
						SET
							[13&12&23/ DW/CNT] = ResultL1.Result,
							[DW/AMT-AVG] = ResultL1.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'DW' + CAST( (convert(smallint,a.[DW/CNT]) + Convert(smallInt,b.[DW/CNT])) AS varchar(20)) as Result,
								'DW' + CAST( (convert(numeric(10,2),a.[DW/SUM]) + Convert(numeric(10,2),b.[DW/SUM])) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED')
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC')
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL1
						ON A.ITEM_NO = ResultL1.ITEM_NO
						WHERE A.[RED/INC] = 'RED'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)

						--23 row
						UPDATE A
						SET
							[13&12&23/UP/CNT] = ResultL2.Result,
							[UP/AMT-AVG] = ResultL2.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'UP' + CAST( (convert(smallint,a.[UP/CNT]) + Convert(smallInt,b.[UP/CNT])) AS varchar(20)) as Result,
								'UP' + CAST( (convert(numeric(10,2),a.[UP/SUM]) + Convert(numeric(10,2),b.[UP/SUM])) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC') + 2)
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL2
						ON A.ITEM_NO = ResultL2.ITEM_NO
						WHERE A.[RED/INC] = 'INC'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC'))

						UPDATE A
						SET
							[13&12&23/ DW/CNT] = ResultL3.Result,
							[DW/AMT-AVG] = ResultL3.AMTavg
						FROM dbo.ProjectHelathEntryResult A join
						(
						SELECT a.ITEM_NO, 
								'DW' + CAST( (convert(smallint,a.[DW/CNT]) + Convert(smallInt,b.[DW/CNT])) AS varchar(20)) as Result,
								'DW' + CAST( (convert(numeric(10,2),a.[DW/SUM]) + Convert(numeric(10,2),b.[DW/SUM])) AS varchar(20)) as AMTavg
						FROM 
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'RED'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'RED') + 2)
						)A join
						(
								SELECT *
								FROM dbo.ProjectHelathEntryResult
								where ITEM_NO in (@Var_Item_No)
								and [RED/INC] = 'INC'
								and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC') + 2)
						)B
						on A.ITEM_NO = b.ITEM_NO
						)ResultL3
						ON A.ITEM_NO = ResultL3.ITEM_NO
						WHERE A.[RED/INC] = 'INC'
						and id IN ( (SELECT top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_Item_No) and [RED/INC] = 'INC'))

		DELETE TOP(1) FROM ##Temp_ITEMNOCL513
		END
