
select * from [dbo].[PP-FILE]


CREATE TABLE [dbo].[ProjectHealth_IntermediaryC2](
	[ITEM_NO]	INT NOT NULL,
	[L/H-IND-CNT1] [nchar](10) NULL,
	[L/H-IND-CNT2] [nchar](10) NULL,
	[L/H-IND-CNT3] [nchar](10) NULL
) ON [PRIMARY]
GO
