ALTER PROCEDURE SP_Loaddifferentset
AS
BEGIN
		DECLARE @Var_ITEM_NO INT

		IF OBJECT_ID('tempdb..##Tem_ITEM_NO') IS NOT NULL
		DROP TABLE ##Tem_ITEM_NO

		select distinct [ITEM_NO]
		into ##Tem_ITEM_NO
		from dbo.ProjectHelathEntryResult

		IF OBJECT_ID('tempdb..##Temp_ProjectHelathEntryResult') IS NOT NULL
		DROP TABLE ##Temp_ProjectHelathEntryResult

		SELECT [ITEM_NO],
								[PR-DATE],
								[PRCL-IND],
								[330-IND],
								[S1C2],
								[UD1],
								[L/H-IND-CNT1],
								[UD2],
								[L/H-IND-CNT2],
								[UD3],
								[L/H-IND-CNT3],
								[PRCL-NXTDCL-DIF],
								[N/P-C2-CNT1],
								[N/P-C2-CNT2],
								[N/P-C2-CNT3],
								[RED/INC],
								[PP-RNG-UD],
								[GAP-LMT],
								[IND-GAP],
								[LIND],
								[MIND],
								[Res9],
								[Res8],
								[Res7],
								[Res6],
								[Res5],
								[Res4],
								[Res3],
								[Res2],
								[Res1],
								[TOT],
								[ALL-CNT(P/N)],
								[GREEN],
								[ACC],
								[COMM],
								[IRES]
						into ##Temp_ProjectHelathEntryResult
						from dbo.ProjectHelathEntryResult 

		TRUNCATE TABLE dbo.ProjectHelathEntryResult 

		WHILE EXISTS(select top(1) ITEM_NO FROM  ##Tem_ITEM_NO)
		begin

				select top(1)  @Var_ITEM_NO = ITEM_NO FROM  ##Tem_ITEM_NO

					insert into dbo.ProjectHelathEntryResult 
					select A.*
					from
					(
						select	[ITEM_NO],
								[PR-DATE],
								[PRCL-IND],
								[330-IND],
								[S1C2],
								[UD1],
								[L/H-IND-CNT1],
								[UD2],
								[L/H-IND-CNT2],
								[UD3],
								[L/H-IND-CNT3],
								[PRCL-NXTDCL-DIF],
								[N/P-C2-CNT1],
								[N/P-C2-CNT2],
								[N/P-C2-CNT3],
								[RED/INC],
								[PP-RNG-UD],
								[GAP-LMT],
								[IND-GAP],
								[LIND],
								[MIND],
								[Res9],
								[Res8],
								[Res7],
								[Res6],
								[Res5],
								[Res4],
								[Res3],
								[Res2],
								[Res1],
								[TOT],
								[ALL-CNT(P/N)],
								[GREEN],
								[ACC],
								[COMM],
								[IRES]
						from ##Temp_ProjectHelathEntryResult
						where ITEM_NO = @Var_ITEM_NO
		
						union 

						select	[ITEM_NO],
								[PR-DATE],
								[PRCL-IND],
								[330-IND],
								[S1C2],
								[UD1],
								[L/H-IND-CNT1],
								[UD2],
								[L/H-IND-CNT2],
								[UD3],
								[L/H-IND-CNT3],
								[PRCL-NXTDCL-DIF],
								[N/P-C2-CNT1],
								[N/P-C2-CNT2],
								[N/P-C2-CNT3],
								[RED/INC],
								0.05 [PP-RNG-UD],
								[GAP-LMT],
								[IND-GAP],
								[LIND],
								[MIND],
								[Res9],
								[Res8],
								[Res7],
								[Res6],
								[Res5],
								[Res4],
								[Res3],
								[Res2],
								[Res1],
								[TOT],
								[ALL-CNT(P/N)],
								[GREEN],
								[ACC],
								[COMM],
								[IRES]
						from ##Temp_ProjectHelathEntryResult 
						where ITEM_NO = @Var_ITEM_NO

						union 

						select	[ITEM_NO],
								[PR-DATE],
								[PRCL-IND],
								[330-IND],
								[S1C2],
								[UD1],
								[L/H-IND-CNT1],
								[UD2],
								[L/H-IND-CNT2],
								[UD3],
								[L/H-IND-CNT3],
								[PRCL-NXTDCL-DIF],
								[N/P-C2-CNT1],
								[N/P-C2-CNT2],
								[N/P-C2-CNT3],
								[RED/INC],
								0.10 [PP-RNG-UD],
								[GAP-LMT],
								[IND-GAP],
								[LIND],
								[MIND],
								[Res9],
								[Res8],
								[Res7],
								[Res6],
								[Res5],
								[Res4],
								[Res3],
								[Res2],
								[Res1],
								[TOT],
								[ALL-CNT(P/N)],
								[GREEN],
								[ACC],
								[COMM],
								[IRES]
						from ##Temp_ProjectHelathEntryResult
						where ITEM_NO = @Var_ITEM_NO
					)A
					order by A.[RED/INC] desc

				DELETE TOP(1) from ##Tem_ITEM_NO

		END

END
