
SELECT Result.ITEM_NO,
		Result.UD1,
		Result.UD2,
		Result.UD3,
		Result.[RED/INC],
		Result.C_PERCENT
FROM 
(
		select ITEM_NO,
				UD1,
				NULL AS UD2,
				NULL AS UD3,
				[RED/INC],
				CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/100)) AS varchar(10)) +'%' AS C_PERCENT 

		from dbo.ProjectHelathEntryResultP2
		WHERE [ACC/TOT] = 'C'
		GROUP BY ITEM_NO,
				UD1,
				[RED/INC]

		union


		select ITEM_NO,
				NULL AS UD1,
				UD2,
				NULL AS UD3,
				[RED/INC],
				CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/100)) AS varchar(10)) +'%' AS C_PERCENT 

		from dbo.ProjectHelathEntryResultP2
		WHERE [ACC/TOT] = 'C'
		GROUP BY ITEM_NO,
				UD2,
				[RED/INC]

		UNION


		select ITEM_NO,
				NULL AS UD1,
				NULL AS UD2,
				UD3,
				[RED/INC],
				CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/100)) AS varchar(10)) +'%' AS C_PERCENT 

		from dbo.ProjectHelathEntryResultP2
		WHERE [ACC/TOT] = 'C'
		GROUP BY ITEM_NO,
				UD3,
				[RED/INC]

		union

		select ITEM_NO,
				NULL AS UD1,
				NULL AS UD2,
				NULL AS UD3,
				'RED SUB-TOT' as [RED/INC],
				CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/100)) AS varchar(10)) +'%' AS C_PERCENT 

		from dbo.ProjectHelathEntryResultP2
		WHERE  [RED/INC] = 'RED' and [ACC/TOT] = 'C'
		GROUP BY ITEM_NO

		union 

		select ITEM_NO,
				NULL AS UD1,
				NULL AS UD2,
				NULL AS UD3,
				'INC SUB-TOT' as [RED/INC],
				CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/100)) AS varchar(10)) +'%' AS C_PERCENT 

		from dbo.ProjectHelathEntryResultP2
		WHERE  [RED/INC] = 'INC' and [ACC/TOT] = 'C'
		GROUP BY ITEM_NO

		union

		select ITEM_NO,
		NULL AS UD1,
		NULL AS UD2,
		NULL AS UD3,
		'TOT RED INC' as [RED/INC],
		CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/100)) AS varchar(10)) +'%' AS C_PERCENT 

		from dbo.ProjectHelathEntryResultP2
		WHERE [ACC/TOT] = 'C'
		GROUP BY ITEM_NO

)Result
order by Result.ITEM_NO asc,Result.[RED/INC] asc

