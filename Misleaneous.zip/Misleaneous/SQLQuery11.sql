USE [ProjectHealth]
GO

/****** Object:  Table [dbo].[ProjectHelathEntryResult]    Script Date: 14/05/2021 11:20:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProjectHelathEntryResult](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ITEM_NO] [int] NOT NULL,
	[PVCL-IND] [numeric](10, 2) NULL,
	[330-IND] [numeric](10, 2) NULL,
	[S1C2] [numeric](10, 2) NULL,
	[UD1] [numeric](10, 2) NULL,
	[L/H-IND-CNT1] [nchar](10) NULL,
	[UD2] [numeric](10, 2) NULL,
	[L/H-IND-CNT2] [nchar](10) NULL,
	[UD3] [numeric](10, 2) NULL,
	[L/H-IND-CNT3] [nchar](10) NULL,
	[PRCL-NXTDCL-DIF] [nchar](10) NULL,
	[N/P-C2-CNT1] [nchar](10) NULL,
	[N/P-C2-CNT2] [nchar](10) NULL,
	[N/P-C2-CNT3] [nchar](10) NULL,
	[RED/INC] [NCHAR](3) NULL,
	[PP-RNG-UD] [nchar](10) NULL,
	[GAP-LMT] [int] NOT NULL,
	[IND-GAP] [numeric](10, 2) NULL,
	[LIND] [numeric](10, 2) NULL,
	[MIND] [numeric](10, 2) NULL,
	[Res9] [numeric](10, 2) NULL,
	[Res8] [numeric](10, 2) NULL,
	[Res7] [numeric](10, 2) NULL,
	[Res6] [numeric](10, 2) NULL,
	[Res5] [numeric](10, 2) NULL,
	[Res4] [numeric](10, 2) NULL,
	[Res3] [numeric](10, 2) NULL,
	[Res2] [numeric](10, 2) NULL,
	[Res1] [numeric](10, 2) NULL,
	[TOT] [numeric](10, 2) NULL,
	[ALL-CNT(P/N)] [nchar](10) NULL,
	[GREEN] [nchar](10) NULL,
	[ACC] [nchar](1) NULL,
	[COMM] [nvarchar](max) NULL,
	[IRES] [numeric](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


