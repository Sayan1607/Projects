
CREATE TABLE Temp_Results
(
	
	Res1 Numeric(10,2) NULL,
	Res2 Numeric(10,2) NULL,
	Res3 Numeric(10,2) NULL,
	Res4 Numeric(10,2) NULL,
	Res5 Numeric(10,2) NULL,
	Res6 Numeric(10,2) NULL,
	Res7 Numeric(10,2) NULL,
	Res8 Numeric(10,2) NULL,
	Res9 Numeric(10,2) NULL
)