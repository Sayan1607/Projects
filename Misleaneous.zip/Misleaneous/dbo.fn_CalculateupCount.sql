ALTER FUNCTION dbo.fn_CalculateupCount
(
	@ITEMNO VARCHAR(50)
)
RETURNS INT
AS 
BEGIN
	Declare @VarSum INT = 0
	
	select @VarSum = CASE WHEN @ITEMNO like '%U'
				THEN  (SELECT sum(convert(smallint,[UP/CNT])) from dbo.ProjectHelathEntryResult where ITEM_NO in (CONVERT(SMALLINT,REPLACE(@ITEMNO,'U',''))))
				ELSE (SELECT sum(convert(smallint,[DW/CNT])) from dbo.ProjectHelathEntryResult where ITEM_NO in (CONVERT(SMALLINT,REPLACE(@ITEMNO,'D',''))))
		END

	Return  @VarSum
END