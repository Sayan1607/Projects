
ALTER PROCEDURE dbo.SP_CalculateCloseRange
(
	@ITEMNO	INT
)
AS
BEGIN
		--Declare @ITEMNO INT = 1064

		IF OBJECT_ID('tempdb..##TEMP_RESULTP') IS NOT NULL
		DROP TABLE ##TEMP_RESULTP

		IF OBJECT_ID('tempdb..##TEMP_PPCLRESULT') IS NOT NULL
		DROP TABLE ##TEMP_PPCLRESULT

		Declare @PrclInd	numeric(10,2),
				@VarMaxDiff	Numeric(10,2),
				@VarPRCLMaxDiff	NUMERIC(10,2),
				@33OIND	NUMERIC(10,2),
				@RNG1	NUMERIC(10,2),
				@RNG2	NUMERIC(10,2),
				@RNG3	NUMERIC(10,2),
				@RNG4	NUMERIC(10,2),
				@varTemp NUMERIC(10,2),
				@VarResl	INT


		select @PrclInd = PRCL_IND,@33OIND =[330_IND] from dbo.ProjectHelathEntry where ITEM_NO in (@ITEMNO)

			;WITH CTE_LOWVAL
			AS
			(
			SELECT TOP(1) [PP-OP]
			FROM DBO.[PP-FILE]
			WHERE [PP-OP] < @PrclInd
			ORDER BY [PP-OP]  DESC
			),
			CTE_HIGHVAL
			AS
			(
			SELECT TOP(1) [PP-OP]
			FROM DBO.[PP-FILE]
			WHERE [PP-OP] > @PrclInd
			ORDER BY [PP-OP]  ASC
			)
			SELECT CTE_LOWVAL.[PP-OP] as L_LMT, 
					(CTE_LOWVAL.[PP-OP] - @PrclInd) as LGAP,
					CTE_HIGHVAL.[PP-OP] as H_LMT,
					(CTE_HIGHVAL.[PP-OP] - @PrclInd) as HGAP
			INTO ##TEMP_RESULTP
			FROM CTE_LOWVAL, CTE_HIGHVAL

			--SELECT * FROM ##TEMP_RESULT

			SELECT @RNG1 = CASE WHEN ABS(LGAP) > ABS(HGAP)
						THEN (@PrclInd + ABS(LGAP))
						WHEN ABS(HGAP) > ABS(LGAP)
						THEN (@PrclInd- ABS(HGAP))
					END,
					@RNG2 = CASE WHEN ABS(LGAP) > ABS(HGAP)
						THEN L_LMT
						WHEN ABS(HGAP) > ABS(LGAP)
						THEN H_LMT
					END
			FROM ##TEMP_RESULTP

			--PRINT @RNG1
			--PRINT @RNG2

			IF (@RNG1> @RNG2)
			BEGIN
				SET @varTemp = @RNG1
				SET @RNG1 = @RNG2
				SET @RNG2 = @varTemp
			END

			--PRINT @RNG1
			--PRINT @RNG2

			 WHILE((SELECT COUNT(distinct [PP-OP]) FROM dbo.[PP-FILE] where ([PP-OP] between @RNG1 and @RNG2)and [PP-OP] not in (@PrclInd))<2)
			 BEGIN
				UPDATE ##TEMP_RESULTP
				set
					L_LMT = L_LMT - 0.01,
					H_LMT = H_LMT + 0.01

				  SELECT @RNG1 = CASE WHEN ABS(LGAP) > ABS(HGAP)
							THEN (@PrclInd + ABS(LGAP))
							WHEN ABS(HGAP) > ABS(LGAP)
							THEN (@PrclInd- ABS(HGAP))
						END,
						@RNG2 = CASE WHEN ABS(LGAP) > ABS(HGAP)
							THEN L_LMT
							WHEN ABS(HGAP) > ABS(LGAP)
							THEN H_LMT
						END
				FROM ##TEMP_RESULTP
				IF (@RNG1> @RNG2)
				BEGIN
					SET @varTemp = @RNG1
					SET @RNG1 = @RNG2
					SET @RNG2 = @varTemp
				END

			 END
			
			 --select * FROM dbo.[PP-FILE] where [PP-OP] between  @RNG1 and @RNG2

	 			 -- 330 IND
			 ;WITH CTE_PPCLLOWVAL
			AS
			(
			SELECT TOP(1) [PP-CL]
			FROM dbo.[PP-FILE]
			WHERE [PP-OP] between   @RNG1 and @RNG2 
			and[PP-CL] < @33OIND
			ORDER BY [PP-CL]  DESC
			),
			CTE_PPCLHIGHVAL
			AS
			(
			SELECT TOP(1) [PP-CL]
			FROM dbo.[PP-FILE]
			WHERE [PP-OP] between  @RNG1 and @RNG2 
			and [PP-CL] > @33OIND
			ORDER BY [PP-CL]  asc
			)
			SELECT CTE_PPCLLOWVAL.[PP-CL] as L_LMT, 
					(CTE_PPCLLOWVAL.[PP-CL] - @33OIND) AS LGAP,
					CTE_PPCLHIGHVAL.[PP-CL] as H_LMT,
					(CTE_PPCLHIGHVAL.[PP-CL] - @33OIND) AS HGAP
			INTO ##TEMP_PPCLRESULT
			FROM CTE_PPCLLOWVAL, CTE_PPCLHIGHVAL

			--SELECT * FROM ##TEMP_PPCLRESULT

			SELECT @RNG3 = CASE WHEN ABS(LGAP) > ABS(HGAP)
						THEN (@33OIND + ABS(LGAP))
						WHEN ABS(HGAP) > ABS(LGAP)
						THEN (@33OIND- ABS(HGAP))
					END,
					@RNG4 = CASE WHEN ABS(LGAP) > ABS(HGAP)
						THEN L_LMT
						WHEN ABS(HGAP) > ABS(LGAP)
						THEN H_LMT
					END
			FROM ##TEMP_PPCLRESULT

			PRINT @RNG3
			PRINT @RNG4
			IF (@RNG3> @RNG4)
			BEGIN
				SET @varTemp = @RNG3
				SET @RNG3 = @RNG4
				SET @RNG4 = @varTemp
			END


			while (select COUNT(distinct [PP-CL]) FROM dbo.[PP-FILE] where [PP-OP] between   @RNG1 and @RNG2  and [PP-CL] between @RNG3 and @RNG4 and [PP-CL] NOT IN (@33OIND))<2
			begin
				update ##TEMP_PPCLRESULT
				set
					L_LMT = L_LMT - 0.01,
					H_LMT = H_LMT + 0.01
				
				  SELECT @RNG3 = CASE WHEN ABS(LGAP) > ABS(HGAP)
						THEN (@33OIND + ABS(LGAP))
						WHEN ABS(HGAP) > ABS(LGAP)
						THEN (@33OIND- ABS(HGAP))
					END,
					@RNG4 = CASE WHEN ABS(LGAP) > ABS(HGAP)
						THEN L_LMT
						WHEN ABS(HGAP) > ABS(LGAP)
						THEN H_LMT
					END
				FROM ##TEMP_PPCLRESULT

				IF (@RNG3> @RNG4)
				BEGIN
					SET @varTemp = @RNG3
					SET @RNG3 = @RNG4
					SET @RNG4 = @varTemp
				END
			end

			--print '@RNG1-->' + cast(@RNG1 as varchar(10)) + '@RNG2-->' + cast(@RNG2 as varchar(10)) + '@RNG3-->' + cast(@RNG3 as varchar(10)) + '@RNG4-->' + cast(@RNG4 as varchar(10))

			select top(1) @RNG3 = [PP-CL] 
			from dbo.[PP-FILE]
			where [PP-OP] between   @RNG1 and @RNG2  
			and [PP-CL]<@33OIND and [PP-CL]>=@RNG3
			order by [PP-CL] desc

			select top(1) @RNG4 = [PP-CL] 
			from dbo.[PP-FILE]
			where [PP-OP] between   @RNG1 and @RNG2  
			and [PP-CL]>@33OIND and [PP-CL]<=@RNG3
			order by [PP-CL] asc

			--print '@RNG1-->' + cast(@RNG1 as varchar(10)) + '@RNG2-->' + cast(@RNG2 as varchar(10)) + '@RNG3-->' + cast(@RNG3 as varchar(10)) + '@RNG4-->' + cast(@RNG4 as varchar(10))

			--select *
			-- FROM dbo.[PP-FILE] 
			-- where [PP-OP] between   @RNG1 and @RNG2 
			-- and [PP-CL] between  @RNG3 and @RNG4 and [PP-CL] not in (@33OIND)
			 --order by [PP-CL] DESC

			;WITH CTE_HIRES
			AS
			(
			 select top(1) [PP-IRES]
			 FROM dbo.[PP-FILE] 
			 where [PP-OP] between  @RNG1 and @RNG2 
			 and [PP-CL] between  @RNG3 and @RNG4 and [PP-CL] not in (@33OIND)
			 order by [PP-CL] DESC
			 ),
			CTE_LIRES
			AS
			(
			 select top(1) [PP-IRES]
			 FROM dbo.[PP-FILE] 
			 where [PP-OP] between   @RNG1 and @RNG2 
			 and [PP-CL] between  @RNG3 and @RNG4 and [PP-CL] not in (@33OIND)
			 order by [PP-CL] ASC
			 )
			 UPDATE dbo.ProjectHelathEntryResult
			 set
				[PP-PRCL-PPOP/33IND-PPCL/NET-AVG] = (SELECT CASE WHEN CONVERT(NUMERIC(10,2),CTE_HIRES.[PP-IRES]) < 0 
																THEN ABS(CONVERT(NUMERIC(10,2),CTE_HIRES.[PP-IRES]) - CONVERT(NUMERIC(10,2),CTE_LIRES.[PP-IRES])) 
																ELSE (CONVERT(NUMERIC(10,2),CTE_HIRES.[PP-IRES]) - CONVERT(NUMERIC(10,2),CTE_LIRES.[PP-IRES])) 
															END AS NET_IRES
														FROM CTE_HIRES,CTE_LIRES
													)
			WHERE ITEM_NO = @ITEMNO
			
END
