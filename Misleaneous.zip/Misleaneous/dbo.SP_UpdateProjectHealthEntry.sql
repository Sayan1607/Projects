CREATE PROCEDURE dbo.SP_UpdateProjectHealthEntry
(
	@Noofcells INT
)
AS
BEGIN
	update dbo.ProjectHelathEntry
	set
		NoofCells = @Noofcells
END
