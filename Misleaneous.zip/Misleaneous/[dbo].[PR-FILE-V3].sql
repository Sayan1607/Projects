
drop table [dbo].[PR-FILE-V3]

CREATE TABLE [dbo].[PR-FILE-V3]
(
	[PR-ITEM-NO]                        INT NULL,
	[PR-DATE]							DATETIME NULL,
	[PROP]								NUMERIC(10,2) NULL,
	[PR-S2C1]							NUMERIC(10,2) NULL,
	[PR-S2-C2]							NUMERIC(10,2) NULL,
	[PR-S2C3]							NUMERIC(10,2) NULL,
	[PR-N1]								NUMERIC(10,2) NULL,
	[PR-N2]								NUMERIC(10,2) NULL,
	[PR-N3]								NUMERIC(10,2) NULL,
	[PR-N4]								NUMERIC(10,2) NULL,
	[PR-N5]								NUMERIC(10,2) NULL,
	[PR-N6]								NUMERIC(10,2) NULL,
	[PR-N7]								NUMERIC(10,2) NULL,
	[PR-N8]								NUMERIC(10,2) NULL,
	[PR(N1-N2)]							NUMERIC(10,2) NULL,
	[PR-AVG]							NUMERIC(10,2) NULL,
	[PR-S1C1]							NUMERIC(10,2) NULL,
	[PR-S1C2]							NUMERIC(10,2) NULL,
	[PR-S1C3]							NUMERIC(10,2) NULL,
	[PRCL-IND]							NVARCHAR(20) NULL,
	[PR-330IND]							NUMERIC(10,2) NULL,
	[PRFIN-IND]							NUMERIC(10,2) NULL,
	[PR-IRES]							NVARCHAR(max) NULL,
	[PR-ARES]							NVARCHAR(max) NULL,
	[DIF(330-PRCL)]						NVARCHAR(20) NULL
)

--CREATE TABLE [dbo].[PR-FILE-V3]
--(
--	[PR-ITEM NO]                    INT NULL,
--	[PR-DATE]                       DATETIME NULL,
--	[PR-S1C1]                       NUMERIC(10,2) NULL,
--	[PR-S1C2]                       NUMERIC(10,2) NULL,
--	[PR-S1C3]                       NUMERIC(10,2) NULL,
--	[PR-330-IND]                    NUMERIC(10,2) NULL,
--	[PR-N1]							NUMERIC(10,2) NULL,
--	[PR-N2]							NUMERIC(10,2) NULL,
--	[PR-N4]							NUMERIC(10,2) NULL,
--	[PR-IRES]                       NCHAR(10) NULL,
--	[PR-ARES]                       NCHAR(10) NULL,
--	[PRCL-IND]                      NCHAR(10) NULL
--)