ALTER PROCEDURE dbo.SP_CalllingCalculateAVGAMT2NDROW
(
	@Var_ITEM_NO VARCHAR(50)
)
AS
BEGIN
		Declare @VarSum VARCHAR(20)
		
		IF(@Var_ITEM_NO like '%U')
		BEGIN	
			
			EXEC SP_CalculateAVGAMT2NDROW
				@Var_ITEM_NO = @Var_ITEM_NO,
				@CNT = 2,
				@Result = @VarSum OUTPUT;
		END
		ELSE IF(@Var_ITEM_NO like '%D')
		BEGIN
			EXEC SP_CalculateAVGAMT2NDROW
				@Var_ITEM_NO = @Var_ITEM_NO,
				@CNT = 1,
				@Result = @VarSum OUTPUT;
		END

		TRUNCATE TABLE Result_AVGAMT
		INSERT INTO Result_AVGAMT
		SELECT @VarSum
		--RETURN @VarSum
END

