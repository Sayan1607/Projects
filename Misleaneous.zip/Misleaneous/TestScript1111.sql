
DECLARE @Var_ITEM_NO VARCHAR(20) = '1063D'


			IF OBJECT_ID('tempdb..##Temp_AVGAMT') IS NOT NULL
			DROP TABLE ##Temp_AVGAMT

			SELECT @Var_ITEM_NO = REPLACE(@Var_ITEM_NO,'D','U')
			;with CTE_FLINC 
			AS
			( 
				SELECT *
				FROM dbo.ProjectHelathEntryResult 
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'INC'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' ))		
			),
			CTE_FLRED
			AS
			(

				SELECT *
				FROM dbo.ProjectHelathEntryResult
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'RED'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' ))	
			)

		SELECT (CTE_FLRED.[RED-P/13&12&23ROWS-TR] + ':' + CTE_FLINC.[RED-P/13&12&23ROWS-TR]) AVGAMT
		INTO ##Temp_AVGAMT
		FROM CTE_FLINC join CTE_FLRED
		on CTE_FLINC.ITEM_NO = CTE_FLRED.ITEM_NO

		-- 2nd ROW
		;with CTE_FLINC 
			AS
			( 
				SELECT *
				FROM dbo.ProjectHelathEntryResult 
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'INC'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' ))		
			),
			CTE_FLRED
			AS
			(

				SELECT *
				FROM dbo.ProjectHelathEntryResult
				WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				and [RED/INC] = 'RED'
				and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' ))	
			)
		INSERT INTO ##Temp_AVGAMT
		SELECT (CTE_FLRED.[RED-N/13&12&23ROWS-TR] + ':' + CTE_FLINC.[RED-N/13&12&23ROWS-TR]) AVGAMT
		FROM CTE_FLINC join CTE_FLRED
		on CTE_FLINC.ITEM_NO = CTE_FLRED.ITEM_NO

		--select * from ##Temp_AVGAMT

		INSERT INTO ##Temp_AVGAMT
				SELECT SUBSTRING(AVGAMT,1,CHARINDEX(':',AVGAMT)-1)
				FROM ##TEMP_AVGAMT
				UNION
				SELECT SUBSTRING(AVGAMT,CHARINDEX(':',AVGAMT)+ 1, LEN(AVGAMT))
				FROM ##TEMP_AVGAMT

				DELETE TOP(1) FROM ##TEMP_AVGAMT
				DELETE TOP(1) FROM ##TEMP_AVGAMT

				--select * from ##Temp_AVGAMT

				IF OBJECT_ID('tempdb..##Temp_AVGAMTN') IS NOT NULL
				DROP TABLE ##Temp_AVGAMTN
				SELECT ROW_NUMBER() OVER(ORDER BY AVGAMT ASC) ID,
						AVGAMT
				INTO ##Temp_AVGAMTN
				FROM ##Temp_AVGAMT

				--select * from ##Temp_AVGAMT
				--SELECT * FROM ##Temp_AVGAMTN order by ID asc
				
				IF OBJECT_ID('tempdb..##Temp_AVGAMTNW') IS NOT NULL
				DROP TABLE ##Temp_AVGAMTNW

				SELECT AVGAMT
				INTO ##Temp_AVGAMTNW
				FROM ##Temp_AVGAMTN
				WHERE 1=2

				IF(SELECT COUNT(*) FROM ##TEMP_AVGAMTN WHERE AVGAMT LIKE 'FL%')>0
				BEGIN
					IF(select COUNT(*) from ##Temp_AVGAMTN where AVGAMT LIKE 'UP%')>0
					BEGIN
						INSERT INTO ##Temp_AVGAMTNW 
						select AVGAMT from ##Temp_AVGAMTN where AVGAMT LIKE 'FL%' 

						INSERT INTO ##Temp_AVGAMTNW 
						SELECT 'UP/' + (select CAST( CONVERT(NUMERIC(10,2),(SUM(CONVERT(NUMERIC(10,2),REPLACE(AVGAMT,'UP/',''))) )/COUNT(*)) AS VARCHAR(20))
						from ##Temp_AVGAMTN 
						where AVGAMT LIKE 'UP%')
					END
					IF (select COUNT(*) from ##Temp_AVGAMTN where AVGAMT LIKE 'DW%')>0
					BEGIN
						INSERT INTO ##Temp_AVGAMTNW 
						select AVGAMT from ##Temp_AVGAMTN where AVGAMT LIKE 'FL%' 

						INSERT INTO ##Temp_AVGAMTNW 
						SELECT 'DW/' + (select CAST( CONVERT(NUMERIC(10,2),(SUM(CONVERT(NUMERIC(10,2),REPLACE(AVGAMT,'DW/',''))) )/COUNT(*)) AS VARCHAR(20))
						from ##Temp_AVGAMTN 
						where AVGAMT LIKE 'DW%')
					END
				END
				ELSE 
				BEGIN
					INSERT INTO ##Temp_AVGAMTNW 
					SELECT 'UP/' + (select CAST( CONVERT(NUMERIC(10,2),(SUM(CONVERT(NUMERIC(10,2),REPLACE(AVGAMT,'UP/',''))) )/COUNT(*)) AS VARCHAR(20))
					from ##Temp_AVGAMTN 
					where AVGAMT LIKE 'UP%')

					INSERT INTO ##Temp_AVGAMTNW 
					SELECT 'DW/' + (select CAST( CONVERT(NUMERIC(10,2),(SUM(CONVERT(NUMERIC(10,2),REPLACE(AVGAMT,'DW/',''))) )/COUNT(*)) AS VARCHAR(20))
					from ##Temp_AVGAMTN 
					where AVGAMT LIKE 'DW%')

				END
				--SELECT * FROM ##Temp_AVGAMTNW

				IF(( (SELECT COUNT(*) FROM ##Temp_AVGAMTNW WHERE AVGAMT LIKE 'UP%') > 0) AND ( (SELECT COUNT(*) FROM ##Temp_AVGAMTNW WHERE AVGAMT LIKE 'DW%') > 0))
				BEGIN
					DELETE FROM ##Temp_AVGAMTNW WHERE AVGAMT = 'FL'
				END
				
				SELECT * FROM ##Temp_AVGAMTNW

				--UPDATE dbo.ProjectHelathEntryResult
				--SET
				--	[DW/AMT-AVG] = ISNULL((SELECT AVGAMT FROM ##Temp_AVGAMTNW where AVGAMT LIKE 'DW%'),'FL')
				--WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				--and [RED/INC] = 'RED'
				--AND ID in ( (SELECT Top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED') + 2)
			
				--UPDATE dbo.ProjectHelathEntryResult
				--SET
				--	[UP/AMT-AVG] = ISNULL((SELECT	AVGAMT FROM ##Temp_AVGAMTNW where AVGAMT LIKE 'UP%'),'FL')
				--WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
				--and [RED/INC] = 'RED'
				--AND ID in ( (SELECT Top(1) id from dbo.ProjectHelathEntryResult where ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED') + 2)
