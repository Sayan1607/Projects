USE [BSTRecDB]
GO

/****** Object:  Table [dbo].[ProjectHelathEntry]    Script Date: 14/05/2021 10:42:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProjectHelathEntry](
	[ITEM_NO] [int] NOT NULL,
	[PRCL_IND] [numeric](10, 2) NULL,
	[UD1] [numeric](10, 2) NULL,
	[UD2] [numeric](10, 2) NULL,
	[UD3] [numeric](10, 2) NULL,
	[330_IND] [numeric](10, 2) NULL,
	[GAP_LIMIT] [int] NULL,
	[IRES] [numeric](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[ITEM_NO] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


