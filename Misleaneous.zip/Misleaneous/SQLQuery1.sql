
/*
======================================
This DB script needs to be executed in the host DB
======================================
*/

CREATE TABLE [dbo].[LogonTable]
(
	[Id] NCHAR(10) NOT NULL PRIMARY KEY, 
    [Password] NCHAR(10) NOT NULL
)


--INSERT INTO [dbo].[LogonTable] values
--('slavian','pass123'),
--('sayan','pass123')

CREATE TABLE [dbo].[ProjectHelathEntry]
(
	[ITEM_NO] INT NOT NULL PRIMARY KEY, 
    [PRCL_IND] NUMERIC(10, 2) NULL, 
    [UD1] NUMERIC(10, 2) NULL, 
    [UD2] NUMERIC(10, 2) NULL, 
    [UD3] NUMERIC(10, 2) NULL, 
    [330_IND] NUMERIC(10, 2) NULL, 
    [GAP_LIMIT] NUMERIC(10, 2) NULL
)

--==============

CREATE TABLE [dbo].[Result]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [ITEM_NO] INT NOT NULL, 
    [PVCL-IND] NUMERIC(10, 2) NULL, 
    [330-IND] NUMERIC(10, 2) NULL, 
    [S1C2] NUMERIC(10, 2) NULL, 
    [UD1] NUMERIC(10, 2) NULL, 
    [L/H-IND-CNT1] NCHAR(10) NULL, 
    [UD2] NUMERIC(10, 2) NULL, 
    [L/H-IND-CNT2] NCHAR(10) NULL, 
    [UD3] NUMERIC(10, 2) NULL, 
    [L/H-IND-CNT3] NCHAR(10) NULL, 
    [PRCL-NXTDCL-DIF] NCHAR(10) NULL, 
    [N/P-C2-CNT1] NCHAR(10) NULL, 
    [N/P-C2-CNT2] NCHAR(10) NULL,
	[N/P-C2-CNT3] NCHAR(10) NULL,
	[PP-RNG-UD]	NCHAR(10) NULL,
	[GAP-LMT] INT NOT NULL,
	[IND-GAP] NUMERIC(10, 2) NULL,
	[LIND] NUMERIC(10, 2) NULL,
	[MIND] NUMERIC(10, 2) NULL,
	[TOT] NUMERIC(10, 2) NULL,
	[ALL-CNT(P/N)] NCHAR(10) NULL,
	[GREEN] NCHAR(10) NULL,
	[ACC] NCHAR(1) NULL
)
