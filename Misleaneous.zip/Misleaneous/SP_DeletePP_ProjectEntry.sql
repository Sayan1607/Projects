
ALTER PROCEDURE SP_DeletePP_ProjectEntry
AS
BEGIN
	TRUNCATE TABLE [dbo].[ProjectHelathEntry]

END
