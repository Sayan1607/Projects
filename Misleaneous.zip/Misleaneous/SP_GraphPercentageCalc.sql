
ALTER PROCEDURE SP_GraphPercentageCalc
AS
BEGIN

INSERT INTO dbo.GraphPercentageCalc	
select [RED/INC],
		SUM(case when [ACC/TOT] = 'C'
			then 1
			else 0
		end) as C_Count,
		SUM(case when [ACC/TOT] = 'W'
			then 1
			else 0
		end) as W_Count
from [dbo].[ProjectHelathEntryResult]
GROUP BY [RED/INC]

END
