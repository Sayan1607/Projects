ALTER PROCEDURE dbo.SP_ProjectHealthP1_RecurINC
(
	@Var_ITEM_NO INT,
	@Id INT,
	@NoOfCells INT 
)
AS
BEGIN
		Declare @ActResCntI INT = 0,
				@ActResNxtCntI	INT = 0,
				@var_PPRNGUD	NUMERIC(10,2)
				-- INC

			set @ActResCntI = 0
			set @ActResNxtCntI = 0

			select @ActResCntI = (case when Res1 IS NULL then 0 else 1 end 
				+ case when Res2 IS NULL then 0 else 1 end 
				+ case when Res3 IS NULL  then 0 else 1 end
				+ case when Res4 IS NULL  then 0 else 1 end
				+ case when Res5 IS NULL  then 0 else 1 end
				+ case when Res6 IS NULL  then 0 else 1 end 
				+ case when Res7 IS NULL  then 0 else 1 end
				+ case when Res8 IS NULL  then 0 else 1 end
				+ case when Res9 IS NULL  then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
			
			IF(
				SELECT count(*)
				FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
				and UD2 in 
				(
					SELECT [PP-RNG-UD]
					FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
				)
			)>0
			BEGIN
					SELECT @var_PPRNGUD = [PP-RNG-UD]
					FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = (@Id-1)
					SET @var_PPRNGUD = @var_PPRNGUD + 0.01
			END
			ELSE
			BEGIN
						IF(
						SELECT count(*)
						FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
						and UD3 in 
						(
							SELECT [PP-RNG-UD]
							FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
						)
					)>0
					BEGIN
							SELECT @var_PPRNGUD = [PP-RNG-UD]
							FROM dbo.ProjectHelathEntryResult WHERE ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = (@Id-1)
							SET @var_PPRNGUD = @var_PPRNGUD + 0.01
					END
					ELSE
					BEGIN
					set @var_PPRNGUD = 0.01
					END
			END
			
			while(@ActResCntI<@NoOfCells)
			begin
				--print '@PPRNGUD-->' + cast(@PPRNGUD as varchar(10))
				IF(@var_PPRNGUD<=15)
				BEGIN
						EXEC dbo.SP_UpdateHealthDataINC @PPRNGUD = @var_PPRNGUD, @ID= @Id, @Var_ITEMNO = @Var_ITEM_NO

						select @ActResNxtCntI = (case when Res1 IS NULL then 0 else 1 end 
						+ case when Res2 IS NULL then 0 else 1 end 
						+ case when Res3 IS NULL  then 0 else 1 end
						+ case when Res4 IS NULL  then 0 else 1 end
						+ case when Res5 IS NULL  then 0 else 1 end
						+ case when Res6 IS NULL  then 0 else 1 end 
						+ case when Res7 IS NULL  then 0 else 1 end
						+ case when Res8 IS NULL  then 0 else 1 end
						+ case when Res9 IS NULL  then 0 else 1 end     
					)
					from dbo.ProjectHelathEntryResult where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
		
					set @ActResCntI = @ActResNxtCntI
					set @var_PPRNGUD = @var_PPRNGUD + 0.01
				END
				ELSE
				BEGIN
					BREAK
				END
			end

			--select cast(@Var_ITEM_NO as varchar(10)) + ' : @varindPRCLRED-->' + cast(@varindPRCLRED as varchar(10))

			
			IF(@var_PPRNGUD>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResult
			SET
				[PP-RNG-UD] = @var_PPRNGUD - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
			end 
			ELSE IF(@var_PPRNGUD=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @var_PPRNGUD
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND Id = @Id
			end 

			
END