
CREATE PROCEDURE dbo.SP_CalculateCloseRange
(
	@PRCLIND	NUMERIC(10,2)
)
BEGIN
		IF OBJECT_ID('tempdb..##TEMP_RESULT') IS NOT NULL
		DROP TABLE ##TEMP_RESULT

		IF OBJECT_ID('tempdb..##TEMP_PPCLRESULT') IS NOT NULL
		DROP TABLE ##TEMP_PPCLRESULT

		Declare @PrclInd	Numeric(10,2),
				@VarMaxDiff	Numeric(10,2),
				@VarPRCLMaxDiff	NUMERIC(10,2),
				@33OIND	NUMERIC(10,2),
				@ITEMNO	INT = 1057

		select @PrclInd = PRCL_IND,@33OIND =[330_IND] from dbo.ProjectHelathEntry where ITEM_NO in (@ITEMNO)

			;WITH CTE_LOWVAL
			AS
			(
			SELECT TOP(1) [PP-OP]
			FROM DBO.[PP-FILE]
			WHERE [PP-OP] < @PrclInd
			ORDER BY [PP-OP]  DESC
			),
			CTE_HIGHVAL
			AS
			(
			SELECT TOP(1) [PP-OP]
			FROM DBO.[PP-FILE]
			WHERE [PP-OP] > @PrclInd
			ORDER BY [PP-OP]  ASC
			)
			SELECT CTE_LOWVAL.[PP-OP] as L_LMT, 
					(CTE_LOWVAL.[PP-OP] - @PrclInd) LGAP,
					CTE_HIGHVAL.[PP-OP] as H_LMT,
					(CTE_HIGHVAL.[PP-OP] - @PrclInd) HGAP
			INTO ##TEMP_RESULT
			FROM CTE_LOWVAL, CTE_HIGHVAL


			SELECT @VarMaxDiff = CASE WHEN ABS(LGAP) >=ABS(HGAP)
						THEN  ABS(LGAP)
						WHEN ABS(HGAP) >= ABS(LGAP)
						THEN ABS(HGAP)
					END 
			 FROM ##TEMP_RESULT


			PRINT @VarMaxDiff
			--PRINT @VarPRCLMaxDiff

			--  and [PP-CL] IN ((@33OIND + @VarPRCLMaxDiff),(@33OIND - @VarPRCLMaxDiff))

			 WHILE(SELECT COUNT(distinct [PP-OP]) FROM dbo.[PP-FILE] where [PP-OP] between (@PrclInd - @VarMaxDiff) and (@PrclInd + @VarMaxDiff) )<2
			 BEGIN
				SET @VarMaxDiff = @VarMaxDiff + 0.01
				--SET @VarPRCLMaxDiff = @VarPRCLMaxDiff + 0.01
			 END
			 PRINT '@VarPRCLMaxDiff-->' + CAST(@VarPRCLMaxDiff AS VARCHAR(10))
			 PRINT 'Latest @VarMaxDiff -->' + cast(@VarMaxDiff as varchar(10))
			 print '@PrclInd-->' + cast(@PrclInd as varchar(10))
			 print '(@PrclInd + @VarMaxDiff)-->' + cast((@PrclInd + @VarMaxDiff) as varchar(10))
			 print '(@PrclInd - @VarMaxDiff)-->' + cast((@PrclInd - @VarMaxDiff) as varchar(10))
	 
			 select * FROM dbo.[PP-FILE] where [PP-OP] between (@PrclInd - @VarMaxDiff) and (@PrclInd + @VarMaxDiff) --and [PP-CL] between (@33OIND - @VarPRCLMaxDiff) and (@33OIND + @VarPRCLMaxDiff)

	 			 -- 330 IND
			 ;WITH CTE_PPCLLOWVAL
			AS
			(
			SELECT TOP(1) [PP-CL]
			FROM dbo.[PP-FILE]
			WHERE [PP-OP] between (@PrclInd - @VarMaxDiff) and (@PrclInd + @VarMaxDiff) 
			and[PP-CL] < @33OIND
			ORDER BY [PP-CL]  DESC
			),
			CTE_PPCLHIGHVAL
			AS
			(
			SELECT TOP(1) [PP-CL]
			FROM dbo.[PP-FILE]
			WHERE [PP-OP] between (@PrclInd - @VarMaxDiff) and (@PrclInd + @VarMaxDiff) 
			and [PP-CL] > @33OIND
			ORDER BY [PP-CL]  asc
			)
			SELECT CTE_PPCLLOWVAL.[PP-CL] as L_LMT, 
					(CTE_PPCLLOWVAL.[PP-CL] - @33OIND) LGAP,
					CTE_PPCLHIGHVAL.[PP-CL] as H_LMT,
					(CTE_PPCLHIGHVAL.[PP-CL] - @33OIND) HGAP
			INTO ##TEMP_PPCLRESULT
			FROM CTE_PPCLLOWVAL, CTE_PPCLHIGHVAL


			while (select COUNT(distinct [PP-CL]) FROM dbo.[PP-FILE] where [PP-OP] between (@PrclInd - @VarMaxDiff) and (@PrclInd + @VarMaxDiff) and [PP-CL] between (select L_LMT from ##TEMP_PPCLRESULT) and (select H_LMT from ##TEMP_PPCLRESULT))<2
			begin
				update ##TEMP_PPCLRESULT
				set
					L_LMT = L_LMT + 0.01,
					H_LMT = H_LMT + 0.01
			end

			 select * FROM dbo.[PP-FILE] where [PP-OP] between (@PrclInd - @VarMaxDiff) and (@PrclInd + @VarMaxDiff) and [PP-CL] between (select L_LMT from ##TEMP_PPCLRESULT) and (select H_LMT from ##TEMP_PPCLRESULT)
END