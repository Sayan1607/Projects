ALTER function dbo.fn_Calculatecntersum(@Cnt1 Varchar(50), @Cnt2 Varchar(50), @Cnt3 Varchar(50))
returns varchar(10)
AS
BEGIN
	return CASE WHEN ( convert(SMALLINT,SUBSTRING(@Cnt1,2,CHARINDEX('/',@Cnt1)-2)) - CONVERT(SMALLINT,substring((replace(replace(@Cnt1,'[',''),']','')),charindex('/', (replace(replace(@Cnt1,'[',''),']','')))+1, len( (replace(replace(@Cnt1,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt1,'[',''),']',''))))) ) <0
				THEN ( convert(SMALLINT,SUBSTRING(@Cnt1,2,CHARINDEX('/',@Cnt1)-2)) - CONVERT(SMALLINT,substring((replace(replace(@Cnt1,'[',''),']','')),charindex('/', (replace(replace(@Cnt1,'[',''),']','')))+1, len( (replace(replace(@Cnt1,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt1,'[',''),']',''))))) )
				ELSE 0
			END
		+
		CASE WHEN ( convert(SMALLINT,SUBSTRING(@Cnt2,2,CHARINDEX('/',@Cnt2)-2)) - CONVERT(SMALLINT,substring((replace(replace(@Cnt2,'[',''),']','')),charindex('/', (replace(replace(@Cnt2,'[',''),']','')))+1, len( (replace(replace(@Cnt2,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt2,'[',''),']',''))))) ) <0
			 THEN ( convert(SMALLINT,SUBSTRING(@Cnt2,2,CHARINDEX('/',@Cnt2)-2)) - CONVERT(SMALLINT,substring((replace(replace(@Cnt2,'[',''),']','')),charindex('/', (replace(replace(@Cnt2,'[',''),']','')))+1, len( (replace(replace(@Cnt2,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt2,'[',''),']',''))))) )
			 ELSE 0
		END
		+
		CASE WHEN ( convert(SMALLINT,SUBSTRING(@Cnt3,2,CHARINDEX('/',@Cnt3)-2)) - CONVERT(SMALLINT,substring((replace(replace(@Cnt3,'[',''),']','')),charindex('/', (replace(replace(@Cnt3,'[',''),']','')))+1, len( (replace(replace(@Cnt3,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt3,'[',''),']',''))))) ) <0
			 THEN ( convert(SMALLINT,SUBSTRING(@Cnt3,2,CHARINDEX('/',@Cnt3)-2)) - CONVERT(SMALLINT,substring((replace(replace(@Cnt3,'[',''),']','')),charindex('/', (replace(replace(@Cnt3,'[',''),']','')))+1, len( (replace(replace(@Cnt3,'[',''),']','')) ) - charindex('/', (replace(replace(@Cnt3,'[',''),']',''))))) )
			 ELSE 0
		END
		
END