ALTER PROCEDURE dbo.SP_C_PERCENTAGE
AS
BEGIN
	TRUNCATE TABLE dbo.ExportSummary
	INSERT INTO dbo.ExportSummary	
	SELECT	Result.[RED/INC],		
			Result.UD1,
			Result.UD2,
			Result.UD3,
			Result.TOT,	
			Result.[3/COL]
					FROM 
					(
				
					SELECT [RED/INC],
							UD1,
							NULL AS UD2,
							NULL AS UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD1=0.03)))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL'
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C'
					GROUP BY [RED/INC],
							UD1
					UNION 

					SELECT [RED/INC],
							NULL AS UD1,
							UD2,
							NULL AS UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD2=0.05)))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL' 
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C'
					GROUP BY [RED/INC],
							UD2
					UNION
					SELECT [RED/INC],
							NULL AS UD1,
							NULL AS UD2,
							UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD3=0.10)))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL'
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C'
					GROUP BY [RED/INC],
							UD3

					UNION

					SELECT 'RED_SUB_TOTAL',
							NULL AS UD1,
							NULL AS UD2,
							NULL UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'RED')))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL' 
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C' and [RED/INC] = 'RED'
					GROUP BY [RED/INC]

					UNION

					SELECT 'INC_SUB_TOTAL',
							NULL AS UD1,
							NULL AS UD2,
							NULL UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'INC')))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL' 
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C' and [RED/INC] = 'INC'
					GROUP BY [RED/INC]

					UNION

					SELECT 'TOTAL_RED_INC',
							NULL AS UD1,
							NULL AS UD2,
							NULL UD3,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult)))*100 AS varchar(10)) +'%' AS TOT,
							NULL AS '3/COL' 
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/TOT] = 'C'

					union
					--3COL

					SELECT CASE WHEN [RED/INC] = 'RED' THEN '3COL_RED' WHEN [RED/INC] = 'INC' THEN '3COL_INC' END AS [RED/INC],
							UD1,
							NULL AS UD2,
							NULL AS UD3,
							NULL AS TOT,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD1=0.03)))*100 AS varchar(10)) +'%' AS '3/COL' 
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/3COL] = 'C'
					GROUP BY [RED/INC],
							UD1
					UNION 

					SELECT CASE WHEN [RED/INC] = 'RED' THEN '3COL_RED' WHEN [RED/INC] = 'INC' THEN '3COL_INC' END AS [RED/INC],
							NULL AS UD1,
							UD2,
							NULL AS UD3,
							NULL AS TOT,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD2=0.05)))*100 AS varchar(10)) +'%' AS '3/COL'  
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/3COL] = 'C'
					GROUP BY [RED/INC],
							UD2
					UNION
					SELECT CASE WHEN [RED/INC] = 'RED' THEN '3COL_RED' WHEN [RED/INC] = 'INC' THEN '3COL_INC' END AS [RED/INC],
							NULL AS UD1,
							NULL AS UD2,
							UD3,
							NULL AS TOT,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE UD3=0.10)))*100 AS varchar(10)) +'%' AS '3/COL'  
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/3COL] = 'C'
					GROUP BY [RED/INC],
							UD3

					UNION

					SELECT '3COL_RED_SUB_TOTAL',
							NULL AS UD1,
							NULL AS UD2,
							NULL UD3,
							NULL AS TOT,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'RED')))*100 AS varchar(10)) +'%' AS '3/COL'  
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/3COL] = 'C' and [RED/INC] = 'RED'
					GROUP BY [RED/INC]

					UNION

					SELECT '3COL_INC_SUB_TOTAL',
							NULL AS UD1,
							NULL AS UD2,
							NULL UD3,
							NULL AS TOT,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult WHERE [RED/INC] = 'INC')))*100 AS varchar(10)) +'%' AS '3/COL'  
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/3COL] = 'C' and [RED/INC] = 'INC'
					GROUP BY [RED/INC]

					UNION

					SELECT '3COL_TOTAL_RED_INC',
							NULL AS UD1,
							NULL AS UD2,
							NULL UD3,
							NULL AS TOT,
							CAST(CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),COUNT([ACC/TOT]))/(SELECT COUNT( ITEM_NO) FROM dbo.ProjectHelathEntryResult)))*100 AS varchar(10)) +'%' AS '3/COL'  
					from dbo.ProjectHelathEntryResult
					WHERE [ACC/3COL] = 'C'

			)Result
			order by Result.[RED/INC] asc


END
