ALTER FUNCTION dbo.fnCalculateUPSUM
(
	@Var_ITEM_NO VARCHAR(50)
)
RETURNS VARCHAR(50)
AS
BEGIN 

		Declare @VarSum VARCHAR(50)
		
		IF(@Var_ITEM_NO like '%U')
		BEGIN
				;WITH CTE_UPSUMRED 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/CNT] AS UP_CNT_RED,
						[DW/CNT] AS DW_CNT_RED
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
					and [RED/INC] = 'RED'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+1)
				),
				CTE_UPSUMINC 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/CNT] AS UP_CNT_INC,
						[DW/CNT] AS DW_CNT_INC
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
					and [RED/INC] = 'INC'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)
				)
				SELECT @VarSum = 'UP/' + cast(CONVERT(SMALLINT,(CONVERT(SMALLINT,A.UP_CNT_INC) + CONVERT(SMALLINT,B.UP_CNT_RED))) as varchar(20))
						FROM CTE_UPSUMINC A JOIN CTE_UPSUMRED B
						ON A.ITEM_NO = B.ITEM_NO
		END
		ELSE IF(@Var_ITEM_NO like '%D')
		BEGIN
			;WITH CTE_DWSUMRED 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/CNT] AS UP_CNT_RED,
						[DW/CNT] AS DW_CNT_RED
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D','')))
					and [RED/INC] = 'RED'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D',''))) and [RED/INC] = 'RED' )+1)
				),
				CTE_DWSUMINC 
				AS
				(
					SELECT Id,
						ITEM_NO,
						[UP/CNT] AS UP_CNT_INC,
						[DW/CNT] AS DW_CNT_INC
					FROM dbo.ProjectHelathEntryResult
					WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D','')))
					and [RED/INC] = 'INC'
					and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'D',''))) and [RED/INC] = 'INC' )+1)
				)
				SELECT @VarSum = 'DW/' + CAST(CONVERT(SMALLINT,(CONVERT(SMALLINT,A.DW_CNT_INC) + CONVERT(SMALLINT,B.DW_CNT_RED))) as varchar(20))
						FROM CTE_DWSUMINC A JOIN CTE_DWSUMRED B
						ON A.ITEM_NO = B.ITEM_NO
		END

		RETURN @VarSum
	
END
