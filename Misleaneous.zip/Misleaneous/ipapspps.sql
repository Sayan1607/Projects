CASE WHEN [RED-P/13&12&23ROWS-TR] = 'FL'
							THEN ( SELECT CASE WHEN [RED-P/13&12&23ROWS-TR] = 'FL' 
											 THEN 'FL' 
											 ELSE [RED-P/13&12&23ROWS-TR]
											 END
									FROM dbo.ProjectHelathEntryResult 
									WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
									and [RED/INC] = 'INC'
									and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)		
								)
						WHEN [RED-P/13&12&23ROWS-TR] like '%U'
						THEN CASE WHEN ( SELECT CASE WHEN [RED-P/13&12&23ROWS-TR] = 'FL' 
											 THEN 'FL' 
											 ELSE [RED-P/13&12&23ROWS-TR]
											 END
									FROM dbo.ProjectHelathEntryResult 
									WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
									and [RED/INC] = 'INC'
									and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)		
								) like '%U'
								THEN (
										(
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+1))
										+
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1))
										)
									)
								WHEN ( SELECT CASE WHEN [RED-P/13&12&23ROWS-TR] = 'FL' 
											 THEN 'FL' 
											 ELSE [RED-P/13&12&23ROWS-TR]
											 END
									FROM dbo.ProjectHelathEntryResult 
									WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
									and [RED/INC] = 'INC'
									and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)		
								) like '%D'
								THEN (
										(
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+1))
										+
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1))
										)
									)
						END
						WHEN [RED-P/13&12&23ROWS-TR] like '%D'
						THEN CASE WHEN ( SELECT CASE WHEN [RED-P/13&12&23ROWS-TR] = 'FL' 
											 THEN 'FL' 
											 ELSE [RED-P/13&12&23ROWS-TR]
											 END
									FROM dbo.ProjectHelathEntryResult 
									WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
									and [RED/INC] = 'INC'
									and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)		
								) like '%D'
								THEN (
										(
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+1))
										+
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1))
										)
									)
								WHEN ( SELECT CASE WHEN [RED-P/13&12&23ROWS-TR] = 'FL' 
											 THEN 'FL' 
											 ELSE [RED-P/13&12&23ROWS-TR]
											 END
									FROM dbo.ProjectHelathEntryResult 
									WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
									and [RED/INC] = 'INC'
									and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1)		
								) like '%U'
								THEN (
										(
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' )+1))
										+
										(SELECT [RED-P/13&12&23ROWS-TR] WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' )+1))
										)
									)
						END
						ELSE [RED-P/13&12&23ROWS-TR]
				END
