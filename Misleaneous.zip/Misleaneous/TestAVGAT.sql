CREATE PROCEDURE dbo.SP_CalculateAVGAMT
(
	@Var_ITEM_NO VARCHAR(20) 
)
AS
BEGIN
--DECLARE @Var_ITEM_NO VARCHAR(20) = '1065D'


			IF OBJECT_ID('tempdb..##Temp_AVGAMT') IS NOT NULL
			DROP TABLE ##Temp_AVGAMT

			SELECT @Var_ITEM_NO = REPLACE(@Var_ITEM_NO,'D','U')
										;with CTE_FLINC 
										AS
										( 
											SELECT *
											FROM dbo.ProjectHelathEntryResult 
											WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
											and [RED/INC] = 'INC'
											and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' ))		
										),
										CTE_FLRED
										AS
										(

											SELECT *
											FROM dbo.ProjectHelathEntryResult
											WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
											and [RED/INC] = 'RED'
											and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' ))	
										)

										SELECT  CASE WHEN SUBSTRING(SUBSTRING(Rslt2.AMTAVG,1,CHARINDEX('|',Rslt2.AMTAVG)-1),1,2) = 'DW'
													THEN SUBSTRING(Rslt2.AMTAVG,1,CHARINDEX('|',Rslt2.AMTAVG)-1)
												END as AVGAMT
										INTO ##Temp_AVGAMT

										FROM
										(
										SELECT CASE WHEN SUBSTRING(Rslt1.AMTAVG,1,2) = 'DW' AND SUBSTRING(SUBSTRING(Rslt1.AMTAVG,CHARINDEX('|',Rslt1.AMTAVG)+1,LEN(Rslt1.AMTAVG)),1,2) = 'DW'
													THEN 'DW/00aa|DW/' +CAST(CONVERT(NUMERIC(10,2),( CONVERT(NUMERIC(10,2),REPLACE(SUBSTRING(Rslt1.AMTAVG,1,CHARINDEX('|',Rslt1.AMTAVG)-1),'DW/','') )+
															CONVERT(NUMERIC(10,2),REPLACE(SUBSTRING(Rslt1.AMTAVG,CHARINDEX('|',Rslt1.AMTAVG)+1,LEN(Rslt1.AMTAVG)),'DW/',''))
															)/2) AS VARCHAR(20))
													ELSE Rslt1.AMTAVG
												END AMTAVG
										FROM 
										(
													SELECT CASE WHEN Rslt.UPAMTAVG like 'UP%DW%'
																THEN Rslt.UPAMTAVG
																WHEN Rslt.UPAMTAVG like 'UP%' or Rslt.UPAMTAVG like 'DW%' OR  Rslt.UPAMTAVG like '%FL%'
																THEN REPLACE(Rslt.UPAMTAVG,'FL','') + '|' + ( SELECT CASE WHEN CTE_FLRED.[RED-N/13&12&23ROWS-TR] = 'FL' AND CTE_FLINC.[RED-N/13&12&23ROWS-TR] = 'FL'
																		THEN 'FL'
																		WHEN CTE_FLRED.[RED-N/13&12&23ROWS-TR] LIKE 'UP%' AND CTE_FLINC.[RED-N/13&12&23ROWS-TR] LIKE 'UP%'
																		THEN 'UP/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-N/13&12&23ROWS-TR],'UP/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-N/13&12&23ROWS-TR],'UP/','')))/2) AS VARCHAR(20))
																		WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] LIKE 'DW%' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] LIKE 'DW%'
																		THEN 'DW/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-N/13&12&23ROWS-TR],'DW/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-N/13&12&23ROWS-TR],'DW/','')))/2) AS VARCHAR(20))
																		ELSE REPLACE((CTE_FLRED.[RED-N/13&12&23ROWS-TR] + ':' + CTE_FLINC.[RED-N/13&12&23ROWS-TR]),'FL','')
																		END
																		FROM CTE_FLRED JOIN CTE_FLINC
																		ON CTE_FLRED.ITEM_NO = CTE_FLINC.ITEM_NO
																	)
														END AS AMTAVG
													FROM
													(
															SELECT CASE WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] = 'FL' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] = 'FL'
																		THEN ((SELECT [RED-N/13&12&23ROWS-TR] FROM CTE_FLRED)
																				+ '|' +
																			  (SELECT [RED-N/13&12&23ROWS-TR] FROM CTE_FLINC) 
																			)
																		WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] LIKE 'UP%' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] LIKE 'UP%'
																		THEN 'UP/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-P/13&12&23ROWS-TR],'UP/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-P/13&12&23ROWS-TR],'UP/','')))/2) AS VARCHAR(20))
																		WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] LIKE 'DW%' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] LIKE 'DW%'
																		THEN 'DW/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-P/13&12&23ROWS-TR],'DW/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-P/13&12&23ROWS-TR],'DW/','')))/2) AS VARCHAR(20))
																		ELSE (CTE_FLRED.[RED-P/13&12&23ROWS-TR] +':' + CTE_FLINC.[RED-P/13&12&23ROWS-TR])
																END AS UPAMTAVG
															FROM CTE_FLRED JOIN CTE_FLINC
															ON CTE_FLRED.ITEM_NO = CTE_FLINC.ITEM_NO
													) Rslt
										)Rslt1
									)Rslt2

									-- 2ND PART
									;with CTE_FLINC 
										AS
										( 
											SELECT *
											FROM dbo.ProjectHelathEntryResult 
											WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
											and [RED/INC] = 'INC'
											and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'INC' ))		
										),
										CTE_FLRED
										AS
										(

											SELECT *
											FROM dbo.ProjectHelathEntryResult
											WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U','')))
											and [RED/INC] = 'RED'
											and Id in ((select top(1) id from dbo.ProjectHelathEntryResult WHERE ITEM_NO in (CONVERT(SMALLINT,REPLACE(@Var_ITEM_NO,'U',''))) and [RED/INC] = 'RED' ))	
										)

										INSERT INTO ##Temp_AVGAMT
										SELECT  CASE WHEN SUBSTRING(SUBSTRING(Rslt2.AMTAVG,1,CHARINDEX('|',Rslt2.AMTAVG)-1),1,2) = 'DW'
													THEN SUBSTRING(Rslt2.AMTAVG,CHARINDEX('|',Rslt2.AMTAVG)+1,LEN(Rslt2.AMTAVG))
												END as AVGAMT
							
										FROM
										(
										SELECT CASE WHEN SUBSTRING(Rslt1.AMTAVG,1,2) = 'DW' AND SUBSTRING(SUBSTRING(Rslt1.AMTAVG,CHARINDEX('|',Rslt1.AMTAVG)+1,LEN(Rslt1.AMTAVG)),1,2) = 'DW'
													THEN 'DW/00aa|DW/' +CAST(CONVERT(NUMERIC(10,2),( CONVERT(NUMERIC(10,2),REPLACE(SUBSTRING(Rslt1.AMTAVG,1,CHARINDEX('|',Rslt1.AMTAVG)-1),'DW/','') )+
															CONVERT(NUMERIC(10,2),REPLACE(SUBSTRING(Rslt1.AMTAVG,CHARINDEX('|',Rslt1.AMTAVG)+1,LEN(Rslt1.AMTAVG)),'DW/',''))
															)/2) AS VARCHAR(20))
													ELSE Rslt1.AMTAVG
												END AMTAVG
										FROM 
										(
													SELECT CASE WHEN Rslt.UPAMTAVG like 'UP%DW%'
																THEN Rslt.UPAMTAVG
																WHEN Rslt.UPAMTAVG like 'UP%' or Rslt.UPAMTAVG like 'DW%' OR  Rslt.UPAMTAVG like '%FL%'
																THEN REPLACE(Rslt.UPAMTAVG,'FL','') + '|' + ( SELECT CASE WHEN CTE_FLRED.[RED-N/13&12&23ROWS-TR] = 'FL' AND CTE_FLINC.[RED-N/13&12&23ROWS-TR] = 'FL'
																		THEN 'FL'
																		WHEN CTE_FLRED.[RED-N/13&12&23ROWS-TR] LIKE 'UP%' AND CTE_FLINC.[RED-N/13&12&23ROWS-TR] LIKE 'UP%'
																		THEN 'UP/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-N/13&12&23ROWS-TR],'UP/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-N/13&12&23ROWS-TR],'UP/','')))/2) AS VARCHAR(20))
																		WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] LIKE 'DW%' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] LIKE 'DW%'
																		THEN 'DW/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-N/13&12&23ROWS-TR],'DW/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-N/13&12&23ROWS-TR],'DW/','')))/2) AS VARCHAR(20))
																		ELSE REPLACE((CTE_FLRED.[RED-N/13&12&23ROWS-TR] + ':' + CTE_FLINC.[RED-N/13&12&23ROWS-TR]),'FL','')
																		END
																		FROM CTE_FLRED JOIN CTE_FLINC
																		ON CTE_FLRED.ITEM_NO = CTE_FLINC.ITEM_NO
																	)
														END AS AMTAVG
													FROM
													(
															SELECT CASE WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] = 'FL' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] = 'FL'
																		THEN ((SELECT [RED-N/13&12&23ROWS-TR] FROM CTE_FLRED)
																				+ '|' +
																			  (SELECT [RED-N/13&12&23ROWS-TR] FROM CTE_FLINC) 
																			)
																		WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] LIKE 'UP%' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] LIKE 'UP%'
																		THEN 'UP/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-P/13&12&23ROWS-TR],'UP/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-P/13&12&23ROWS-TR],'UP/','')))/2) AS VARCHAR(20))
																		WHEN CTE_FLRED.[RED-P/13&12&23ROWS-TR] LIKE 'DW%' AND CTE_FLINC.[RED-P/13&12&23ROWS-TR] LIKE 'DW%'
																		THEN 'DW/' + CAST( CONVERT(NUMERIC(10,2),(CONVERT(NUMERIC(10,2),REPLACE(CTE_FLRED.[RED-P/13&12&23ROWS-TR],'DW/','')) + CONVERT(NUMERIC(10,2),REPLACE(CTE_FLINC.[RED-P/13&12&23ROWS-TR],'DW/','')))/2) AS VARCHAR(20))
																		ELSE (CTE_FLRED.[RED-P/13&12&23ROWS-TR] +':' + CTE_FLINC.[RED-P/13&12&23ROWS-TR])
																END AS UPAMTAVG
															FROM CTE_FLRED JOIN CTE_FLINC
															ON CTE_FLRED.ITEM_NO = CTE_FLINC.ITEM_NO
													) Rslt
										)Rslt1
									)Rslt2
	
				INSERT INTO ##Temp_AVGAMT
				select substring(AVGAMT,1,CHARINDEX(':',AVGAMT)-1)
				from ##Temp_AVGAMT
				union
				select substring(AVGAMT,CHARINDEX(':',AVGAMT)+ 1, len(AVGAMT))
				from ##Temp_AVGAMT

				delete TOP(1) from ##Temp_AVGAMT
				delete TOP(1) from ##Temp_AVGAMT


				SELECT * FROM ##Temp_AVGAMT

END