-- PRCL RED
			set @ActResCntR = 0
			set @ActResNxtCntR = 0
			SET @varindPRCLRED = 0.00

			select @ActResCntR = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL->PPCL'
		
			while(@ActResCntR<@NoOfCells)
			begin
				EXEC SP_UpdateHealthDataRECP2 @PPRNGUD = @UD1, @Varind = @varindPRCLRED
				--EXEC SP_UpdateHealthDataINCP2 @PPRNGUD = @UD1, @Varind = @varind

				select @ActResNxtCntR = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL->PPCL'
		
			set @ActResCntR = @ActResNxtCntR
			set @varindPRCLRED = @varindPRCLRED + 0.01

			end

			select cast(@Var_ITEM_NO as varchar(10)) + ' : @varindPRCLRED-->' + cast(@varindPRCLRED as varchar(10))

			IF(@varindPRCLRED>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varindPRCLRED - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL->PPCL' 
			end 
			ELSE IF(@varindPRCLRED=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varindPRCLRED
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL->PPCL' 
			end 

			-- prcl inc
			set @ActResCntI = 0
			set @ActResNxtCntI = 0
			SET @varindPRCLINC = 0.00
			select @ActResCntI = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL->PPCL'
		
			while(@ActResCntI<@NoOfCells)
			begin
				--EXEC SP_UpdateHealthDataRECP2 @PPRNGUD = @UD1, @Varind = @varind
				EXEC SP_UpdateHealthDataINCP2 @PPRNGUD = @UD1, @Varind = @varindPRCLINC

				select @ActResNxtCntI = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL->PPCL'
		
			set @ActResCntI = @ActResNxtCntI
			set @varindPRCLINC = @varindPRCLINC + 0.01

			end

			select cast(@Var_ITEM_NO as varchar(10)) + ' : @varindPRCLINC-->' + cast(@varindPRCLINC as varchar(10))

			IF(@varindPRCLINC>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varindPRCLINC - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL->PPCL' 
			end 
			else IF(@varindPRCLINC=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varindPRCLINC
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL->PPCL' 
			end 

			-- 330ind red
			set @varind330RED = 0.00
			set @ActResCnt330R = 0
			set @ActResNxtCnt330R = 0

			select @ActResCnt330R = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = '330IND->PPCL'
		
			while(@ActResCnt330R<@NoOfCells)
			begin
				EXEC SP_UpdateHealthDataRECP2330ind @PPRNGUD = @UD1, @Varind = @varind330RED
				--EXEC SP_UpdateHealthDataINCP2330ind @PPRNGUD = @UD1, @Varind = @varind

				select @ActResNxtCnt330R = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = '330IND->PPCL'
		
			set @ActResCnt330R = @ActResNxtCnt330R
			set @varind330RED = @varind330RED + 0.01

			end

			select cast(@Var_ITEM_NO as varchar(10)) +  ' : @varind330RED-->' + cast(@varind330RED as varchar(10))

			IF(@varind330RED>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330RED - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = '330IND->PPCL' 
			end 
			else IF(@varind330RED=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330RED
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = '330IND->PPCL' 
			end 

			-- 330 inc
			set @varind330INC = 0.00
			set @ActResCnt330I = 0
			set @ActResNxtCnt330I = 0

			select @ActResCnt330I = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = '330IND->PPCL'
		
			while(@ActResCnt330I<@NoOfCells)
			begin
				--EXEC SP_UpdateHealthDataRECP2330ind @PPRNGUD = @UD1, @Varind = @varind
				EXEC SP_UpdateHealthDataINCP2330ind @PPRNGUD = @UD1, @Varind = @varind330INC

				select @ActResNxtCnt330I = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = '330IND->PPCL'
		
			set @ActResCnt330I = @ActResNxtCnt330I
			set @varind330INC = @varind330INC + 0.01

			end

			select cast(@Var_ITEM_NO as varchar(10)) + ' : @varind330INC-->' + cast(@varind330INC as varchar(10))

			IF(@varind330INC>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330INC - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = '330IND->PPCL' 
			end 
			else IF(@varind330INC=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330INC
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = '330IND->PPCL' 
			end 

			
			-- 330PRCL INC
			set @varind330PRCLINC = 0.00
			set @ActResCnt330P = 0
			set @ActResNxtCnt330P = 0

			select @ActResCnt330P = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL/330IND->PPOP/PPCL'
		
			while(@ActResCnt330P<@NoOfCells)
			begin
				--EXEC SP_UpdateHealthDataRECP2330ind @PPRNGUD = @UD1, @Varind = @varind
				EXEC SP_UpdateHealthDataINCP2330PRCL @PPRNGUD = @UD1, @Varind = @varind330PRCLINC

				select @ActResNxtCnt330P = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL/330IND->PPOP/PPCL'
		
			set @ActResCnt330P = @ActResNxtCnt330P
			set @varind330PRCLINC = @varind330PRCLINC + 0.01

			end

			select cast(@Var_ITEM_NO as varchar(10)) + ' : @varind330PRCLINC-->' + cast(@varind330PRCLINC as varchar(10))

			IF(@varind330PRCLINC>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330PRCLINC - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL/330IND->PPOP/PPCL' 
			end 
			else IF(@varind330PRCLINC = 0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330PRCLINC
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'INC' AND FLAG = 'PRCL/330IND->PPOP/PPCL' 
			end 

			-- 330PRCL RED
			set @varind330PRCLRED = 0.00
			set @ActResCnt330RP = 0
			set @ActResNxtCnt330RP = 0

			select @ActResCnt330RP = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL/330IND->PPOP/PPCL'
		
			while(@ActResCnt330RP<@NoOfCells)
			begin
				--EXEC SP_UpdateHealthDataRECP2330ind @PPRNGUD = @UD1, @Varind = @varind
				EXEC SP_UpdateHealthDataRECP2330PRCL @PPRNGUD = @UD1, @Varind = @varind330PRCLRED

				select @ActResNxtCnt330RP = (case when ISNULL(Res1,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res2,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res3,0)=0 then 0 else 1 end
				+ case when ISNULL(Res4,0)=0 then 0 else 1 end
				+ case when ISNULL(Res5,0)=0 then 0 else 1 end
				+ case when ISNULL(Res6,0)=0 then 0 else 1 end 
				+ case when ISNULL(Res7,0)=0 then 0 else 1 end
				+ case when ISNULL(Res8,0)=0 then 0 else 1 end
				+ case when ISNULL(Res9,0)=0 then 0 else 1 end     
			)
			from dbo.ProjectHelathEntryResultP2 where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL/330IND->PPOP/PPCL'
		
			set @ActResCnt330RP = @ActResNxtCnt330RP
			set @varind330PRCLRED = @varind330PRCLRED + 0.01

			end

			select cast(@Var_ITEM_NO as varchar(10)) + ' : @varind330PRCLRED-->' + cast(@varind330PRCLRED as varchar(10))

			IF(@varind330PRCLRED>0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330PRCLRED - 0.01
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL/330IND->PPOP/PPCL' 
			end 
			else IF(@varind330PRCLRED=0.00)
			begin
			UPDATE dbo.ProjectHelathEntryResultP2
			SET
				[PP-RNG-UD] = @varind330PRCLRED
			where ITEM_NO in (@Var_ITEM_NO) and [RED/INC] = 'RED' AND FLAG = 'PRCL/330IND->PPOP/PPCL' 
			end 